import os
import sys
from pathlib import Path

# Print current working directory
print(f"Current working directory: {os.getcwd()}")

# Print Python path
print("\nPython path:")
for path in sys.path:
    print(f"- {path}")

# Try to import the settings module
try:
    import refugee_management.refugee_management.settings as settings
    print("\nSuccessfully imported settings module")
    print(f"Settings module path: {settings.__file__}")
except ImportError as e:
    print(f"\nError importing settings: {e}")
    import traceback
    traceback.print_exc()

# Try to import Django
try:
    import django
    print(f"\nDjango version: {django.__version__}")
    print(f"Django path: {django.__file__}")
except ImportError as e:
    print(f"\nError importing Django: {e}")
    import traceback
    traceback.print_exc()
