import os
import sys
import django
from pathlib import Path

# Add the backend directory to the Python path
backend_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), 'backend'))
if backend_dir not in sys.path:
    sys.path.insert(0, backend_dir)

# Set the DJANGO_SETTINGS_MODULE environment variable
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'refugee_management.settings')

# Initialize Django
try:
    django.setup()
    print("Django initialized successfully")
except Exception as e:
    print(f"Error initializing Django: {e}")
    sys.exit(1)

# Print the current Python path
print("\nPython path:")
for path in sys.path:
    print(f"  - {path}")

# Try to import the users module
try:
    import refugee_management.users
    print("\nSuccessfully imported refugee_management.users")
    print(f"Users module path: {refugee_management.users.__file__}")
except ImportError as e:
    print(f"\nError importing refugee_management.users: {e}")

# Try to import the users app config
try:
    from refugee_management.users.apps import UsersConfig
    print("\nSuccessfully imported UsersConfig")
    print(f"UsersConfig name: {UsersConfig.name}")
except ImportError as e:
    print(f"\nError importing UsersConfig: {e}")

# Try to get the app config from Django
try:
    from django.apps import apps
    users_config = apps.get_app_config('users')
    print(f"\nSuccessfully got users app config: {users_config.name}")
    print(f"Users app models: {list(users_config.get_models())}")
except Exception as e:
    print(f"\nError getting users app config: {e}")
