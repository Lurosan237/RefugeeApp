# Script to run the development server

# Ensure we're in the project root
$projectRoot = Split-Path -Parent $PSScriptRoot
Set-Location $projectRoot

Write-Host " Starting development server..." -ForegroundColor Cyan

# Check if virtual environment exists
if (-not (Test-Path "venv")) {
    Write-Error "Virtual environment not found. Please run .\scripts\setup_dev_env.ps1 first."
    exit 1
}

# Activate the virtual environment
try {
    .\venv\Scripts\Activate.ps1
} catch {
    Write-Error "Failed to activate virtual environment: $_"
    exit 1
}

# Set environment variables for development
$env:DJANGO_ENV = "development"
$env:PYTHONPATH = "$projectRoot\backend"

# Check if .env file exists
if (-not (Test-Path ".env")) {
    Write-Warning ".env file not found. Creating from .env.example..."
    Copy-Item .env.example .env -ErrorAction SilentlyContinue
    Write-Warning "Please update the .env file with your settings"
}

# Run database migrations
Write-Host "Running database migrations..." -ForegroundColor Cyan
python backend\refugee_management\manage.py migrate
if ($LASTEXITCODE -ne 0) {
    Write-Error "Failed to run database migrations"
    exit 1
}

# Start the development server
Write-Host "Starting Django development server..." -ForegroundColor Cyan
Write-Host "Press Ctrl+C to stop the server" -ForegroundColor Yellow
Write-Host ""

# Run the development server
python backend\refugee_management\manage.py runserver

# Show message after server stops
Write-Host ""
Write-Host "Development server stopped." -ForegroundColor Cyan
python manage.py runserver
