# Setup development environment for Refugee Management System

# Check if Python is installed
$pythonVersion = python --version 2>&1
if (-not $?) {
    Write-Error "Python is not installed or not in PATH. Please install Python 3.8 or higher."
    exit 1
}

# Check if virtual environment exists, create if not
if (-not (Test-Path -Path ".\venv")) {
    Write-Host "Creating virtual environment..."
    python -m venv venv
}

# Activate virtual environment
Write-Host "Activating virtual environment..."
.\venv\Scripts\Activate.ps1

# Upgrade pip
Write-Host "Upgrading pip..." -ForegroundColor Cyan
python -m pip install --upgrade pip
if ($LASTEXITCODE -ne 0) {
    Write-Error "Failed to upgrade pip"
    exit 1
}

# Install development dependencies
Write-Host "Installing development dependencies..." -ForegroundColor Cyan
pip install -r requirements\development.txt
if ($LASTEXITCODE -ne 0) {
    Write-Error "Failed to install development dependencies"
    exit 1
}

# Create a .env file if it doesn't exist
if (-not (Test-Path ".env")) {
    Write-Host "Creating .env file from .env.example..." -ForegroundColor Cyan
    Copy-Item .env.example .env
    Write-Host "Created .env file from .env.example" -ForegroundColor Green
    Write-Host "Please update the .env file with your settings" -ForegroundColor Yellow
}

# Set up pre-commit hooks if pre-commit is installed
if (Get-Command pre-commit -ErrorAction SilentlyContinue) {
    Write-Host "Setting up pre-commit hooks..." -ForegroundColor Cyan
    pre-commit install
}

# Install Node.js dependencies if frontend directory exists
if (Test-Path "frontend") {
    Write-Host "Installing frontend dependencies..." -ForegroundColor Cyan
    Set-Location frontend
    npm install
    if ($LASTEXITCODE -ne 0) {
        Write-Error "Failed to install frontend dependencies"
        exit 1
    }
    Set-Location ..
}

# Run database migrations
Write-Host "Running database migrations..." -ForegroundColor Cyan
python backend\refugee_management\manage.py migrate
if ($LASTEXITCODE -ne 0) {
    Write-Error "Failed to run database migrations"
    exit 1
}

# Create superuser if it doesn't exist
$adminExists = python -c "
import os
import django
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'refugee_management.settings')
django.setup()
from django.contrib.auth import get_user_model
User = get_user_model()
print(User.objects.filter(is_superuser=True).exists())"

if ($adminExists -eq "False") {
    Write-Host "Creating superuser..." -ForegroundColor Cyan
    python backend\refugee_management\manage.py createsuperuser
    if ($LASTEXITCODE -ne 0) {
        Write-Error "Failed to create superuser"
        exit 1
    }
}

Write-Host ""
Write-Host "✅ Development environment setup complete!" -ForegroundColor Green
Write-Host "To start the development server, run: .\scripts\run_dev_server.ps1" -ForegroundColor Cyan
Write-Host "Don't forget to update your .env file with your settings" -ForegroundColor Yellow
