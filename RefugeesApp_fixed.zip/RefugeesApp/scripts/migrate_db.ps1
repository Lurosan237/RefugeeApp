# Script to run database migrations

param (
    [string]$env = "development"
)

# Set environment variables based on the environment
if ($env -eq "production") {
    $env:DJANGO_DEVELOPMENT = "false"
    $env:DJANGO_SETTINGS_MODULE = "refugee_management.refugee_management.production"
    Write-Host "Running migrations for production environment..."
} else {
    $env:DJANGO_DEVELOPMENT = "true"
    $env:DJANGO_SETTINGS_MODULE = "refugee_management.refugee_management.settings"
    Write-Host "Running migrations for development environment..."
}

# Ensure we're in the project root
$projectRoot = Split-Path -Parent $PSScriptRoot
Set-Location $projectRoot

Write-Host " Running database migrations..." -ForegroundColor Cyan

# Check if virtual environment exists
if (-not (Test-Path "venv")) {
    Write-Error "Virtual environment not found. Please run the setup script first."
    exit 1
}

# Activate the virtual environment
try {
    .\venv\Scripts\Activate.ps1
} catch {
    Write-Error "Failed to activate virtual environment: $_"
    exit 1
}

# Set environment variables based on .env file
if (Test-Path ".env") {
    Get-Content .env | ForEach-Object {
        $line = $_.Trim()
        if ($line -and !$line.StartsWith('#')) {
            $parts = $line -split '=', 2
            if ($parts.Length -eq 2) {
                $name = $parts[0].Trim()
                $value = $parts[1].Trim()
                # Remove surrounding quotes if they exist
                $value = $value.Trim('"').Trim("'")
                if ($name -and $value) {
                    [System.Environment]::SetEnvironmentVariable($name, $value, 'Process')
                }
            }
        }
    }
} else {
    Write-Warning ".env file not found. Using default settings."
}

# Set PYTHONPATH to include both the backend directory and the project root
$env:PYTHONPATH = "$projectRoot\backend;$projectRoot"

# Set the DJANGO_SETTINGS_MODULE environment variable
$isProduction = $env:DJANGO_ENV -eq "production"
$settingsModule = if ($isProduction) { "refugee_management.production" } else { "refugee_management.settings" }
$env:DJANGO_SETTINGS_MODULE = $settingsModule

# Check database connection by running migrate with --check flag
Write-Host "Checking database connection..." -ForegroundColor Cyan
$checkCmd = "python backend\refugee_management\manage.py check --database default"
$checkOutput = Invoke-Expression $checkCmd 2>&1

if ($LASTEXITCODE -eq 0) {
    Write-Host " Database connection successful" -ForegroundColor Green
} else {
    Write-Error " Database connection check failed: $checkOutput"
    exit 1
}

# If any arguments are passed, treat them as app names to create migrations for
if ($args.Count -gt 0) {
    Write-Host "Creating migrations for: $($args -join ', ')" -ForegroundColor Cyan
    python backend\refugee_management\manage.py makemigrations $args
    if ($LASTEXITCODE -ne 0) {
        Write-Error " Failed to create migrations"
        exit 1
    }
}

# Apply migrations
Write-Host "Applying migrations..." -ForegroundColor Cyan
python backend\refugee_management\manage.py migrate --noinput
if ($LASTEXITCODE -ne 0) {
    Write-Error " Failed to apply migrations"
    exit 1
}

# If no arguments were passed, show migration status
if ($args.Count -eq 0) {
    Write-Host "Migration status:" -ForegroundColor Cyan
    python backend\refugee_management\manage.py showmigrations
    if ($LASTEXITCODE -ne 0) {
        Write-Error " Failed to show migration status"
        exit 1
    }
}

# Create cache table if using database cache
if ($isProduction) {
    Write-Host "Creating cache tables..." -ForegroundColor Cyan
    python backend\refugee_management\manage.py createcachetable
    if ($LASTEXITCODE -ne 0) {
        Write-Warning "  Failed to create cache tables (this is not critical)"
    }
}

# If this is the first time setting up, create a superuser
if ($env -eq "development") {
    $createSuperuser = Read-Host "Do you want to create a superuser? (y/n)"
    if ($createSuperuser -eq "y") {
        python manage.py createsuperuser
    }
}

Write-Host ""
Write-Host " Database migrations completed successfully!" -ForegroundColor Green
