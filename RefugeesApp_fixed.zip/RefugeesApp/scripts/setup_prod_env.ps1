# Setup production environment for Refugee Management System

param (
    [string]$envFile = ".env.production"
)

# Check if Python is installed
$pythonVersion = python --version 2>&1
if (-not $?) {
    Write-Error "Python is not installed or not in PATH. Please install Python 3.8 or higher."
    exit 1
}

# Check if virtual environment exists, create if not
if (-not (Test-Path -Path ".\venv")) {
    Write-Host "Creating virtual environment..."
    python -m venv venv
}

# Activate the virtual environment
Write-Host "Activating virtual environment..." -ForegroundColor Cyan
try {
    .\venv\Scripts\Activate.ps1
} catch {
    Write-Error "Failed to activate virtual environment: $_"
    exit 1
}

# Upgrade pip
Write-Host "Upgrading pip..." -ForegroundColor Cyan
python -m pip install --upgrade pip
if ($LASTEXITCODE -ne 0) {
    Write-Error "Failed to upgrade pip"
    exit 1
}

# Install production dependencies
Write-Host "Installing production dependencies..." -ForegroundColor Cyan
pip install -r requirements\production.txt
if ($LASTEXITCODE -ne 0) {
    Write-Error "Failed to install production dependencies"
    exit 1
}

# Create a .env file if it doesn't exist
if (-not (Test-Path ".env")) {
    Write-Host "Creating .env file from .env.example..." -ForegroundColor Cyan
    Copy-Item .env.example .env
    Write-Host "Created .env file from .env.example" -ForegroundColor Green
    Write-Host "Please update the .env file with your production settings" -ForegroundColor Yellow
    Write-Host "Make sure to set DJANGO_ENV=production and update all database credentials" -ForegroundColor Yellow
}

# Set environment variables for production
$env:DJANGO_ENV = "production"
$env:PYTHONPATH = "$projectRoot\backend"

# Collect static files
Write-Host "Collecting static files..." -ForegroundColor Cyan
python backend\refugee_management\manage.py collectstatic --noinput
if ($LASTEXITCODE -ne 0) {
    Write-Error "Failed to collect static files"
    exit 1
}

# Run database migrations
Write-Host "Running database migrations..." -ForegroundColor Cyan
python backend\refugee_management\manage.py migrate
if ($LASTEXITCODE -ne 0) {
    Write-Error "Failed to run database migrations"
    exit 1
}

# Create superuser if it doesn't exist
$adminExists = python -c "
import os
import django
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'refugee_management.production')
django.setup()
from django.contrib.auth import get_user_model
User = get_user_model()
print(User.objects.filter(is_superuser=True).exists())"

if ($adminExists -eq "False") {
    Write-Host "Creating superuser..." -ForegroundColor Cyan
    $adminEmail = Read-Host "Enter admin email (default: admin@example.com)"
    if ([string]::IsNullOrWhiteSpace($adminEmail)) {
        $adminEmail = "admin@example.com"
    }
    
    $adminPassword = Read-Host -AsSecureString "Enter admin password (min 8 characters)"
    $adminPassword = [Runtime.InteropServices.Marshal]::PtrToStringAuto(
        [Runtime.InteropServices.Marshal]::SecureStringToBSTR($adminPassword)
    )
    
    if ($adminPassword.Length -lt 8) {
        Write-Error "Password must be at least 8 characters long"
        exit 1
    }
    
    $createSuperuserCmd = @"
import os
import django
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'refugee_management.production')
django.setup()
from django.contrib.auth import get_user_model
User = get_user_model()
if not User.objects.filter(username='admin').exists():
    User.objects.create_superuser('admin', '$adminEmail', '$adminPassword')
    print('Superuser created successfully')
else:
    print('Superuser already exists')
"@
    
    $createSuperuserCmd | python
    if ($LASTEXITCODE -ne 0) {
        Write-Error "Failed to create superuser"
        exit 1
    }
}

Write-Host ""
Write-Host "✅ Production environment setup complete!" -ForegroundColor Green
Write-Host "To start the production server, run: .\scripts\run_prod_server.ps1" -ForegroundColor Cyan
Write-Host "Make sure your .env file is properly configured for production" -ForegroundColor Yellow
