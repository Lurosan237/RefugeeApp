# Script to run the production server with Gunicorn

param (
    [int]$workers = 3,
    [string]$hostAddr = "0.0.0.0:8000",
    [string]$envFile = ".env.production"
)

# Check if production environment file exists
if (-not (Test-Path -Path $envFile)) {
    Write-Error "Production environment file '$envFile' not found. Please create it from .env.example"
    exit 1
}

# Ensure we're in the project root
$projectRoot = Split-Path -Parent $PSScriptRoot
Set-Location $projectRoot

Write-Host " Starting production server..." -ForegroundColor Cyan

# Check if running as administrator
$isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $isAdmin) {
    Write-Error "This script requires administrator privileges. Please run as administrator."
    exit 1
}

# Check if virtual environment exists
if (-not (Test-Path "venv")) {
    Write-Error "Virtual environment not found. Please run .\scripts\setup_prod_env.ps1 first."
    exit 1
}

# Activate the virtual environment
try {
    .\venv\Scripts\Activate.ps1
} catch {
    Write-Error "Failed to activate virtual environment: $_"
    exit 1
}

# Set environment variables for production
$env:DJANGO_ENV = "production"
$env:PYTHONPATH = "$projectRoot\backend"

gunicorn --workers $workers --bind $hostAddr refugee_management.wsgi:application
