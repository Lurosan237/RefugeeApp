# Refugee Management Application

A comprehensive web application for managing refugees and food distribution for NGOs.

## Features

### Admin (NGO)
- Refugee account management
- Food distribution planning
- Beneficiary list management
- Beneficiary tracking
- Report generation
- Manager account management

### Manager (Stock Keeper)
- Food item registration
- Distribution schedule viewing
- Refugee eligibility verification
- Stock level updates
- Distribution report submission

## Technology Stack

### Backend
- **Framework**: Django 4.2 with Django REST Framework
- **Database**: 
  - Development: SQLite
  - Production: PostgreSQL 13+
- **Authentication**: JWT (JSON Web Tokens)
- **API Documentation**: Swagger/OpenAPI
- **Caching**: Redis
- **Static Files**: WhiteNoise
- **WSGI Server**: Gunicorn
- **ASGI Server**: Daphne (for WebSocket support)

### Frontend (Coming Soon)
- **Framework**: React 18
- **UI Library**: Material-UI
- **State Management**: Redux Toolkit
- **API Client**: Axios

## Project Structure

```
RefugeesApp/
├── .env.example               # Example environment variables
├── .gitignore
├── README.md
├── backend/                   # Django project
│   ├── refugee_management/     # Main project directory
│   │   ├── __init__.py
│   │   ├── asgi.py            # ASGI config
│   │   ├── settings/          # Settings directory
│   │   │   ├── __init__.py
│   │   │   ├── base.py        # Base settings
│   │   │   ├── development.py # Development settings
│   │   │   └── production.py  # Production settings
│   │   ├── urls.py           # Main URL configuration
│   │   └── wsgi.py           # WSGI config
│   ├── users/                 # User management app
│   ├── refugees/              # Refugee management app
│   ├── distributions/         # Distribution management app
│   ├── stocks/                # Stock management app
│   └── reports/               # Report generation app
├── requirements/              # Requirements files
│   ├── base.txt              # Base requirements
│   ├── development.txt       # Development requirements
│   └── production.txt        # Production requirements
└── scripts/                  # Utility scripts
    ├── setup_dev_env.ps1     # Setup development environment
    ├── setup_prod_env.ps1    # Setup production environment
    ├── run_dev_server.ps1    # Run development server
    ├── run_prod_server.ps1   # Run production server
    └── migrate_db.ps1        # Run database migrations
```

## Getting Started

### Prerequisites

- Python 3.8+
- PostgreSQL 13+ (for production)
- Node.js 16+ (for frontend, coming soon)
- Git

### Development Setup

1. **Clone the repository**
   ```bash
   git clone [repository-url]
   cd RefugeesApp
   ```

2. **Set up the development environment**
   ```powershell
   # Copy example environment file
   Copy-Item .env.example .env
   ```
   
   Update the `.env` file with your development settings.

3. **Run the development setup script**
   ```powershell
   .\scripts\setup_dev_env.ps1
   ```
   
   This script will:
   - Create a Python virtual environment
   - Install development dependencies
   - Set up environment variables

4. **Run database migrations**
   ```powershell
   .\scripts\migrate_db.ps1
   ```
   
   This will apply all database migrations and prompt you to create a superuser if one doesn't exist.

5. **Start the development server**
   ```powershell
   .\scripts\run_dev_server.ps1
   ```
   
   The development server will be available at `http://localhost:8000`

### Production Setup

1. **Set up the production environment**
   ```powershell
   # Copy example environment file
   Copy-Item .env.example .env
   ```
   
   Update the `.env` file with your production settings, ensuring:
   - `DJANGO_ENV=production`
   - `DEBUG=False`
   - All database credentials are correct
   - `SECRET_KEY` is set to a secure value
   - `ALLOWED_HOSTS` includes your domain

2. **Run the production setup script**
   ```powershell
   .\scripts\setup_prod_env.ps1
   ```

3. **Run database migrations**
   ```powershell
   .\scripts\migrate_db.ps1
   ```

4. **Start the production server**
   ```powershell
   .\scripts\run_prod_server.ps1
   ```
   
   By default, this will start Gunicorn with 4 worker processes. You can customize this:
   ```powershell
   .\scripts\run_prod_server.ps1 -workers 8 -host "0.0.0.0" -port 8000
   ```

## Environment Configuration

### Development
- Uses SQLite database by default
- Debug mode enabled
- Detailed error pages
- Automatic reload on code changes
- Console email backend

### Production
- Uses PostgreSQL database
- Debug mode disabled
- Secure settings enabled (HSTS, SSL redirect, secure cookies)
- Email backend configured for production
- Static files collected and served by WhiteNoise
- Gunicorn as WSGI server

## Security Best Practices

1. **Secrets Management**
   - Never commit sensitive data to version control
   - Use environment variables for all secrets
   - The `.env` file is in `.gitignore` by default

2. **Dependencies**
   - Keep all dependencies up to date
   - Use `requirements/base.txt` for shared dependencies
   - Separate development and production requirements

3. **Database**
   - Use different databases for development and production
   - Regular backups recommended in production

4. **HTTPS**
   - Always use HTTPS in production
   - Set up automatic redirect from HTTP to HTTPS

5. **Django Settings**
   - `DEBUG=False` in production
   - `SECRET_KEY` must be kept secret
   - `ALLOWED_HOSTS` must be properly configured

## API Documentation

API documentation is available at `/api/docs/` when running the development server.

## Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit your changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to the branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## Acknowledgments

- Django REST Framework for the powerful API framework
- WhiteNoise for static file serving
- Gunicorn for production WSGI server
- All contributors who have helped improve this project

```bash
cd frontend
npm install
npm start
```