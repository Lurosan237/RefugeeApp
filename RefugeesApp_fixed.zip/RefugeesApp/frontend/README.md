# Application de Gestion des Réfugiés - Frontend

## À propos

Cette application frontend fait partie d'un système de gestion des réfugiés qui permet de suivre les réfugiés, les distributions d'aide et les stocks de produits.

## Configuration du développement

### Prérequis

- Node.js (v14 ou supérieur)
- npm (v6 ou supérieur)

### Installation

```bash
# Installer les dépendances
npm install
```

### Démarrage du serveur de développement

```bash
npm start
```

L'application sera accessible à l'adresse [http://localhost:3000](http://localhost:3000).

## Mode de développement sans backend

Actuellement, l'application est configurée pour fonctionner avec des données fictives (mock) pour faciliter le développement sans avoir besoin du backend. Les services suivants ont été modifiés pour utiliser des données mock :

- `refugeeService`
- `distributionService`
- `stockService`

### Comment utiliser les données mock

Les données mock sont déjà configurées dans les fichiers suivants :

- `src/services/mockData.js` - Contient toutes les données fictives
- `src/services/mockServices.js` - Implémente les services avec les données mock

Les composants utilisent ces services mock au lieu des services réels qui communiquent avec le backend.

### Revenir aux services réels

Pour revenir à l'utilisation des services réels (lorsque le backend est disponible), modifiez les imports dans les composants concernés. Par exemple, dans `Dashboard.js` :

```javascript
// Remplacer ceci
import { mockRefugeeService as refugeeService, 
         mockDistributionService as distributionService, 
         mockStockService as stockService } from '../services/mockServices';

// Par ceci
import refugeeService from '../services/refugeeService';
import distributionService from '../services/distributionService';
import stockService from '../services/stockService';
```

## Configuration du proxy

L'application est configurée pour proxifier les requêtes API vers le backend Django qui doit fonctionner sur `http://localhost:8000`. Cette configuration se trouve dans le fichier `package.json` :

```json
"proxy": "http://localhost:8000"
```

Assurez-vous que le serveur backend est en cours d'exécution sur ce port lorsque vous utilisez les services réels.

## Résolution des problèmes

### Erreurs de proxy

Si vous voyez des erreurs de proxy comme `Proxy error: Could not proxy request /api/...`, cela signifie que le frontend ne peut pas se connecter au backend. Vérifiez que :

1. Le serveur backend est en cours d'exécution
2. Le serveur backend est accessible sur le port 8000
3. Les points d'API sont correctement configurés

En mode développement avec données mock, ces erreurs peuvent être ignorées car les données sont générées localement.

## Structure du projet

- `src/pages/` - Composants de page principaux
- `src/components/` - Composants réutilisables
- `src/services/` - Services pour communiquer avec l'API
- `src/services/mockServices.js` - Services utilisant des données fictives
- `src/services/mockData.js` - Données fictives pour le développement