import React from 'react';
import { Routes, Route } from 'react-router-dom';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { AdapterDateFns } from '@mui/x-date-pickers/AdapterDateFns';
import { fr } from 'date-fns/locale';
import { ThemeProvider, createTheme } from '@mui/material/styles';
import CssBaseline from '@mui/material/CssBaseline';

// Pages à créer
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';
import RefugeesList from './pages/RefugeesList';
import RefugeeDetail from './pages/RefugeeDetail';
import DistributionsList from './pages/DistributionsList';
import DistributionDetail from './pages/DistributionDetail';
import StockManagement from './pages/StockManagement';
import Reports from './pages/Reports';
import Profile from './pages/Profile'; // Ajouter l'importation pour la page de profil
import NotFound from './pages/NotFound';

// Composants
import PrivateRoute from './components/PrivateRoute'; // Assurez-vous que l'import est correct
import Layout from './components/Layout';

// Thème de l'application
const theme = createTheme({
  palette: {
    primary: {
      main: '#1976d2',
    },
    secondary: {
      main: '#dc004e',
    },
    background: {
      default: '#f5f5f5',
    },
  },
});

function App() {
  return (
    <LocalizationProvider dateAdapter={AdapterDateFns} adapterLocale={fr}>
      <ThemeProvider theme={theme}>
      <CssBaseline />
      <Routes>
        <Route path="/login" element={<Login />} />
        
        {/* Routes protégées avec contrôle de rôle */}
        <Route 
          path="/" 
          element={
            <PrivateRoute>
              <Layout />
            </PrivateRoute>
          }
        >
          {/* Routes accessibles à tous les utilisateurs connectés (ou définir des rôles spécifiques) */}
          <Route index element={<PrivateRoute><Dashboard /></PrivateRoute>} />
          <Route path="profile" element={<PrivateRoute><Profile /></PrivateRoute>} />

          {/* Routes potentiellement restreintes (exemple : Admin, Manager) */}
          <Route path="refugees" element={<PrivateRoute roles={['ADMIN', 'MANAGER']}><RefugeesList /></PrivateRoute>} />
          <Route path="refugees/:id" element={<PrivateRoute roles={['ADMIN', 'MANAGER']}><RefugeeDetail /></PrivateRoute>} />
          <Route path="distributions" element={<PrivateRoute roles={['ADMIN', 'MANAGER', 'Volunteer']}><DistributionsList /></PrivateRoute>} />
          <Route path="distributions/:id" element={<PrivateRoute roles={['ADMIN', 'MANAGER', 'Volunteer']}><DistributionDetail /></PrivateRoute>} />
          <Route path="stock" element={<PrivateRoute roles={['ADMIN', 'MANAGER']}><StockManagement /></PrivateRoute>} />
          <Route path="reports" element={<PrivateRoute roles={['ADMIN', 'MANAGER']}><Reports /></PrivateRoute>} />
        </Route>
        
        {/* Route 404 */}
        <Route path="*" element={<NotFound />} />
      </Routes>
    </ThemeProvider>
  </LocalizationProvider>
  );
}

export default App;