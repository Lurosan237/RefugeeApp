import axios from 'axios';

const API_URL = '/api/reports';

// Service pour gérer les opérations liées aux rapports
const reportService = {
  // Récupérer tous les rapports disponibles
  getAll: async () => {
    try {
      const response = await axios.get(`${API_URL}/`);
      return response.data;
    } catch (error) {
      throw error;
    }
  },

  // Récupérer les rapports de réfugiés
  getRefugeeReports: async (startDate, endDate, reportType = 'monthly') => {
    try {
      const response = await axios.get(`${API_URL}/refugees/`, {
        params: { start_date: startDate, end_date: endDate, report_type: reportType }
      });
      return response.data;
    } catch (error) {
      throw error;
    }
  },

  // Récupérer les rapports de distributions
  getDistributionReports: async (startDate, endDate, reportType = 'monthly') => {
    try {
      const response = await axios.get(`${API_URL}/distributions/`, {
        params: { start_date: startDate, end_date: endDate, report_type: reportType }
      });
      return response.data;
    } catch (error) {
      throw error;
    }
  },

  // Récupérer les rapports de stock
  getStockReports: async (startDate, endDate) => {
    try {
      const response = await axios.get(`${API_URL}/stocks/`, {
        params: { start_date: startDate, end_date: endDate }
      });
      return response.data;
    } catch (error) {
      throw error;
    }
  },

  // Générer un rapport de réfugiés
  generateRefugeeReport: async (filters = {}) => {
    try {
      const response = await axios.post(`${API_URL}/refugees/`, filters);
      return response.data;
    } catch (error) {
      throw error;
    }
  },

  // Générer un rapport de distributions
  generateDistributionReport: async (filters = {}) => {
    try {
      const response = await axios.post(`${API_URL}/distributions/`, filters);
      return response.data;
    } catch (error) {
      throw error;
    }
  },

  // Générer un rapport de stock
  generateStockReport: async (filters = {}) => {
    try {
      const response = await axios.post(`${API_URL}/stocks/`, filters);
      return response.data;
    } catch (error) {
      throw error;
    }
  },

  // Exporter un rapport de réfugiés
  exportRefugeeReport: async (startDate, endDate, reportType = 'monthly', format = 'pdf') => {
    try {
      const response = await axios.get(`${API_URL}/refugees/export/`, {
        params: { start_date: startDate, end_date: endDate, report_type: reportType, format },
        responseType: 'blob'
      });
      return URL.createObjectURL(response.data);
    } catch (error) {
      throw error;
    }
  },

  // Exporter un rapport de distributions
  exportDistributionReport: async (startDate, endDate, reportType = 'monthly', format = 'pdf') => {
    try {
      const response = await axios.get(`${API_URL}/distributions/export/`, {
        params: { start_date: startDate, end_date: endDate, report_type: reportType, format },
        responseType: 'blob'
      });
      return URL.createObjectURL(response.data);
    } catch (error) {
      throw error;
    }
  },

  // Exporter un rapport de stock
  exportStockReport: async (startDate, endDate, format = 'pdf') => {
    try {
      const response = await axios.get(`${API_URL}/stocks/export/`, {
        params: { start_date: startDate, end_date: endDate, format },
        responseType: 'blob'
      });
      return URL.createObjectURL(response.data);
    } catch (error) {
      throw error;
    }
  },

  // Télécharger un rapport au format PDF
  downloadPdf: async (reportId) => {
    try {
      const response = await axios.get(`${API_URL}/${reportId}/download/pdf/`, {
        responseType: 'blob'
      });
      return response.data;
    } catch (error) {
      throw error;
    }
  },

  // Télécharger un rapport au format Excel
  downloadExcel: async (reportId) => {
    try {
      const response = await axios.get(`${API_URL}/${reportId}/download/excel/`, {
        responseType: 'blob'
      });
      return response.data;
    } catch (error) {
      throw error;
    }
  },

  // Créer un nouveau rapport
  createReport: async (reportData) => {
    try {
      const response = await axios.post(`${API_URL}/`, reportData);
      return response.data;
    } catch (error) {
      throw error;
    }
  }
};

export default reportService;