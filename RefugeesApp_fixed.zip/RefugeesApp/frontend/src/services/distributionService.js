import axios from 'axios';

const API_URL = '/api/distributions';

// Configuration de l'intercepteur pour ajouter le token JWT à chaque requête
axios.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token');
    if (token) {
      config.headers['Authorization'] = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Service pour gérer les opérations liées aux distributions
const distributionService = {
  // Récupérer toutes les distributions avec pagination
  getAll: async (page = 1, limit = 10, search = '') => {
    try {
      const response = await axios.get(`${API_URL}/?page=${page}&limit=${limit}&search=${search}`);
      return response.data;
    } catch (error) {
      throw error;
    }
  },

  // Récupérer une distribution par son ID
  getById: async (id) => {
    try {
      const response = await axios.get(`${API_URL}/${id}/`);
      return response.data;
    } catch (error) {
      throw error;
    }
  },

  // Créer une nouvelle distribution
  create: async (distributionData) => {
    try {
      const response = await axios.post(`${API_URL}/`, distributionData);
      return response.data;
    } catch (error) {
      throw error;
    }
  },

  // Mettre à jour une distribution existante
  update: async (id, distributionData) => {
    try {
      const response = await axios.put(`${API_URL}/${id}/`, distributionData);
      return response.data;
    } catch (error) {
      throw error;
    }
  },

  // Supprimer une distribution
  delete: async (id) => {
    try {
      const response = await axios.delete(`${API_URL}/${id}/`);
      return response.data;
    } catch (error) {
      throw error;
    }
  },

  // Marquer une distribution comme terminée
  markAsCompleted: async (id) => {
    try {
      const response = await axios.patch(`${API_URL}/${id}/complete/`, {});
      return response.data;
    } catch (error) {
      throw error;
    }
  },

  // Récupérer les statistiques des distributions
  getStatistics: async () => {
    try {
      const response = await axios.get(`${API_URL}/statistics/`);
      return response.data;
    } catch (error) {
      throw error;
    }
  }
};

export default distributionService;