import axios from 'axios';

const API_URL = '/api';

// Service pour gérer l'authentification
const authService = {
  // Connexion utilisateur
  login: async (email, password) => {
    console.log('[AuthService] Attempting login for:', email);
    try {
      const response = await axios.post(`${API_URL}/token/`, { email, password });
      if (response.data.access) {
        console.log('[AuthService] Login successful, token received.');
        localStorage.setItem('token', response.data.access);
        localStorage.setItem('refreshToken', response.data.refresh);
        return response.data;
      }
    } catch (error) {
      console.error('[AuthService] Login failed:', error.response ? error.response.data : error.message);
      throw error;
    }
  },

  // Déconnexion utilisateur
  logout: () => {
    console.log('[AuthService] Logging out.');
    localStorage.removeItem('token');
    localStorage.removeItem('refreshToken');
  },

  // Récupérer le token actuel
  getCurrentToken: () => {
    return localStorage.getItem('token');
  },

  // Récupérer les informations de l'utilisateur connecté
  getCurrentUser: async () => {
    console.log('[AuthService] Attempting to get current user.');
    try {
      const token = localStorage.getItem('token');
      if (!token) {
        console.log('[AuthService] No token found for current user.');
        return null;
      }
      console.log('[AuthService] Token found, fetching user data.');
      const response = await axios.get(`${API_URL}/users/me/`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      console.log('[AuthService] Current user data fetched:', response.data);
      return response.data;
    } catch (error) {
      console.error('[AuthService] Error fetching current user:', error.response ? error.response.data : error.message);
      throw error;
    }
  },

  // Rafraîchir le token
  refreshToken: async () => {
    console.log('[AuthService] Attempting to refresh token.');
    try {
      const refreshToken = localStorage.getItem('refreshToken');
      if (!refreshToken) {
        console.log('[AuthService] No refresh token available.');
        throw new Error('No refresh token available');
      }

      const response = await axios.post(`${API_URL}/token/refresh/`, {
        refresh: refreshToken
      });

      if (response.data.access) {
        console.log('[AuthService] Token refreshed successfully.');
        localStorage.setItem('token', response.data.access);
        return response.data.access;
      }
    } catch (error) {
      console.error('[AuthService] Error refreshing token:', error.response ? error.response.data : error.message);
      throw error;
    }
  }
};

export default authService;