import axios from 'axios';

const API_URL = '/api/refugees';

// Configuration de l'intercepteur pour ajouter le token JWT à chaque requête
axios.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token');
    if (token) {
      config.headers['Authorization'] = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Add data validation before sending to server
const validateRequestData = (data) => {
  // Ensure required fields are present
  const requiredFields = ['first_name', 'last_name', 'registration_number', 'gender', 'nationality'];
  const missingFields = requiredFields.filter(field => !data[field]);
  
  if (missingFields.length > 0) {
    throw new Error(`Missing required fields: ${missingFields.join(', ')}`);
  }

  // Validate date formats
  if (data.date_of_birth && !/^\d{4}-\d{2}-\d{2}$/.test(data.date_of_birth)) {
    throw new Error('Invalid date_of_birth format. Use YYYY-MM-DD');
  }
  
  if (data.arrival_date && !/^\d{4}-\d{2}-\d{2}$/.test(data.arrival_date)) {
    throw new Error('Invalid arrival_date format. Use YYYY-MM-DD');
  }

  return true;
};

// Service pour gérer les opérations liées aux réfugiés
const refugeeService = {
  // Récupérer tous les réfugiés avec pagination
  getAll: async (page = 1, limit = 10, search = '') => {
    try {
      const response = await axios.get(`${API_URL}/?page=${page}&limit=${limit}&search=${search}`);
      return response.data;
    } catch (error) {
      throw error;
    }
  },

  // Récupérer un réfugié par son ID
  getById: async (id) => {
    try {
      const response = await axios.get(`${API_URL}/${id}/`);
      return response.data;
    } catch (error) {
      throw error;
    }
  },

  // Créer un nouveau réfugié
  create: async (refugeeData) => {
    try {
      // Log the request data
      console.log('Creating refugee with data:', refugeeData);
      
      validateRequestData(refugeeData);
      
      // Format dates properly
      const formattedData = {
        ...refugeeData,
        date_of_birth: refugeeData.date_of_birth ? new Date(refugeeData.date_of_birth).toISOString().split('T')[0] : null,
        arrival_date: new Date(refugeeData.arrival_date).toISOString().split('T')[0]
      };

      const response = await axios.post(`${API_URL}/`, formattedData);
      console.log('Server response:', response);
      return response.data;
    } catch (error) {
      console.error('Server error:', error.response?.data || error.message);
      if (error.response?.status === 500) {
        throw new Error('Erreur serveur: Veuillez contacter l\'administrateur');
      }
      throw error;
    }
  },

  // Mettre à jour un réfugié existant
  update: async (id, refugeeData) => {
    try {
      validateRequestData(refugeeData);
      const response = await axios.put(`${API_URL}/${id}/`, refugeeData);
      return response.data;
    } catch (error) {
      if (error.message) {
        throw new Error(error.message);
      }
      throw error;
    }
  },

  // Supprimer un réfugié
  delete: async (id) => {
    try {
      const response = await axios.delete(`${API_URL}/${id}/`);
      return response.data;
    } catch (error) {
      throw error;
    }
  },

  // Récupérer les statistiques des réfugiés
  getStatistics: async () => {
    try {
      const response = await axios.get(`${API_URL}/statistics/`);
      return response.data;
    } catch (error) {
      if (error.code === 'ECONNREFUSED') {
        throw new Error('Impossible de se connecter au serveur. Vérifiez que le backend est en cours d\'exécution.');
      }
      console.error('Statistics error:', error.response?.data || error.message);
      throw error;
    }
  }
};

export default refugeeService;