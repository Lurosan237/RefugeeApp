import { mockRefugeeStats, mockRefugees, mockDistributionStats, mockDistributions, mockStockStats, mockStocks } from './mockData';

// Service mock pour les réfugiés
export const mockRefugeeService = {
  getAll: async (page = 1, limit = 10, search = '') => {
    // Simuler un délai réseau
    await new Promise(resolve => setTimeout(resolve, 300));
    // Filtrer par recherche si nécessaire
    const filteredResults = search
      ? mockRefugees.results.filter(r => 
          r.first_name.toLowerCase().includes(search.toLowerCase()) || 
          r.last_name.toLowerCase().includes(search.toLowerCase()) ||
          r.registration_number.toLowerCase().includes(search.toLowerCase())
        )
      : mockRefugees.results;
    
    const start = (page - 1) * limit;
    const end = start + limit;
    const paginatedResults = filteredResults.slice(start, end);

    return {
      count: filteredResults.length,
      results: paginatedResults
    };
  },

  getById: async (id) => {
    await new Promise(resolve => setTimeout(resolve, 300));
    const refugee = mockRefugees.results.find(r => r.id === parseInt(id));
    if (!refugee) {
      throw new Error('Réfugié non trouvé');
    }
    return refugee;
  },

  create: async (refugeeData) => {
    await new Promise(resolve => setTimeout(resolve, 300));
    const newRefugee = { ...refugeeData, id: Math.floor(Math.random() * 1000) + 100 };
    // Note: Ne modifie pas réellement mockRefugees dans cette version mock
    return newRefugee;
  },

  update: async (id, refugeeData) => {
    await new Promise(resolve => setTimeout(resolve, 300));
    // Note: Ne modifie pas réellement mockRefugees dans cette version mock
    return { ...refugeeData, id: parseInt(id) };
  },

  delete: async (id) => {
    await new Promise(resolve => setTimeout(resolve, 300));
    // Note: Ne modifie pas réellement mockRefugees dans cette version mock
    return { success: true };
  },

  getStatistics: async () => {
    await new Promise(resolve => setTimeout(resolve, 300));
    return mockRefugeeStats;
  }
};

// Service mock pour les distributions
export const mockDistributionService = {
  getAll: async (page = 1, limit = 10, search = '') => {
    await new Promise(resolve => setTimeout(resolve, 300));
    // Simuler la pagination et la recherche si nécessaire
    return mockDistributions;
  },

  getById: async (id) => {
    await new Promise(resolve => setTimeout(resolve, 300));
    const distribution = mockDistributions.results.find(d => d.id === parseInt(id));
    if (!distribution) {
      throw new Error('Distribution non trouvée');
    }
    return distribution;
  },

  create: async (distributionData) => {
    await new Promise(resolve => setTimeout(resolve, 300));
    return { ...distributionData, id: Math.floor(Math.random() * 1000) + 100 };
  },

  update: async (id, distributionData) => {
    await new Promise(resolve => setTimeout(resolve, 300));
    return { ...distributionData, id: parseInt(id) };
  },

  delete: async (id) => {
    await new Promise(resolve => setTimeout(resolve, 300));
    return { success: true };
  },

  markAsCompleted: async (id) => {
    await new Promise(resolve => setTimeout(resolve, 300));
    return { id: parseInt(id), status: 'Completed' };
  },

  getStatistics: async () => {
    await new Promise(resolve => setTimeout(resolve, 300));
    return mockDistributionStats;
  }
};

// Service mock pour les stocks
export const mockStockService = {
  getAll: async (page = 1, limit = 10, search = '') => {
    await new Promise(resolve => setTimeout(resolve, 300));
    // Simuler la pagination et la recherche si nécessaire
    return mockStocks;
  },

  getById: async (id) => {
    await new Promise(resolve => setTimeout(resolve, 300));
    const stock = mockStocks.results.find(s => s.id === parseInt(id));
    if (!stock) {
      throw new Error('Produit non trouvé');
    }
    return stock;
  },

  create: async (productData) => {
    await new Promise(resolve => setTimeout(resolve, 300));
    return { ...productData, id: Math.floor(Math.random() * 1000) + 100 };
  },

  update: async (id, productData) => {
    await new Promise(resolve => setTimeout(resolve, 300));
    return { ...productData, id: parseInt(id) };
  },

  delete: async (id) => {
    await new Promise(resolve => setTimeout(resolve, 300));
    return { success: true };
  },

  adjustQuantity: async (id, quantity, reason) => {
    await new Promise(resolve => setTimeout(resolve, 300));
    return { id: parseInt(id), quantity, success: true };
  },

  getStockHistory: async (page = 1, limit = 10) => {
    await new Promise(resolve => setTimeout(resolve, 300));
    // Simuler l'historique
    return {
      count: 3,
      results: mockStockStats.movements.map((m, index) => ({
        id: index + 1,
        date: m.date,
        product_name: mockStocks.results[index % mockStocks.results.length].name,
        quantity_change: m.in - m.out,
        reason: m.in > m.out ? 'Approvisionnement' : 'Distribution',
        user: 'Admin'
      }))
    };
  },

  getStatistics: async () => {
    await new Promise(resolve => setTimeout(resolve, 300));
    return mockStockStats;
  }
};

// Service mock pour les rapports
export const mockReportService = {
  // Méthodes pour récupérer les données de rapport (simulées)
  getRefugeeReports: async (startDate, endDate, reportType) => {
    await new Promise(resolve => setTimeout(resolve, 300));
    console.log(`Récupération des rapports réfugiés: ${startDate} à ${endDate}, type: ${reportType}`);
    // Retourner des données similaires à mockRefugeeStats mais potentiellement filtrées/agrégées
    return {
      timeline: mockRefugeeStats.byAgeGroup.map((g, i) => ({ period: `Mois ${i+1}`, count: Math.floor(Math.random() * 5 + 5) })), // Données temporelles factices
      nationalities: mockRefugeeStats.byNationality,
      ageGroups: mockRefugeeStats.byAgeGroup,
      genderDistribution: mockRefugeeStats.byGender
    };
  },

  getDistributionReports: async (startDate, endDate, reportType) => {
    await new Promise(resolve => setTimeout(resolve, 300));
    console.log(`Récupération des rapports distributions: ${startDate} à ${endDate}, type: ${reportType}`);
    return {
      timeline: mockDistributionStats.byMonth.map(m => ({ period: m.month, count: m.count })), // Données temporelles factices
      topItems: mockDistributionStats.topItems
    };
  },

  getStockReports: async (startDate, endDate) => {
    await new Promise(resolve => setTimeout(resolve, 300));
    console.log(`Récupération des rapports stocks: ${startDate} à ${endDate}`);
    return {
      movements: mockStockStats.movements.map(m => ({ period: m.date, in: m.in, out: m.out })) // Données temporelles factices
    };
  },

  // Méthodes pour exporter les rapports (simulées)
  exportRefugeeReport: async (startDate, endDate, reportType) => {
    await new Promise(resolve => setTimeout(resolve, 300));
    console.log(`Exportation rapport réfugiés: ${startDate} à ${endDate}, type: ${reportType}`);
    return `/mock-reports/refugees-${reportType}-${Date.now()}.pdf`;
  },

  exportDistributionReport: async (startDate, endDate, reportType) => {
    await new Promise(resolve => setTimeout(resolve, 300));
    console.log(`Exportation rapport distributions: ${startDate} à ${endDate}, type: ${reportType}`);
    return `/mock-reports/distributions-${reportType}-${Date.now()}.pdf`;
  },

  exportStockReport: async (startDate, endDate) => {
    await new Promise(resolve => setTimeout(resolve, 300));
    console.log(`Exportation rapport stocks: ${startDate} à ${endDate}`);
    return `/mock-reports/stock-${Date.now()}.pdf`;
  },
  generateReport: async (reportType, params) => {
    await new Promise(resolve => setTimeout(resolve, 300));
    console.log(`Génération du rapport de type ${reportType} avec les paramètres:`, params);
    // Simuler la génération d'un rapport
    return { success: true, message: `Rapport ${reportType} généré avec succès.`, reportUrl: `/mock-reports/${reportType}-${Date.now()}.pdf` };
  },

  getReportTypes: async () => {
    await new Promise(resolve => setTimeout(resolve, 300));
    return [
      { id: 'refugee_summary', name: 'Résumé des Réfugiés' },
      { id: 'distribution_activity', name: 'Activité de Distribution' },
      { id: 'stock_inventory', name: 'Inventaire des Stocks' },
    ];
  },

  getReportHistory: async (page = 1, limit = 10) => {
    await new Promise(resolve => setTimeout(resolve, 300));
    // Simuler l'historique des rapports
    return {
      count: 5,
      results: [
        { id: 1, report_type: 'Résumé des Réfugiés', generated_at: '2023-05-10T10:00:00Z', generated_by: 'Admin', status: 'Completed', download_url: '/mock-reports/refugee_summary-1683712800000.pdf' },
        { id: 2, report_type: 'Activité de Distribution', generated_at: '2023-05-09T15:30:00Z', generated_by: 'Admin', status: 'Completed', download_url: '/mock-reports/distribution_activity-1683646200000.pdf' },
        { id: 3, report_type: 'Inventaire des Stocks', generated_at: '2023-05-08T09:00:00Z', generated_by: 'Admin', status: 'Failed', download_url: null },
      ]
    };
  }
};