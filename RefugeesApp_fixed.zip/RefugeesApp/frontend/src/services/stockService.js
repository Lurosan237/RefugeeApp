import axios from 'axios';

const API_URL = '/api/stocks';

// Configuration de l'intercepteur pour ajouter le token JWT à chaque requête
axios.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token');
    if (token) {
      config.headers['Authorization'] = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Service pour gérer les opérations liées aux stocks
const stockService = {
  // Récupérer tous les produits en stock avec pagination
  getAll: async (page = 1, limit = 10, search = '') => {
    try {
      const response = await axios.get(`${API_URL}/?page=${page}&limit=${limit}&search=${search}`);
      return response.data;
    } catch (error) {
      throw error;
    }
  },

  // Récupérer un produit par son ID
  getById: async (id) => {
    try {
      const response = await axios.get(`${API_URL}/${id}/`);
      return response.data;
    } catch (error) {
      throw error;
    }
  },

  // Ajouter un nouveau produit au stock
  create: async (productData) => {
    try {
      const response = await axios.post(`${API_URL}/`, productData);
      return response.data;
    } catch (error) {
      throw error;
    }
  },

  // Mettre à jour un produit existant
  update: async (id, productData) => {
    try {
      const response = await axios.put(`${API_URL}/${id}/`, productData);
      return response.data;
    } catch (error) {
      throw error;
    }
  },

  // Supprimer un produit
  delete: async (id) => {
    try {
      const response = await axios.delete(`${API_URL}/${id}/`);
      return response.data;
    } catch (error) {
      throw error;
    }
  },

  // Ajuster la quantité d'un produit
  adjustQuantity: async (id, quantity, reason) => {
    try {
      const response = await axios.patch(`${API_URL}/${id}/adjust/`, {
        quantity,
        reason
      });
      return response.data;
    } catch (error) {
      throw error;
    }
  },

  // Récupérer l'historique des mouvements de stock
  getStockHistory: async (page = 1, limit = 10) => {
    try {
      const response = await axios.get(`${API_URL}/history/?page=${page}&limit=${limit}`);
      return response.data;
    } catch (error) {
      throw error;
    }
  },

  // Récupérer les statistiques des stocks
  getStatistics: async () => {
    try {
      const response = await axios.get(`${API_URL}/statistics/`);
      return response.data;
    } catch (error) {
      throw error;
    }
  }
};

export default stockService;