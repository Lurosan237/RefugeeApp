// Données fictives pour simuler les réponses API pendant le développement

// Données pour les réfugiés
export const mockRefugees = {
  count: 25,
  results: [
    {
      id: 1,
      registration_number: 'REF-2023-001',
      first_name: 'Jean',
      last_name: 'Dupont',
      gender: 'M',
      date_of_birth: '1985-05-15',
      nationality: 'Syrie',
      arrival_date: '2023-01-10',
      status: 'Active',
      phone_number: '+33612345678',
      email: 'jean.dupont@example.com',
      address: '15 Rue de la Paix, Paris',
      family_size: 3,
      special_needs: '',
      notes: 'Parle français et arabe'
    },
    {
      id: 2,
      registration_number: 'REF-2023-002',
      first_name: 'Marie',
      last_name: 'Laurent',
      gender: 'F',
      date_of_birth: '1990-08-22',
      nationality: 'Ukraine',
      arrival_date: '2023-02-15',
      status: 'Active',
      phone_number: '+33623456789',
      email: 'marie.laurent@example.com',
      address: '8 Avenue Victor Hugo, Lyon',
      family_size: 2,
      special_needs: 'Besoin d\'un interprète',
      notes: 'Parle ukrainien et anglais'
    },
    {
      id: 3,
      registration_number: 'REF-2023-003',
      first_name: 'Ahmed',
      last_name: 'Khalid',
      gender: 'M',
      date_of_birth: '1978-11-30',
      nationality: 'Afghanistan',
      arrival_date: '2023-03-05',
      status: 'Inactive',
      phone_number: '+33634567890',
      email: 'ahmed.khalid@example.com',
      address: '22 Rue des Fleurs, Marseille',
      family_size: 5,
      special_needs: 'Problèmes de santé',
      notes: 'Famille avec 3 enfants'
    }
  ]
};

// Statistiques des réfugiés
export const mockRefugeeStats = {
  total: 25,
  active: 18,
  inactive: 7,
  byNationality: [
    { nationality: 'Syrie', count: 8 },
    { nationality: 'Ukraine', count: 7 },
    { nationality: 'Afghanistan', count: 5 },
    { nationality: 'Érythrée', count: 3 },
    { nationality: 'Autres', count: 2 }
  ],
  byGender: [
    { gender: 'M', count: 14 },
    { gender: 'F', count: 11 }
  ],
  byAgeGroup: [
    { ageGroup: '0-18', count: 6 },
    { ageGroup: '19-35', count: 10 },
    { ageGroup: '36-50', count: 7 },
    { ageGroup: '51+', count: 2 }
  ]
};

// Données pour les distributions
export const mockDistributions = {
  count: 15,
  results: [
    {
      id: 1,
      distribution_date: '2023-04-15',
      status: 'Completed',
      location: 'Centre d\'accueil Paris',
      description: 'Distribution mensuelle de kits d\'hygiène',
      items: [
        { product_id: 1, product_name: 'Kit d\'hygiène', quantity: 50 },
        { product_id: 3, product_name: 'Couverture', quantity: 20 }
      ],
      beneficiaries_count: 45,
      notes: 'Distribution réussie'
    },
    {
      id: 2,
      distribution_date: '2023-05-01',
      status: 'Pending',
      location: 'Centre d\'accueil Lyon',
      description: 'Distribution de vêtements',
      items: [
        { product_id: 2, product_name: 'Vêtements (lot)', quantity: 30 },
        { product_id: 4, product_name: 'Chaussures (paire)', quantity: 15 }
      ],
      beneficiaries_count: 30,
      notes: 'En attente de confirmation'
    }
  ]
};

// Statistiques des distributions
export const mockDistributionStats = {
  total: 15,
  pending: 3,
  completed: 12,
  byMonth: [
    { month: 'Janvier', count: 2 },
    { month: 'Février', count: 2 },
    { month: 'Mars', count: 3 },
    { month: 'Avril', count: 4 },
    { month: 'Mai', count: 4 }
  ],
  topItems: [
    { item: 'Kit d\'hygiène', count: 250 },
    { item: 'Vêtements', count: 180 },
    { item: 'Couvertures', count: 120 },
    { item: 'Nourriture', count: 100 }
  ]
};

// Données pour les stocks
export const mockStocks = {
  count: 10,
  results: [
    {
      id: 1,
      name: 'Kit d\'hygiène',
      category: 'Hygiène',
      quantity: 150,
      unit: 'kit',
      threshold: 50,
      location: 'Entrepôt principal',
      last_updated: '2023-05-01'
    },
    {
      id: 2,
      name: 'Vêtements',
      category: 'Habillement',
      quantity: 80,
      unit: 'lot',
      threshold: 30,
      location: 'Entrepôt principal',
      last_updated: '2023-05-02'
    },
    {
      id: 3,
      name: 'Couverture',
      category: 'Literie',
      quantity: 45,
      unit: 'pièce',
      threshold: 50,
      location: 'Entrepôt secondaire',
      last_updated: '2023-05-03'
    },
    {
      id: 4,
      name: 'Chaussures',
      category: 'Habillement',
      quantity: 25,
      unit: 'paire',
      threshold: 30,
      location: 'Entrepôt principal',
      last_updated: '2023-05-03'
    }
  ]
};

// Statistiques des stocks
export const mockStockStats = {
  totalItems: 10,
  lowStock: 3,
  byCategory: [
    { category: 'Hygiène', count: 3 },
    { category: 'Habillement', count: 4 },
    { category: 'Literie', count: 2 },
    { category: 'Alimentation', count: 1 }
  ],
  movements: [
    { date: '2023-04-01', in: 50, out: 30 },
    { date: '2023-04-15', in: 40, out: 35 },
    { date: '2023-05-01', in: 60, out: 45 }
  ]
};