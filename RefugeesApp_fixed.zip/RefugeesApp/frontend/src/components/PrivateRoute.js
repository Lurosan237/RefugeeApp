import React from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import jwt_decode from 'jwt-decode';

const PrivateRoute = ({ children, roles }) => { // Ajouter la prop 'roles'
  const location = useLocation();
  console.log('[PrivateRoute] Checking authentication for path:', location.pathname, 'Required roles:', roles);
  
  // Vérifier si l'utilisateur est authentifié
  const isAuthenticated = () => {
    const token = localStorage.getItem('token');
    if (!token) {
      console.log('[PrivateRoute] No token found. User is not authenticated.');
      return false;
    }
    
    try {
      console.log('[PrivateRoute] Token found. Decoding token:', token);
      const decoded = jwt_decode(token);
      console.log('[PrivateRoute] Decoded token:', decoded);
      const currentTime = Date.now() / 1000;
      
      if (decoded.exp < currentTime) {
        console.warn('[PrivateRoute] Token has expired. Exp:', new Date(decoded.exp * 1000), 'Current:', new Date(currentTime * 1000));
        localStorage.removeItem('token');
        return false;
      }
      
      // Vérifier si l'utilisateur a le rôle requis
      if (roles && roles.length > 0) {
        console.log('[PrivateRoute] Checking roles. Required:', roles, 'User role:', decoded.role);
        if (!roles.includes(decoded.role)) {
          console.warn('[PrivateRoute] User does not have the required role. Access denied.');
          return false;
        }
        console.log('[PrivateRoute] User has the required role.');
      } else {
        console.log('[PrivateRoute] No specific roles required for this route.');
      }

      console.log('[PrivateRoute] User is authenticated and authorized.');
      return true;
    } catch (error) {
      console.error('[PrivateRoute] Error decoding token or token is invalid:', error);
      localStorage.removeItem('token');
      return false;
    }
  };

  const isAuth = isAuthenticated();
  console.log('[PrivateRoute] isAuthenticated result:', isAuth);

  // Rediriger vers la page de connexion si non authentifié
  if (!isAuth) {
    console.log('[PrivateRoute] Redirecting to /login.');
    return <Navigate to="/login" state={{ from: location }} replace />;
  }

  // Optionnel : Rediriger vers une page non autorisée si le rôle n'est pas correct
  // Pour l'instant, on retourne simplement null ou un message, mais une page dédiée serait mieux
  // Cette partie de la logique est déjà gérée dans isAuthenticated() avec la vérification des rôles.
  // Si isAuthenticated retourne false à cause du rôle, la redirection vers /login se fera.
  // Si on veut une page spécifique pour 'non autorisé' au lieu de 'login', il faudrait ajuster.

  // Si l'utilisateur est authentifié et a le bon rôle (vérifié dans isAuthenticated)
  console.log('[PrivateRoute] Rendering children for authenticated user.');
  return children;
};

export default PrivateRoute;