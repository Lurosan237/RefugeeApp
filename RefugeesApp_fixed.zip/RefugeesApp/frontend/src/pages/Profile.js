import React, { useState, useEffect } from 'react';
import {
  Container,
  Paper,
  Typography,
  Box,
  Grid,
  TextField,
  Button,
  CircularProgress,
  Alert,
  Avatar,
} from '@mui/material';
import { Save as SaveIcon } from '@mui/icons-material';
// Import du service d'authentification (à adapter selon votre implémentation)
// import authService from '../services/authService';

// Simuler un service d'authentification pour le développement
const mockAuthService = {
  getCurrentUser: async () => {
    await new Promise(resolve => setTimeout(resolve, 300));
    // Retourner des données utilisateur mock
    return {
      id: 1,
      username: 'admin_user',
      email: 'admin@example.com',
      firstName: 'Admin',
      lastName: 'User',
      role: 'Administrator',
      avatarUrl: '/static/images/avatar/1.jpg', // Chemin vers un avatar par défaut ou URL
    };
  },
  updateProfile: async (userId, profileData) => {
    await new Promise(resolve => setTimeout(resolve, 300));
    console.log('Updating profile for user:', userId, profileData);
    return { ...profileData };
  },
};

const authService = mockAuthService; // Utiliser le service mock

function Profile() {
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(false);
  const [user, setUser] = useState({
    username: '',
    email: '',
    firstName: '',
    lastName: '',
    avatarUrl: '',
  });

  useEffect(() => {
    const fetchUserData = async () => {
      try {
        setLoading(true);
        const currentUser = await authService.getCurrentUser();
        setUser(currentUser);
        setError(null);
      } catch (err) {
        setError('Erreur lors du chargement des informations utilisateur');
        console.error('Error fetching user data:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchUserData();
  }, []);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setUser({
      ...user,
      [name]: value,
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSaving(true);
    setError(null);
    setSuccess(false);

    try {
      const updatedUser = await authService.updateProfile(user.id, {
        firstName: user.firstName,
        lastName: user.lastName,
        email: user.email,
        // Ne pas envoyer le nom d'utilisateur ou le rôle pour la mise à jour du profil standard
      });
      setUser(prevUser => ({ ...prevUser, ...updatedUser }));
      setSuccess(true);
      setTimeout(() => setSuccess(false), 3000); // Masquer le message de succès après 3s
    } catch (err) {
      setError('Erreur lors de la mise à jour du profil');
      console.error('Error updating profile:', err);
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '80vh' }}>
        <CircularProgress />
      </Box>
    );
  }

  return (
    <Container maxWidth="md">
      <Box sx={{ mt: 4, mb: 4 }}>
        <Typography variant="h4" gutterBottom>
          Mon Profil
        </Typography>

        {error && (
          <Alert severity="error" sx={{ mb: 2 }}>
            {error}
          </Alert>
        )}
        {success && (
          <Alert severity="success" sx={{ mb: 2 }}>
            Profil mis à jour avec succès !
          </Alert>
        )}

        <Paper sx={{ p: 3 }}>
          <form onSubmit={handleSubmit}>
            <Grid container spacing={3} alignItems="center">
              <Grid item xs={12} sx={{ display: 'flex', justifyContent: 'center', mb: 2 }}>
                <Avatar
                  alt={`${user.firstName} ${user.lastName}`}
                  src={user.avatarUrl}
                  sx={{ width: 100, height: 100 }}
                />
                {/* Option pour changer l'avatar pourrait être ajoutée ici */}
              </Grid>
              <Grid item xs={12} md={6}>
                <TextField
                  fullWidth
                  label="Nom d'utilisateur"
                  name="username"
                  value={user.username}
                  disabled // Généralement non modifiable
                  variant="filled"
                />
              </Grid>
              <Grid item xs={12} md={6}>
                <TextField
                  fullWidth
                  label="Rôle"
                  name="role"
                  value={user.role}
                  disabled
                  variant="filled"
                />
              </Grid>
              <Grid item xs={12} md={6}>
                <TextField
                  fullWidth
                  label="Prénom"
                  name="firstName"
                  value={user.firstName}
                  onChange={handleChange}
                  required
                />
              </Grid>
              <Grid item xs={12} md={6}>
                <TextField
                  fullWidth
                  label="Nom"
                  name="lastName"
                  value={user.lastName}
                  onChange={handleChange}
                  required
                />
              </Grid>
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  label="Email"
                  name="email"
                  type="email"
                  value={user.email}
                  onChange={handleChange}
                  required
                />
              </Grid>
              {/* Section pour changer le mot de passe (optionnel) */}
              {/* ... */}
              <Grid item xs={12} sx={{ display: 'flex', justifyContent: 'flex-end' }}>
                <Button
                  type="submit"
                  variant="contained"
                  color="primary"
                  disabled={saving}
                  startIcon={saving ? <CircularProgress size={20} /> : <SaveIcon />}
                >
                  {saving ? 'Enregistrement...' : 'Enregistrer les modifications'}
                </Button>
              </Grid>
            </Grid>
          </form>
        </Paper>
      </Box>
    </Container>
  );
}

export default Profile;