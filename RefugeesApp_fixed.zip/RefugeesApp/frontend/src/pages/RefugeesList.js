import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Container,
  Paper,
  Typography,
  Box,
  Button,
  TextField,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TablePagination,
  IconButton,
  Chip,
  InputAdornment,
  CircularProgress,
  Dialog,
  DialogActions,
  DialogContent,
  DialogContentText,
  DialogTitle,
} from '@mui/material';
import {
  Add as AddIcon,
  Search as SearchIcon,
  Edit as EditIcon,
  Delete as DeleteIcon,
  Visibility as VisibilityIcon,
} from '@mui/icons-material';
// Import du service réel (commenté pendant le développement sans backend)
// import refugeeService from '../services/refugeeService';

// Import du service mock pour le développement sans backend
import refugeeService from '../services/refugeeService';

function RefugeesList() {
  const navigate = useNavigate();
  const [refugees, setRefugees] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(10);
  const [totalCount, setTotalCount] = useState(0);
  const [searchTerm, setSearchTerm] = useState('');
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [refugeeToDelete, setRefugeeToDelete] = useState(null);

  // Utilisation de useCallback pour mémoriser fetchRefugees
  const fetchRefugees = React.useCallback(async (pageNum = page, limit = rowsPerPage, search = searchTerm) => {
    try {
      setLoading(true);
      const data = await refugeeService.getAll(pageNum + 1, limit, search);
      
      // Validate data structure
      if (!data) {
        throw new Error('Aucune donnée reçue du serveur');
      }

      // Ensure data.results is an array, if not use empty array
      const results = Array.isArray(data.results) ? data.results : [];
      const count = typeof data.count === 'number' ? data.count : 0;

      setRefugees(results);
      setTotalCount(count);
      setError(null);

    } catch (err) {
      console.error('Error fetching refugees:', err);
      setRefugees([]);
      setTotalCount(0);
      const errorMessage = err.response?.data?.detail || err.message || 'Erreur lors du chargement des réfugiés.';
      setError(errorMessage);
    } finally {
      setLoading(false);
    }
  }, [page, rowsPerPage, searchTerm]); // Ajout des dépendances pour useCallback

  useEffect(() => {
    fetchRefugees();
  }, [fetchRefugees]); // Ajout de fetchRefugees comme dépendance

  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  const handleSearch = (e) => {
    e.preventDefault();
    setPage(0);
    fetchRefugees(0, rowsPerPage, searchTerm);
  };

  const handleViewRefugee = (id) => {
    navigate(`/refugees/${id}`);
  };

  const handleEditRefugee = (id) => {
    navigate(`/refugees/${id}`);
  };

  const handleDeleteClick = (refugee) => {
    setRefugeeToDelete(refugee);
    setDeleteDialogOpen(true);
  };

  const handleDeleteConfirm = async () => {
    if (!refugeeToDelete) return;

    try {
      await refugeeService.delete(refugeeToDelete.id);
      fetchRefugees();
      setDeleteDialogOpen(false);
      setRefugeeToDelete(null);
    } catch (err) {
      setError('Erreur lors de la suppression du réfugié');
      console.error('Error deleting refugee:', err);
    }
  };

  const handleDeleteCancel = () => {
    setDeleteDialogOpen(false);
    setRefugeeToDelete(null);
  };

  const getStatusChip = (status) => {
    let color = 'default';
    switch (status) {
      case 'Active':
        color = 'success';
        break;
      case 'Inactive':
        color = 'error';
        break;
      case 'Pending':
        color = 'warning';
        break;
      default:
        color = 'default';
    }
    return <Chip label={status} color={color} size="small" />;
  };

  return (
    <Container maxWidth="lg">
      <Box sx={{ mt: 4, mb: 4 }}>
        <Typography variant="h4" gutterBottom>
          Gestion des Réfugiés
        </Typography>
        <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 2 }}>
          <form onSubmit={handleSearch}>
            <TextField
              variant="outlined"
              size="small"
              placeholder="Rechercher..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              InputProps={{
                startAdornment: (
                  <InputAdornment position="start">
                    <SearchIcon />
                  </InputAdornment>
                ),
              }}
            />
          </form>
          <Button
            variant="contained"
            color="primary"
            startIcon={<AddIcon />}
            onClick={() => navigate('/refugees/new')}
          >
            Nouveau Réfugié
          </Button>
        </Box>

        {error && (
          <Typography color="error" sx={{ mb: 2 }}>
            {error}
          </Typography>
        )}

        <Paper sx={{ width: '100%', overflow: 'hidden' }}>
          {loading ? (
            <Box sx={{ display: 'flex', justifyContent: 'center', p: 3 }}>
              <CircularProgress />
            </Box>
          ) : (
            <>
              <TableContainer sx={{ maxHeight: 440 }}>
                <Table stickyHeader aria-label="sticky table">
                  <TableHead>
                    <TableRow>
                      <TableCell>Numéro d'enregistrement</TableCell>
                      <TableCell>Nom</TableCell>
                      <TableCell>Prénom</TableCell>
                      <TableCell>Nationalité</TableCell>
                      <TableCell>Date d'arrivée</TableCell>
                      <TableCell>Statut</TableCell>
                      <TableCell align="right">Actions</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {refugees.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={7} align="center">
                          Aucun réfugié trouvé
                        </TableCell>
                      </TableRow>
                    ) : (
                      refugees.map((refugee) => (
                        <TableRow hover key={refugee.id}>
                          <TableCell>{refugee.registration_number}</TableCell>
                          <TableCell>{refugee.last_name}</TableCell>
                          <TableCell>{refugee.first_name}</TableCell>
                          <TableCell>{refugee.nationality}</TableCell>
                          <TableCell>
                            {new Date(refugee.arrival_date).toLocaleDateString()}
                          </TableCell>
                          <TableCell>{getStatusChip(refugee.status)}</TableCell>
                          <TableCell align="right">
                            <IconButton
                              color="primary"
                              onClick={() => handleViewRefugee(refugee.id)}
                              size="small"
                            >
                              <VisibilityIcon fontSize="small" />
                            </IconButton>
                            <IconButton
                              color="secondary"
                              onClick={() => handleEditRefugee(refugee.id)}
                              size="small"
                            >
                              <EditIcon fontSize="small" />
                            </IconButton>
                            <IconButton
                              color="error"
                              onClick={() => handleDeleteClick(refugee)}
                              size="small"
                            >
                              <DeleteIcon fontSize="small" />
                            </IconButton>
                          </TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </TableContainer>
              <TablePagination
                rowsPerPageOptions={[5, 10, 25]}
                component="div"
                count={totalCount}
                rowsPerPage={rowsPerPage}
                page={page}
                onPageChange={handleChangePage}
                onRowsPerPageChange={handleChangeRowsPerPage}
                labelRowsPerPage="Lignes par page:"
              />
            </>
          )}
        </Paper>
      </Box>

      {/* Dialogue de confirmation de suppression */}
      <Dialog
        open={deleteDialogOpen}
        onClose={handleDeleteCancel}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description"
      >
        <DialogTitle id="alert-dialog-title">
          Confirmer la suppression
        </DialogTitle>
        <DialogContent>
          <DialogContentText id="alert-dialog-description">
            Êtes-vous sûr de vouloir supprimer ce réfugié ? Cette action est irréversible.
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleDeleteCancel}>Annuler</Button>
          <Button onClick={handleDeleteConfirm} color="error" autoFocus>
            Supprimer
          </Button>
        </DialogActions>
      </Dialog>
    </Container>
  );
}

export default RefugeesList;