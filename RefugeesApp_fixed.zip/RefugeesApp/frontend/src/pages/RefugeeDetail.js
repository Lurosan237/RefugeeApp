import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import {
  Container,
  Paper,
  Typography,
  Box,
  Grid,
  TextField,
  Button,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Divider,
  CircularProgress,
  Alert,
  Snackbar,
  IconButton,
} from '@mui/material';
import { ArrowBack as ArrowBackIcon, Save as SaveIcon } from '@mui/icons-material';
import { AdapterDateFns } from '@mui/x-date-pickers/AdapterDateFns';
import { LocalizationProvider, DatePicker } from '@mui/x-date-pickers';
// Import du service réel (commenté pendant le développement sans backend)
// import refugeeService from '../services/refugeeService';

// Import du service mock pour le développement sans backend
import refugeeService from '../services/refugeeService';

function RefugeeDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const isNewRefugee = id === 'new';
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(false);
  const [refugee, setRefugee] = useState({
    first_name: '',
    last_name: '',
    registration_number: '',
    gender: '',
    date_of_birth: null,
    nationality: '',
    arrival_date: new Date(),
    status: 'Active',
    phone_number: '',
    email: '',
    address: '',
    family_size: 1,
    special_needs: '',
    notes: '',
  });

  useEffect(() => {
    const fetchRefugee = async () => {
      if (isNewRefugee) {
        setLoading(false);
        return;
      }

      try {
        setLoading(true);
        const data = await refugeeService.getById(id);
        setRefugee({
          ...data,
          date_of_birth: data.date_of_birth ? new Date(data.date_of_birth) : null,
          arrival_date: new Date(data.arrival_date),
        });
        setError(null);
      } catch (err) {
        setError('Erreur lors du chargement des données du réfugié');
        console.error('Error fetching refugee:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchRefugee();
  }, [id, isNewRefugee]);

  const validateInput = (name, value) => {
    switch (name) {
      case 'phone_number':
        return /^\+?[\d\s-]{8,}$/.test(value) || value === '';
      case 'email':
        return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value) || value === '';
      case 'family_size':
        return parseInt(value) >= 1;
      default:
        return true;
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    
    if (!validateInput(name, value)) {
      setError(`Format invalide pour ${name}`);
      return;
    }
    
    setError(null);
    setRefugee(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleDateOfBirthChange = (newDate) => {
    if (newDate && newDate > new Date()) {
      setError('La date de naissance ne peut pas être dans le futur');
      return;
    }
    
    setError(null);
    setRefugee(prev => ({
      ...prev,
      date_of_birth: newDate
    }));
  };

  const handleArrivalDateChange = (newDate) => {
    if (newDate && newDate > new Date()) {
      setError('La date d\'arrivée ne peut pas être dans le futur');
      return;
    }
    
    setError(null);
    setRefugee(prev => ({
      ...prev,
      arrival_date: newDate
    }));
  };

  // Add data validation helper
  const validateData = (data) => {
    const errors = [];
    
    // Required fields validation
    const requiredFields = [
      { key: 'first_name', label: 'Prénom' },
      { key: 'last_name', label: 'Nom' },
      { key: 'registration_number', label: 'Numéro d\'enregistrement' },
      { key: 'gender', label: 'Genre' },
      { key: 'nationality', label: 'Nationalité' }
    ];
  
    requiredFields.forEach(field => {
      if (!data[field.key] || data[field.key].trim() === '') {
        errors.push(`Le champ "${field.label}" est requis`);
      }
    });
  
    // Date validations
    if (data.date_of_birth && new Date(data.date_of_birth) > new Date()) {
      errors.push('La date de naissance ne peut pas être dans le futur');
    }
  
    if (data.arrival_date && new Date(data.arrival_date) > new Date()) {
      errors.push('La date d\'arrivée ne peut pas être dans le futur');
    }
  
    // Format validations
    if (data.phone_number && !/^\+?[\d\s-]{8,}$/.test(data.phone_number)) {
      errors.push('Le format du numéro de téléphone est invalide');
    }
  
    if (data.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email)) {
      errors.push('Le format de l\'email est invalide');
    }
  
    if (data.family_size && (isNaN(data.family_size) || data.family_size < 1)) {
      errors.push('La taille de la famille doit être un nombre positif');
    }
  
    return errors;
  };

  // Update handleSubmit function with better error handling
  const handleSubmit = async (e) => {
    e.preventDefault();
    setSaving(true);
    setError(null);
  
    try {
      // Validate data
      const validationErrors = validateData(refugee);
      if (validationErrors.length > 0) {
        throw new Error(validationErrors.join('\n'));
      }
  
      // Format dates properly before sending
      const formattedData = {
        ...refugee,
        date_of_birth: refugee.date_of_birth ? refugee.date_of_birth.toISOString().split('T')[0] : null,
        arrival_date: refugee.arrival_date.toISOString().split('T')[0]
      };
  
      // Log the data being sent
      console.log('Sending refugee data:', formattedData);
  
      // Perform save operation
      if (isNewRefugee) {
        await refugeeService.create(formattedData);
      } else {
        await refugeeService.update(id, formattedData);
      }
  
      setSuccess(true);
      
      // Navigate after success message
      setTimeout(() => {
        navigate('/refugees');
      }, 1500);
  
    } catch (err) {
      console.error('Full error object:', err);
      let errorMessage;
      
      if (err.response) {
        // Server responded with error
        if (err.response.status === 500) {
          errorMessage = 'Erreur serveur interne. Veuillez réessayer plus tard.';
        } else if (err.response.data) {
          // Try to get detailed error message from response
          errorMessage = typeof err.response.data === 'object' 
            ? Object.entries(err.response.data)
                .map(([key, value]) => `${key}: ${value}`)
                .join('\n')
            : err.response.data.detail || err.response.data || 'Erreur lors de la sauvegarde';
        }
      } else if (err.request) {
        // Request was made but no response
        errorMessage = 'Impossible de contacter le serveur. Vérifiez votre connexion.';
      } else {
        // Error in request setup
        errorMessage = err.message || 'Erreur lors de l\'enregistrement du réfugié';
      }
      
      setError(errorMessage);
      setSuccess(false);
      console.error('Error saving refugee:', {
        status: err.response?.status,
        data: err.response?.data,
        message: errorMessage
      });
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '80vh' }}>
        <CircularProgress />
      </Box>
    );
  }

  return (
    <Container maxWidth="lg">
      <Box sx={{ mt: 4, mb: 4 }}>
        <Box sx={{ display: 'flex', alignItems: 'center', mb: 3 }}>
          <IconButton onClick={() => navigate('/refugees')} sx={{ mr: 2 }}>
            <ArrowBackIcon />
          </IconButton>
          <Typography variant="h4">
            {isNewRefugee ? 'Nouveau Réfugié' : 'Modifier Réfugié'}
          </Typography>
        </Box>

        {error && (
          <Alert 
            severity="error" 
            sx={{ mb: 2 }}
          >
            {error.split('\n').map((line, index) => (
              <div key={index}>{line}</div>
            ))}
          </Alert>
        )}

        <Paper sx={{ p: 3 }}>
          <form onSubmit={handleSubmit}>
            <Grid container spacing={3}>
              <Grid item xs={12} md={6}>
                <TextField
                  fullWidth
                  label="Prénom"
                  name="first_name"
                  value={refugee.first_name}
                  onChange={handleChange}
                  required
                />
              </Grid>
              <Grid item xs={12} md={6}>
                <TextField
                  fullWidth
                  label="Nom"
                  name="last_name"
                  value={refugee.last_name}
                  onChange={handleChange}
                  required
                />
              </Grid>
              <Grid item xs={12} md={6}>
                <TextField
                  fullWidth
                  label="Numéro d'enregistrement"
                  name="registration_number"
                  value={refugee.registration_number}
                  onChange={handleChange}
                  required
                  disabled={!isNewRefugee}
                  helperText={!isNewRefugee ? "Le numéro d'enregistrement ne peut pas être modifié" : ""}
                />
              </Grid>
              <Grid item xs={12} md={6}>
                <FormControl fullWidth>
                  <InputLabel>Genre</InputLabel>
                  <Select
                    name="gender"
                    value={refugee.gender}
                    onChange={handleChange}
                    label="Genre"
                    required
                  >
                    <MenuItem value="M">Masculin</MenuItem>
                    <MenuItem value="F">Féminin</MenuItem>
                    <MenuItem value="O">Autre</MenuItem>
                  </Select>
                </FormControl>
              </Grid>
              <Grid item xs={12} md={6}>
                <LocalizationProvider dateAdapter={AdapterDateFns}>
                  <DatePicker
                    label="Date de naissance"
                    value={refugee.date_of_birth}
                    onChange={handleDateOfBirthChange}
                    renderInput={(params) => <TextField {...params} fullWidth />}
                  />
                </LocalizationProvider>
              </Grid>
              <Grid item xs={12} md={6}>
                <TextField
                  fullWidth
                  label="Nationalité"
                  name="nationality"
                  value={refugee.nationality}
                  onChange={handleChange}
                  required
                />
              </Grid>
              <Grid item xs={12} md={6}>
                <LocalizationProvider dateAdapter={AdapterDateFns}>
                  <DatePicker
                    label="Date d'arrivée"
                    value={refugee.arrival_date}
                    onChange={handleArrivalDateChange}
                    renderInput={(params) => <TextField {...params} fullWidth required />}
                  />
                </LocalizationProvider>
              </Grid>
              <Grid item xs={12} md={6}>
                <FormControl fullWidth>
                  <InputLabel>Statut</InputLabel>
                  <Select
                    name="status"
                    value={refugee.status}
                    onChange={handleChange}
                    label="Statut"
                    required
                  >
                    <MenuItem value="Active">Actif</MenuItem>
                    <MenuItem value="Inactive">Inactif</MenuItem>
                    <MenuItem value="Pending">En attente</MenuItem>
                  </Select>
                </FormControl>
              </Grid>

              <Grid item xs={12}>
                <Divider sx={{ my: 2 }} />
                <Typography variant="h6" gutterBottom>
                  Informations de contact
                </Typography>
              </Grid>

              <Grid item xs={12} md={6}>
                <TextField
                  fullWidth
                  label="Numéro de téléphone"
                  name="phone_number"
                  value={refugee.phone_number}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item xs={12} md={6}>
                <TextField
                  fullWidth
                  label="Email"
                  name="email"
                  type="email"
                  value={refugee.email}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  label="Adresse"
                  name="address"
                  value={refugee.address}
                  onChange={handleChange}
                  multiline
                  rows={2}
                />
              </Grid>

              <Grid item xs={12}>
                <Divider sx={{ my: 2 }} />
                <Typography variant="h6" gutterBottom>
                  Informations supplémentaires
                </Typography>
              </Grid>

              <Grid item xs={12} md={6}>
                <TextField
                  fullWidth
                  label="Taille de la famille"
                  name="family_size"
                  type="number"
                  value={refugee.family_size}
                  onChange={handleChange}
                  InputProps={{ inputProps: { min: 1 } }}
                />
              </Grid>
              <Grid item xs={12} md={6}>
                <TextField
                  fullWidth
                  label="Besoins spéciaux"
                  name="special_needs"
                  value={refugee.special_needs}
                  onChange={handleChange}
                  multiline
                  rows={2}
                />
              </Grid>
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  label="Notes"
                  name="notes"
                  value={refugee.notes}
                  onChange={handleChange}
                  multiline
                  rows={3}
                />
              </Grid>
            </Grid>

            <Box sx={{ display: 'flex', justifyContent: 'flex-end', mt: 3 }}>
              <Button
                variant="contained"
                color="primary"
                type="submit"
                disabled={saving}
                startIcon={<SaveIcon />}
                sx={{ ml: 1 }}
              >
                {saving ? 'Enregistrement...' : 'Enregistrer'}
              </Button>
            </Box>
          </form>
        </Paper>
      </Box>

      <Snackbar
        open={success}
        autoHideDuration={6000}
        onClose={() => setSuccess(false)}
      >
        <Alert severity="success" sx={{ width: '100%' }}>
          Réfugié enregistré avec succès!
        </Alert>
      </Snackbar>
    </Container>
  );
}

export default RefugeeDetail;