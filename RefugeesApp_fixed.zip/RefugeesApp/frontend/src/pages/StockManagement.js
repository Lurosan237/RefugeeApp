import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Container,
  Paper,
  Typography,
  Box,
  Button,
  TextField,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TablePagination,
  IconButton,
  Chip,
  InputAdornment,
  CircularProgress,
  Dialog,
  DialogActions,
  DialogContent,
  DialogContentText,
  DialogTitle,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Grid,
} from '@mui/material';
import {
  Add as AddIcon,
  Search as SearchIcon,
  Edit as EditIcon,
  Delete as DeleteIcon,
  // Warning as WarningIcon, // Supprimé car non utilisé
  Add as PlusIcon,
  // Remove as MinusIcon, // Supprimé car non utilisé (PlusIcon est utilisé pour l'ajustement)
} from '@mui/icons-material';
// Import du service réel (commenté pendant le développement sans backend)
// import stockService from '../services/stockService';

// Import du service mock pour le développement sans backend
import stockService from '../services/stockService';

function StockManagement() {
  const navigate = useNavigate();
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(10);
  const [totalCount, setTotalCount] = useState(0);
  const [searchTerm, setSearchTerm] = useState('');
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [productToDelete, setProductToDelete] = useState(null);
  const [adjustDialogOpen, setAdjustDialogOpen] = useState(false);
  const [productToAdjust, setProductToAdjust] = useState(null);
  const [adjustQuantity, setAdjustQuantity] = useState(0);
  const [adjustReason, setAdjustReason] = useState('');
  const [adjustmentType, setAdjustmentType] = useState('add');
  const [newProductDialogOpen, setNewProductDialogOpen] = useState(false);
  const [newProduct, setNewProduct] = useState({
    name: '',
    category: '',
    quantity: 0,
    unit: '',
    threshold: 0,
    description: '',
  });

  // Utilisation de useCallback pour mémoriser fetchProducts
  const fetchProducts = React.useCallback(async (pageNum = page, limit = rowsPerPage, search = searchTerm) => {
    try {
      setLoading(true);
      const data = await stockService.getAll(pageNum + 1, limit, search);

      if (data && Array.isArray(data.results) && typeof data.count === 'number') {
        // Case 1: Standard paginated response
        setProducts(data.results);
        setTotalCount(data.count);
        setError(null);
      } else if (Array.isArray(data)) {
        // Case 2: Simple array response
        setProducts(data);
        setTotalCount(data.length); // Assuming total count is array length if not paginated
        setError(null);
      } else {
        // Case 3: Unrecognized format
        console.error('StockManagement: Invalid data structure received from API:', data);
        setProducts([]);
        setTotalCount(0);
        setError('Format de données invalide reçu du serveur.');
      }
    } catch (err) {
      console.error('Error fetching products:', err);
      setProducts([]);
      setTotalCount(0);
      const errorMessage = err.response?.data?.detail || 'Erreur lors du chargement des produits.';
      setError(errorMessage);
    } finally {
      setLoading(false);
    }
  }, [page, rowsPerPage, searchTerm]); // Ajout des dépendances pour useCallback

  useEffect(() => {
    fetchProducts();
  }, [fetchProducts]); // Ajout de fetchProducts comme dépendance

  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  const handleSearch = (e) => {
    e.preventDefault();
    setPage(0);
    fetchProducts(0, rowsPerPage, searchTerm);
  };

  const handleDeleteClick = (product) => {
    setProductToDelete(product);
    setDeleteDialogOpen(true);
  };

  const handleDeleteConfirm = async () => {
    if (!productToDelete) return;

    try {
      await stockService.delete(productToDelete.id);
      fetchProducts();
      setDeleteDialogOpen(false);
      setProductToDelete(null);
    } catch (err) {
      setError('Erreur lors de la suppression du produit');
      console.error('Error deleting product:', err);
    }
  };

  const handleDeleteCancel = () => {
    setDeleteDialogOpen(false);
    setProductToDelete(null);
  };

  const handleAdjustClick = (product) => {
    setProductToAdjust(product);
    setAdjustQuantity(0);
    setAdjustReason('');
    setAdjustmentType('add');
    setAdjustDialogOpen(true);
  };

  const handleAdjustConfirm = async () => {
    if (!productToAdjust || adjustQuantity <= 0) return;

    try {
      const finalQuantity = adjustmentType === 'add' ? adjustQuantity : -adjustQuantity;
      await stockService.adjustQuantity(productToAdjust.id, finalQuantity, adjustReason);
      fetchProducts();
      setAdjustDialogOpen(false);
      setProductToAdjust(null);
      setAdjustQuantity(0);
      setAdjustReason('');
    } catch (err) {
      setError('Erreur lors de l\'ajustement du stock');
      console.error('Error adjusting stock:', err);
    }
  };

  const handleAdjustCancel = () => {
    setAdjustDialogOpen(false);
    setProductToAdjust(null);
    setAdjustQuantity(0);
    setAdjustReason('');
  };

  const handleNewProductClick = () => {
    setNewProduct({
      name: '',
      category: '',
      quantity: 0,
      unit: '',
      threshold: 0,
      description: '',
    });
    setNewProductDialogOpen(true);
  };

  const handleNewProductChange = (e) => {
    const { name, value } = e.target;
    setNewProduct({
      ...newProduct,
      [name]: name === 'quantity' || name === 'threshold' ? Number(value) : value,
    });
  };

  const handleNewProductConfirm = async () => {
    try {
      await stockService.create(newProduct);
      fetchProducts();
      setNewProductDialogOpen(false);
    } catch (err) {
      setError('Erreur lors de la création du produit');
      console.error('Error creating product:', err);
    }
  };

  const handleNewProductCancel = () => {
    setNewProductDialogOpen(false);
  };

  const getStockStatusChip = (product) => {
    if (!product || typeof product.quantity !== 'number' || typeof product.threshold !== 'number') {
      // console.warn('StockManagement: Invalid product data for chip:', product); // Optional for debugging
      return <Chip label="Données Invalides" color="default" size="small" />;
    }
    if (product.quantity <= 0) {
      return <Chip label="Épuisé" color="error" size="small" />;
    } else if (product.quantity <= product.threshold) {
      return <Chip label="Stock Faible" color="warning" size="small" />;
    } else {
      return <Chip label="En Stock" color="success" size="small" />;
    }
  };

  return (
    <Container maxWidth="lg">
      <Box sx={{ mt: 4, mb: 4 }}>
        <Typography variant="h4" gutterBottom>
          Gestion des Stocks
        </Typography>
        <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 2 }}>
          <form onSubmit={handleSearch}>
            <TextField
              variant="outlined"
              size="small"
              placeholder="Rechercher..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              InputProps={{
                startAdornment: (
                  <InputAdornment position="start">
                    <SearchIcon />
                  </InputAdornment>
                ),
              }}
            />
          </form>
          <Button
            variant="contained"
            color="primary"
            startIcon={<AddIcon />}
            onClick={handleNewProductClick}
          >
            Nouveau Produit
          </Button>
        </Box>

        {error && (
          <Typography color="error" sx={{ mb: 2 }}>
            {error}
          </Typography>
        )}

        <Paper sx={{ width: '100%', overflow: 'hidden' }}>
          {loading ? (
            <Box sx={{ display: 'flex', justifyContent: 'center', p: 3 }}>
              <CircularProgress />
            </Box>
          ) : (
            <>
              <TableContainer sx={{ maxHeight: 440 }}>
                <Table stickyHeader aria-label="sticky table">
                  <TableHead>
                    <TableRow>
                      <TableCell>Nom</TableCell>
                      <TableCell>Catégorie</TableCell>
                      <TableCell>Quantité</TableCell>
                      <TableCell>Unité</TableCell>
                      <TableCell>Seuil d'alerte</TableCell>
                      <TableCell>Statut</TableCell>
                      <TableCell align="right">Actions</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {(() => {
                      if (!Array.isArray(products)) {
                        console.error("StockManagement: products n'est pas un tableau!", products);
                        return (
                          <TableRow>
                            <TableCell colSpan={7} align="center">
                              Erreur : Données des produits invalides.
                            </TableCell>
                          </TableRow>
                        );
                      }
                      if (products.length === 0) {
                        return (
                          <TableRow>
                            <TableCell colSpan={7} align="center">
                              Aucun produit trouvé
                            </TableCell>
                          </TableRow>
                        );
                      }
                      return products.map((product) => (
                        <TableRow hover key={product.id}>
                          <TableCell>{product.name}</TableCell>
                          <TableCell>{product.category}</TableCell>
                          <TableCell>{product.quantity}</TableCell>
                          <TableCell>{product.unit}</TableCell>
                          <TableCell>{product.threshold}</TableCell>
                          <TableCell>{getStockStatusChip(product)}</TableCell>
                          <TableCell align="right">
                            <IconButton
                              color="primary"
                              onClick={() => handleAdjustClick(product)}
                              size="small"
                              title="Ajuster le stock"
                            >
                              <PlusIcon fontSize="small" />
                            </IconButton>
                            <IconButton
                              color="secondary"
                              onClick={() => navigate(`/stock/${product.id}`)}
                              size="small"
                              title="Modifier"
                            >
                              <EditIcon fontSize="small" />
                            </IconButton>
                            <IconButton
                              color="error"
                              onClick={() => handleDeleteClick(product)}
                              size="small"
                              title="Supprimer"
                            >
                              <DeleteIcon fontSize="small" />
                            </IconButton>
                          </TableCell>
                        </TableRow>
                      ));
                    })()}
                  </TableBody>
                </Table>
              </TableContainer>
              <TablePagination
                rowsPerPageOptions={[5, 10, 25]}
                component="div"
                count={totalCount}
                rowsPerPage={rowsPerPage}
                page={page}
                onPageChange={handleChangePage}
                onRowsPerPageChange={handleChangeRowsPerPage}
                labelRowsPerPage="Lignes par page:"
              />
            </>
          )}
        </Paper>
      </Box>

      {/* Dialogue de confirmation de suppression */}
      <Dialog
        open={deleteDialogOpen}
        onClose={handleDeleteCancel}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description"
      >
        <DialogTitle id="alert-dialog-title">
          Confirmer la suppression
        </DialogTitle>
        <DialogContent>
          <DialogContentText id="alert-dialog-description">
            Êtes-vous sûr de vouloir supprimer ce produit ? Cette action est irréversible.
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleDeleteCancel}>Annuler</Button>
          <Button onClick={handleDeleteConfirm} color="error" autoFocus>
            Supprimer
          </Button>
        </DialogActions>
      </Dialog>

      {/* Dialogue d'ajustement de stock */}
      <Dialog
        open={adjustDialogOpen}
        onClose={handleAdjustCancel}
        aria-labelledby="adjust-dialog-title"
      >
        <DialogTitle id="adjust-dialog-title">
          Ajuster le stock: {productToAdjust?.name}
        </DialogTitle>
        <DialogContent>
          <Box sx={{ mt: 2 }}>
            <FormControl fullWidth sx={{ mb: 2 }}>
              <InputLabel>Type d'ajustement</InputLabel>
              <Select
                value={adjustmentType}
                onChange={(e) => setAdjustmentType(e.target.value)}
                label="Type d'ajustement"
              >
                <MenuItem value="add">Ajouter au stock</MenuItem>
                <MenuItem value="remove">Retirer du stock</MenuItem>
              </Select>
            </FormControl>
            <TextField
              fullWidth
              label="Quantité"
              type="number"
              value={adjustQuantity}
              onChange={(e) => setAdjustQuantity(Math.max(0, parseInt(e.target.value, 10) || 0))}
              InputProps={{ inputProps: { min: 0 } }}
              sx={{ mb: 2 }}
            />
            <TextField
              fullWidth
              label="Raison"
              value={adjustReason}
              onChange={(e) => setAdjustReason(e.target.value)}
              multiline
              rows={2}
            />
          </Box>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleAdjustCancel}>Annuler</Button>
          <Button 
            onClick={handleAdjustConfirm} 
            color="primary" 
            disabled={adjustQuantity <= 0}
          >
            Confirmer
          </Button>
        </DialogActions>
      </Dialog>

      {/* Dialogue de nouveau produit */}
      <Dialog
        open={newProductDialogOpen}
        onClose={handleNewProductCancel}
        aria-labelledby="new-product-dialog-title"
        maxWidth="md"
        fullWidth
      >
        <DialogTitle id="new-product-dialog-title">
          Ajouter un nouveau produit
        </DialogTitle>
        <DialogContent>
          <Grid container spacing={2} sx={{ mt: 1 }}>
            <Grid item xs={12} md={6}>
              <TextField
                fullWidth
                label="Nom du produit"
                name="name"
                value={newProduct.name}
                onChange={handleNewProductChange}
                required
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <TextField
                fullWidth
                label="Catégorie"
                name="category"
                value={newProduct.category}
                onChange={handleNewProductChange}
                required
              />
            </Grid>
            <Grid item xs={12} md={4}>
              <TextField
                fullWidth
                label="Quantité initiale"
                name="quantity"
                type="number"
                value={newProduct.quantity}
                onChange={handleNewProductChange}
                InputProps={{ inputProps: { min: 0 } }}
                required
              />
            </Grid>
            <Grid item xs={12} md={4}>
              <TextField
                fullWidth
                label="Unité"
                name="unit"
                value={newProduct.unit}
                onChange={handleNewProductChange}
                required
                placeholder="ex: kg, pièces, cartons"
              />
            </Grid>
            <Grid item xs={12} md={4}>
              <TextField
                fullWidth
                label="Seuil d'alerte"
                name="threshold"
                type="number"
                value={newProduct.threshold}
                onChange={handleNewProductChange}
                InputProps={{ inputProps: { min: 0 } }}
                required
                helperText="Quantité minimale avant alerte"
              />
            </Grid>
            <Grid item xs={12}>
              <TextField
                fullWidth
                label="Description"
                name="description"
                value={newProduct.description}
                onChange={handleNewProductChange}
                multiline
                rows={3}
              />
            </Grid>
          </Grid>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleNewProductCancel}>Annuler</Button>
          <Button 
            onClick={handleNewProductConfirm} 
            color="primary"
            disabled={!newProduct.name || !newProduct.category || !newProduct.unit}
          >
            Ajouter
          </Button>
        </DialogActions>
      </Dialog>
    </Container>
  );
}

export default StockManagement;