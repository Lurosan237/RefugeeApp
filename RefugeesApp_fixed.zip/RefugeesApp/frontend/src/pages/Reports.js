import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types'; // Move to top with other imports
import {
  Container,
  Paper,
  Typography,
  Box,
  Grid,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  CircularProgress,
  Tabs,
  Tab,
  Button,
  TextField,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  IconButton,
  Dialog,
  DialogActions,
  DialogContent,
  DialogContentText,
  DialogTitle,
} from '@mui/material';
import { 
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from 'recharts';
import {
  Download as DownloadIcon,
  PictureAsPdf as PdfIcon,
  Description as ExcelIcon // Using Description for Excel as an example, could be more specific
} from '@mui/icons-material';
import { DatePicker } from '@mui/x-date-pickers/DatePicker';
import authService from '../services/authService'; // Import authService
// import { AdapterDateFns } from '@mui/x-date-pickers/AdapterDateFns'; // Supprimé car géré globalement
// import { LocalizationProvider } from '@mui/x-date-pickers'; // Supprimé car géré globalement
import { format, subMonths } from 'date-fns';
// import { fr } from 'date-fns/locale'; // Supprimé car géré globalement
// Import des services réels (commentés pendant le développement sans backend)
// import refugeeService from '../services/refugeeService';
// import distributionService from '../services/distributionService';
// import stockService from '../services/stockService';
import reportService from '../services/reportService';

// Import des services mock pour le développement sans backend (si nécessaire pour d'autres modules)
// import { mockRefugeeService } from '../services/mockServices';
// import { mockDistributionService } from '../services/mockServices';
// import { mockStockService } from '../services/mockServices';

// Couleurs pour les graphiques
const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884d8', '#82ca9d'];

class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true };
  }

  componentDidCatch(error, errorInfo) {
    console.error('Report component error:', error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      return (
        <Paper sx={{ p: 3, textAlign: 'center' }}>
          <Typography color="error">
            Une erreur est survenue lors de l'affichage des données.
          </Typography>
          <Button 
            onClick={() => this.setState({ hasError: false })}
            sx={{ mt: 2 }}
          >
            Réessayer
          </Button>
        </Paper>
      );
    }

    return this.props.children;
  }
}

function Reports() {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [tabValue, setTabValue] = useState(0);
  const [reportType, setReportType] = useState('monthly');
  const [startDate, setStartDate] = useState(subMonths(new Date(), 6));
  const [endDate, setEndDate] = useState(new Date());
  const [refugeeData, setRefugeeData] = useState([]);
  const [distributionData, setDistributionData] = useState([]);
  const [stockData, setStockData] = useState([]);
  const [nationalityData, setNationalityData] = useState([]);
  const [ageGroupData, setAgeGroupData] = useState([]);
  const [genderData, setGenderData] = useState([]);
  const [topDistributedItems, setTopDistributedItems] = useState([]);
  const [mainTabValue, setMainTabValue] = useState(0); // 0 for Statistics, 1 for Generated Reports
  const [generatedReports, setGeneratedReports] = useState([]);
  const [generatedReportsLoading, setGeneratedReportsLoading] = useState(false);
  const [generatedReportsError, setGeneratedReportsError] = useState(null);
  const [createReportDialogOpen, setCreateReportDialogOpen] = useState(false);
  const [newReportName, setNewReportName] = useState('');
  const [newReportType, setNewReportType] = useState('refugees'); // 'refugees', 'distributions', 'stocks'
  const [newReportStartDate, setNewReportStartDate] = useState(subMonths(new Date(), 1));
  const [newReportEndDate, setNewReportEndDate] = useState(new Date());
  const [creatingReport, setCreatingReport] = useState(false);
  const [currentUser, setCurrentUser] = useState(null);

  const handleDownloadReport = async (reportId, format) => {
    try {
      let blob;
      if (format === 'pdf') {
        blob = await reportService.downloadPdf(reportId);
      } else if (format === 'excel') {
        blob = await reportService.downloadExcel(reportId);
      }
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `report_${reportId}.${format === 'pdf' ? 'pdf' : 'xlsx'}`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      window.URL.revokeObjectURL(url);
    } catch (err) {
      console.error(`Error downloading report ${reportId} as ${format}:`, err);
      setGeneratedReportsError(`Erreur lors du téléchargement du rapport (ID: ${reportId}).`);
    }
  };

  const handleOpenCreateReportDialog = () => {
    setNewReportName(`Rapport ${newReportType} ${format(new Date(), 'yyyy-MM-dd HH:mm')}`);
    setNewReportStartDate(subMonths(new Date(), 1));
    setNewReportEndDate(new Date());
    setCreateReportDialogOpen(true);
  };

  const handleCloseCreateReportDialog = () => {
    setCreateReportDialogOpen(false);
  };

  const handleCreateReport = async () => {
    try {
      setCreatingReport(true);
      const formattedStartDate = format(newReportStartDate, 'yyyy-MM-dd');
      const formattedEndDate = format(newReportEndDate, 'yyyy-MM-dd');
      
      await reportService.createReport({
        name: newReportName,
        type: newReportType,
        startDate: formattedStartDate,
        endDate: formattedEndDate
      });
      
      setCreateReportDialogOpen(false);
      fetchGeneratedReports(); // Refresh the list of reports
    } catch (err) {
      console.error('Error creating report:', err);
      setGeneratedReportsError('Erreur lors de la création du rapport.');
    } finally {
      setCreatingReport(false);
    }
  };

  // Utilisation de useCallback pour mémoriser fetchReportData
  const fetchGeneratedReports = React.useCallback(async () => {
    if (mainTabValue !== 1) return; // Only fetch if the tab is active
    
    try {
      setGeneratedReportsLoading(true);
      const response = await reportService.getAll();
      
      // Transform the response to ensure it's an array
      const reports = Array.isArray(response) ? response : 
                     Array.isArray(response?.results) ? response.results :
                     Array.isArray(response?.data) ? response.data : [];
      
      setGeneratedReports(reports);
      setGeneratedReportsError(null);
    } catch (err) {
      console.error('Error fetching generated reports:', err);
      setGeneratedReports([]);
      setGeneratedReportsError('Erreur lors du chargement des rapports');
    } finally {
      setGeneratedReportsLoading(false);
    }
  }, [mainTabValue]);

  const fetchReportData = React.useCallback(async () => {
    try {
      setLoading(true);
      const formattedStartDate = format(startDate, 'yyyy-MM-dd');
      const formattedEndDate = format(endDate, 'yyyy-MM-dd');

      if (tabValue === 0) {
        const refugeeStats = await reportService.getRefugeeReports(formattedStartDate, formattedEndDate, reportType);
        
        // Transform and validate refugee data
        const transformedData = {
          timeline: Array.isArray(refugeeStats?.timeline) ? refugeeStats.timeline : [],
          nationalities: Array.isArray(refugeeStats?.nationalities) ? refugeeStats.nationalities : [],
          ageGroups: Array.isArray(refugeeStats?.ageGroups) ? refugeeStats.ageGroups : [],
          genderDistribution: Array.isArray(refugeeStats?.genderDistribution) ? refugeeStats.genderDistribution : []
        };

        setRefugeeData(transformedData.timeline);
        setNationalityData(transformedData.nationalities);
        setAgeGroupData(transformedData.ageGroups);
        setGenderData(transformedData.genderDistribution);
        setError(null);
      } 
      // ... rest of the function remains the same
    } catch (err) {
      console.error('Error fetching report data:', err);
      setError('Erreur lors du chargement des données');
      resetAllData();
    } finally {
      setLoading(false);
    }
  }, [startDate, endDate, reportType, tabValue]);

  // Add a helper function to reset all data
  const resetAllData = () => {
    setRefugeeData([]);
    setNationalityData([]);
    setAgeGroupData([]);
    setGenderData([]);
    setDistributionData([]);
    setTopDistributedItems([]);
    setStockData([]);
  };

  useEffect(() => {
    if (mainTabValue === 0) {
      fetchReportData();
    }
  }, [fetchReportData, mainTabValue]);

  useEffect(() => {
    if (mainTabValue === 1) {
      fetchGeneratedReports();
    }
  }, [fetchGeneratedReports, mainTabValue]);

  useEffect(() => {
    const fetchCurrentUser = async () => {
      try {
        const user = await authService.getCurrentUser();
        setCurrentUser(user);
      } catch (error) {
        console.error('Error fetching current user:', error);
        // Handle error fetching user, maybe set an error state
      }
    };
    fetchCurrentUser();
  }, []);

  // La définition originale de fetchReportData est supprimée car elle est maintenant définie avec useCallback plus haut.

  const handleMainTabChange = (event, newValue) => {
    setMainTabValue(newValue);
  };

  const handleTabChange = (event, newValue) => {
    setTabValue(newValue);
  };

  const handleReportTypeChange = (event) => {
    setReportType(event.target.value);
  };

  const handleExportReport = async () => {
    try {
      const formattedStartDate = format(startDate, 'yyyy-MM-dd');
      const formattedEndDate = format(endDate, 'yyyy-MM-dd');
      
      let reportUrl;
      if (tabValue === 0) {
        reportUrl = await reportService.exportRefugeeReport(formattedStartDate, formattedEndDate, reportType);
      } else if (tabValue === 1) {
        reportUrl = await reportService.exportDistributionReport(formattedStartDate, formattedEndDate, reportType);
      } else if (tabValue === 2) {
        reportUrl = await reportService.exportStockReport(formattedStartDate, formattedEndDate);
      }
      
      // Ouvrir le rapport dans un nouvel onglet ou télécharger
      if (reportUrl) {
        window.open(reportUrl, '_blank');
      }
    } catch (err) {
      setError('Erreur lors de l\'exportation du rapport');
      console.error('Error exporting report:', err);
    }
  };

  const renderRefugeeReports = () => (
    <Grid container spacing={3}>
      <Grid item xs={12}>
        <Paper sx={{ p: 3, mb: 3 }}>
          <Typography variant="h6" gutterBottom>
            Évolution du nombre de réfugiés
          </Typography>
          {refugeeData.length > 0 ? (
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={refugeeData}>
                {/* ... existing chart configuration ... */}
              </BarChart>
            </ResponsiveContainer>
          ) : (
            <Typography color="textSecondary" align="center">
              Aucune donnée disponible pour la période sélectionnée
            </Typography>
          )}
        </Paper>
      </Grid>
      {/* ... rest of the component ... */}
    </Grid>
  );

  const renderDistributionReports = () => (
    <Grid container spacing={3}>
      <Grid item xs={12}>
        <Paper sx={{ p: 3, mb: 3 }}>
          <Typography variant="h6" gutterBottom>
            Évolution des distributions
          </Typography>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={distributionData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="period" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Bar dataKey="count" fill="#ff9800" name="Nombre de distributions" />
              <Bar dataKey="beneficiaries" fill="#f44336" name="Nombre de bénéficiaires" />
            </BarChart>
          </ResponsiveContainer>
        </Paper>
      </Grid>
      
      <Grid item xs={12}>
        <Paper sx={{ p: 3 }}>
          <Typography variant="h6" gutterBottom>
            Articles les plus distribués
          </Typography>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={topDistributedItems} layout="vertical">
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis type="number" />
              <YAxis dataKey="name" type="category" width={150} />
              <Tooltip />
              <Legend />
              <Bar dataKey="quantity" fill="#8884d8" name="Quantité distribuée" />
            </BarChart>
          </ResponsiveContainer>
        </Paper>
      </Grid>
    </Grid>
  );

  const renderStockReports = () => (
    <Grid container spacing={3}>
      <Grid item xs={12}>
        <Paper sx={{ p: 3 }}>
          <Typography variant="h6" gutterBottom>
            Mouvements de stock
          </Typography>
          <ResponsiveContainer width="100%" height={400}>
            <BarChart data={stockData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="date" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Bar dataKey="additions" fill="#4caf50" name="Entrées" />
              <Bar dataKey="removals" fill="#f44336" name="Sorties" />
            </BarChart>
          </ResponsiveContainer>
        </Paper>
      </Grid>
    </Grid>
  );

  if (mainTabValue === 0 && loading && !refugeeData.length && !distributionData.length && !stockData.length) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '80vh' }}>
        <CircularProgress />
      </Box>
    );
  }

  return (
    <Container maxWidth="lg">
      <ErrorBoundary>
        <Box sx={{ mt: 4, mb: 4 }}>
          <Typography variant="h4" gutterBottom>
            Rapports et Statistiques
          </Typography>

          <Paper sx={{ mb: 3 }}>
            <Tabs
              value={mainTabValue}
              onChange={handleMainTabChange}
              indicatorColor="primary"
              textColor="primary"
              variant="fullWidth"
            >
              <Tab label="Statistiques Visuelles" />
              <Tab label="Liste des Rapports Générés" />
            </Tabs>
          </Paper>

          {mainTabValue === 0 && (
            <>
              <Paper sx={{ mb: 3 }}>
                <Tabs
                  value={tabValue}
                  onChange={handleTabChange}
                  indicatorColor="secondary"
                  textColor="secondary"
                  variant="fullWidth"
                >
                  <Tab label="Réfugiés" />
                  <Tab label="Distributions" />
                  <Tab label="Stocks" />
                </Tabs>
              </Paper>

              <Paper sx={{ p: 3, mb: 3 }}>
                <Grid container spacing={2} alignItems="center">
                  <Grid item xs={12} md={3}>
                    <FormControl fullWidth>
                      <InputLabel>Type de rapport</InputLabel>
                      <Select
                        value={reportType}
                        onChange={handleReportTypeChange}
                        label="Type de rapport"
                      >
                        <MenuItem value="daily">Quotidien</MenuItem>
                        <MenuItem value="weekly">Hebdomadaire</MenuItem>
                        <MenuItem value="monthly">Mensuel</MenuItem>
                        <MenuItem value="yearly">Annuel</MenuItem>
                      </Select>
                    </FormControl>
                  </Grid>
                  
                  <Grid item xs={12} md={3}>
                      <DatePicker
                        label="Date de début"
                        value={startDate}
                        onChange={(newDate) => setStartDate(newDate)}
                        renderInput={(params) => <TextField {...params} fullWidth />}
                        maxDate={endDate}
                      />
                  </Grid>
                  
                  <Grid item xs={12} md={3}>
                      <DatePicker
                        label="Date de fin"
                        value={endDate}
                        onChange={(newDate) => setEndDate(newDate)}
                        renderInput={(params) => <TextField {...params} fullWidth />}
                        minDate={startDate}
                        maxDate={new Date()}
                      />
                  </Grid>
                  
                  <Grid item xs={12} md={3}>
                    <Button
                      variant="outlined"
                      color="primary"
                      fullWidth
                      onClick={handleExportReport}
                    >
                      Exporter le rapport (Statistiques)
                    </Button>
                  </Grid>
                </Grid>
              </Paper>

              {error && (
                <Typography color="error" sx={{ mb: 2 }}>
                  {error}
                </Typography>
              )}

              {loading ? (
                <Box sx={{ display: 'flex', justifyContent: 'center', p: 3 }}>
                  <CircularProgress />
                </Box>
              ) : (
                <>
                  {tabValue === 0 && renderRefugeeReports()}
                  {tabValue === 1 && renderDistributionReports()}
                  {tabValue === 2 && renderStockReports()}
                </>
              )}
            </>
          )}

          {mainTabValue === 1 && (
            <>
              <Paper sx={{ p: 3 }}>
                <Typography variant="h6" gutterBottom>
                  Liste des Rapports Générés
                </Typography>
                <Box sx={{ mb: 2, display: 'flex', justifyContent: 'flex-end' }}>
                  {currentUser && (currentUser.is_staff || currentUser.role === 'admin' || currentUser.role === 'manager') ? (
                    <Button variant="contained" color="primary" onClick={handleOpenCreateReportDialog} disabled={creatingReport}>
                      Créer un nouveau rapport
                    </Button>
                  ) : (
                    <Button variant="contained" color="primary" disabled title="Vous n'avez pas les permissions nécessaires">
                      Créer un nouveau rapport (Permissions requises)
                    </Button>
                  )}
                </Box>
                
                {generatedReportsError && (
                  <Typography color="error" sx={{ mb: 2 }}>
                    {generatedReportsError}
                  </Typography>
                )}
                
                {generatedReportsLoading ? (
                  <Box sx={{ display: 'flex', justifyContent: 'center', p: 3 }}>
                    <CircularProgress />
                  </Box>
                ) : generatedReports.length > 0 ? (
                  <TableContainer component={Paper} sx={{ mt: 2 }}>
                    <Table sx={{ minWidth: 650 }} aria-label="simple table">
                      <TableHead>
                        <TableRow>
                          <TableCell>Nom du Rapport</TableCell>
                          <TableCell>Type</TableCell>
                          <TableCell>Date de Création</TableCell>
                          <TableCell align="right">Actions</TableCell>
                        </TableRow>
                      </TableHead>
                      <TableBody>
                        {generatedReports.map((report) => (
                          <TableRow
                            key={report.id}
                            sx={{ '&:last-child td, &:last-child th': { border: 0 } }}
                          >
                            <TableCell component="th" scope="row">
                              {report.name || `Rapport ID: ${report.id}`}
                            </TableCell>
                            <TableCell>{report.report_type || report.type || 'N/A'}</TableCell>
                            <TableCell>{new Date(report.created_at || report.createdAt).toLocaleDateString()}</TableCell>
                            <TableCell align="right">
                              <IconButton onClick={() => handleDownloadReport(report.id, 'pdf')} title="Télécharger PDF">
                                <PdfIcon />
                              </IconButton>
                              <IconButton onClick={() => handleDownloadReport(report.id, 'excel')} title="Télécharger Excel">
                                <ExcelIcon />
                              </IconButton>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </TableContainer>
                ) : (
                  <Typography>
                    Aucun rapport généré trouvé.
                  </Typography>
                )}
              </Paper>
              
              <CreateReportDialog 
                open={createReportDialogOpen}
                onClose={handleCloseCreateReportDialog}
                onCreate={handleCreateReport}
                reportName={newReportName}
                setReportName={setNewReportName}
                reportType={newReportType}
                setReportType={setNewReportType}
                startDate={newReportStartDate}
                setStartDate={setNewReportStartDate}
                endDate={newReportEndDate}
                setEndDate={setNewReportEndDate}
                loading={creatingReport}
              />
            </>
          )}
        </Box>
      </ErrorBoundary>
    </Container>
  );
}

export default Reports;

// Dialog for Creating a new Report
function CreateReportDialog({ open, onClose, onCreate, reportName, setReportName, reportType, setReportType, startDate, setStartDate, endDate, setEndDate, loading }) {
  return (
    <Dialog open={open} onClose={onClose} maxWidth="sm" fullWidth>
      <DialogTitle>Créer un nouveau rapport</DialogTitle>
      <DialogContent>
        <DialogContentText sx={{mb: 2}}>
          Veuillez spécifier les détails pour le nouveau rapport.
        </DialogContentText>
        <TextField
          autoFocus
          margin="dense"
          id="name"
          label="Nom du rapport"
          type="text"
          fullWidth
          variant="outlined"
          value={reportName}
          onChange={(e) => setReportName(e.target.value)}
          sx={{ mb: 2 }}
        />
        <FormControl fullWidth margin="dense" sx={{ mb: 2 }}>
          <InputLabel id="report-type-label">Type de rapport</InputLabel>
          <Select
            labelId="report-type-label"
            id="report-type"
            value={reportType}
            label="Type de rapport"
            onChange={(e) => setReportType(e.target.value)}
          >
            <MenuItem value="refugees">Réfugiés</MenuItem>
            <MenuItem value="distributions">Distributions</MenuItem>
            <MenuItem value="stocks">Stocks</MenuItem>
          </Select>
        </FormControl>
        <Grid container spacing={2} sx={{ mb: 2 }}>
          <Grid item xs={12} sm={6}>
            <DatePicker
              label="Date de début"
              value={startDate}
              onChange={(newDate) => setStartDate(newDate)}
              renderInput={(params) => <TextField {...params} fullWidth />}
              maxDate={endDate}
            />
          </Grid>
          <Grid item xs={12} sm={6}>
            <DatePicker
              label="Date de fin"
              value={endDate}
              onChange={(newDate) => setEndDate(newDate)}
              renderInput={(params) => <TextField {...params} fullWidth />}
              minDate={startDate}
              maxDate={new Date()}
            />
          </Grid>
        </Grid>
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose} color="secondary" disabled={loading}>Annuler</Button>
        <Button onClick={onCreate} color="primary" variant="contained" disabled={loading}>
          {loading ? <CircularProgress size={24} /> : 'Créer'}
        </Button>
      </DialogActions>
    </Dialog>
  );
}

CreateReportDialog.propTypes = {
  open: PropTypes.bool.isRequired,
  onClose: PropTypes.func.isRequired,
  onCreate: PropTypes.func.isRequired,
  reportName: PropTypes.string,
  setReportName: PropTypes.func.isRequired,
  reportType: PropTypes.string,
  setReportType: PropTypes.func.isRequired,
  startDate: PropTypes.instanceOf(Date),
  setStartDate: PropTypes.func.isRequired,
  endDate: PropTypes.instanceOf(Date),
  setEndDate: PropTypes.func.isRequired,
  loading: PropTypes.bool
};

CreateReportDialog.defaultProps = {
  reportName: '',
  reportType: 'refugees',
  startDate: new Date(),
  endDate: new Date(),
  loading: false
};

