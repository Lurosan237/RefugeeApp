import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import {
  Container,
  Paper,
  Typography,
  Box,
  Grid,
  TextField,
  Button,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Divider,
  List,
  ListItem,
  ListItemText,
  CircularProgress,
  Alert,
  Snackbar,
  IconButton,
  Chip,
} from '@mui/material';
import { ArrowBack as ArrowBackIcon, Save as SaveIcon, Delete as DeleteIcon } from '@mui/icons-material'; // Ajout de DeleteIcon
import { AdapterDateFns } from '@mui/x-date-pickers/AdapterDateFns';
import { LocalizationProvider, DatePicker } from '@mui/x-date-pickers';
import distributionService from '../services/distributionService';
import refugeeService from '../services/refugeeService';
import stockService from '../services/stockService';

function DistributionDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const isNewDistribution = id === 'new';
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(false);
  const [distribution, setDistribution] = useState({
    date: new Date(),
    location: '',
    description: '',
    status: 'Pending',
    items: [],
    beneficiaries: [],
  });
  const [availableRefugees, setAvailableRefugees] = useState([]);
  const [availableItems, setAvailableItems] = useState([]);
  const [selectedRefugee, setSelectedRefugee] = useState('');
  const [selectedItem, setSelectedItem] = useState('');
  const [selectedItemQuantity, setSelectedItemQuantity] = useState(1);

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        
        const [refugeesData, itemsData] = await Promise.all([
          refugeeService.getAll(1, 100),
          stockService.getAll(1, 100)
        ]);

        setAvailableRefugees(refugeesData?.results || []);
        setAvailableItems(itemsData?.results || []);
        
        if (!isNewDistribution) {
          const distributionData = await distributionService.getById(id);
          setDistribution(prev => ({
            ...prev,
            ...distributionData,
            date: distributionData?.date ? new Date(distributionData.date) : new Date(),
            items: distributionData?.items || [],
            beneficiaries: distributionData?.beneficiaries || []
          }));
        }
        
        setError(null);
      } catch (err) {
        setError('Erreur lors du chargement des données');
        console.error('Error fetching data:', err);
      } finally {
        setLoading(false);
      }
    };
    
    fetchData();
  }, [id, isNewDistribution]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setDistribution({
      ...distribution,
      [name]: value,
    });
  };

  const handleDateChange = (newDate) => {
    setDistribution({
      ...distribution,
      date: newDate,
    });
  };

  const handleAddBeneficiary = () => {
    if (!selectedRefugee) return;
    
    const refugeeToAdd = availableRefugees.find(r => r.id === selectedRefugee);
    
    // Vérifier si le réfugié est déjà dans la liste
    if (distribution.beneficiaries.some(b => b.id === refugeeToAdd.id)) {
      return;
    }
    
    setDistribution({
      ...distribution,
      beneficiaries: [...distribution.beneficiaries, refugeeToAdd],
    });
    
    setSelectedRefugee('');
  };

  const handleRemoveBeneficiary = (beneficiaryId) => {
    setDistribution({
      ...distribution,
      beneficiaries: distribution.beneficiaries.filter(b => b.id !== beneficiaryId),
    });
  };

  const handleAddItem = () => {
    if (!selectedItem || selectedItemQuantity <= 0) return;
    
    const itemToAdd = availableItems.find(i => i.id === selectedItem);
    
    // Vérifier si l'article est déjà dans la liste
    const existingItemIndex = distribution.items.findIndex(i => i.id === itemToAdd.id);
    
    if (existingItemIndex >= 0) {
      // Mettre à jour la quantité si l'article existe déjà
      const updatedItems = [...distribution.items];
      updatedItems[existingItemIndex].quantity += selectedItemQuantity;
      
      setDistribution({
        ...distribution,
        items: updatedItems,
      });
    } else {
      // Ajouter un nouvel article
      setDistribution({
        ...distribution,
        items: [...distribution.items, { ...itemToAdd, quantity: selectedItemQuantity }],
      });
    }
    
    setSelectedItem('');
    setSelectedItemQuantity(1);
  };

  const handleRemoveItem = (itemId) => {
    setDistribution({
      ...distribution,
      items: distribution.items.filter(i => i.id !== itemId),
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSaving(true);
    
    try {
      const distributionData = {
        ...distribution,
        beneficiaries: distribution.beneficiaries.map(b => b.id),
        items: distribution.items.map(i => ({ id: i.id, quantity: i.quantity })),
      };
      
      if (isNewDistribution) {
        await distributionService.create(distributionData);
      } else {
        await distributionService.update(id, distributionData);
      }
      
      setSuccess(true);
      setTimeout(() => {
        navigate('/distributions');
      }, 1500);
    } catch (err) {
      setError('Erreur lors de l\'enregistrement de la distribution');
      console.error('Error saving distribution:', err);
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '80vh' }}>
        <CircularProgress />
      </Box>
    );
  }

  const renderItems = () => {
    if (!distribution?.items?.length) {
      return (
        <Typography color="textSecondary" align="center">
          Aucun article ajouté
        </Typography>
      );
    }

    return (
      <List>
        {distribution.items.map((item) => (
          <ListItem
            key={item?.id || Math.random()}
            secondaryAction={
              <IconButton
                edge="end"
                aria-label="delete"
                onClick={() => handleRemoveItem(item.id)}
              >
                <DeleteIcon />
              </IconButton>
            }
          >
            <ListItemText
              primary={item?.name || 'Article sans nom'}
              secondary={`Quantité: ${item?.quantity || 0}`}
            />
          </ListItem>
        ))}
      </List>
    );
  };

  const renderBeneficiaries = () => {
    if (!distribution?.beneficiaries?.length) {
      return (
        <Typography color="textSecondary" align="center">
          Aucun bénéficiaire ajouté
        </Typography>
      );
    }

    return (
      <List>
        {distribution.beneficiaries.map((beneficiary) => (
          <ListItem
            key={beneficiary?.id || Math.random()}
            secondaryAction={
              <IconButton
                edge="end"
                aria-label="delete"
                onClick={() => handleRemoveBeneficiary(beneficiary.id)}
              >
                <DeleteIcon />
              </IconButton>
            }
          >
            <ListItemText
              primary={`${beneficiary?.first_name || ''} ${beneficiary?.last_name || ''}`}
              secondary={beneficiary?.registration_number || 'No registration'}
            />
          </ListItem>
        ))}
      </List>
    );
  };

  return (
    <Container maxWidth="lg">
      <Box sx={{ mt: 4, mb: 4 }}>
        <Box sx={{ display: 'flex', alignItems: 'center', mb: 3 }}>
          <IconButton onClick={() => navigate('/distributions')} sx={{ mr: 2 }}>
            <ArrowBackIcon />
          </IconButton>
          <Typography variant="h4">
            {isNewDistribution ? 'Nouvelle Distribution' : 'Modifier Distribution'}
          </Typography>
        </Box>

        {error && (
          <Alert severity="error" sx={{ mb: 2 }}>
            {error}
          </Alert>
        )}

        <Paper sx={{ p: 3 }}>
          <form onSubmit={handleSubmit}>
            <Grid container spacing={3}>
              <Grid item xs={12} md={6}>
                <LocalizationProvider dateAdapter={AdapterDateFns}>
                  <DatePicker
                    label="Date de distribution"
                    value={distribution.date}
                    onChange={handleDateChange}
                    renderInput={(params) => <TextField {...params} fullWidth required />}
                  />
                </LocalizationProvider>
              </Grid>
              <Grid item xs={12} md={6}>
                <TextField
                  fullWidth
                  label="Lieu"
                  name="location"
                  value={distribution.location}
                  onChange={handleChange}
                  required
                />
              </Grid>
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  label="Description"
                  name="description"
                  value={distribution.description}
                  onChange={handleChange}
                  multiline
                  rows={3}
                />
              </Grid>
              <Grid item xs={12} md={6}>
                <FormControl fullWidth>
                  <InputLabel>Statut</InputLabel>
                  <Select
                    name="status"
                    value={distribution.status}
                    onChange={handleChange}
                    label="Statut"
                  >
                    <MenuItem value="Pending">En attente</MenuItem>
                    <MenuItem value="In Progress">En cours</MenuItem>
                    <MenuItem value="Completed">Terminée</MenuItem>
                    <MenuItem value="Cancelled">Annulée</MenuItem>
                  </Select>
                </FormControl>
              </Grid>
            </Grid>

            <Divider sx={{ my: 3 }} />

            <Typography variant="h6" gutterBottom>
              Articles à distribuer
            </Typography>
            <Grid container spacing={2} sx={{ mb: 2 }}>
              <Grid item xs={12} md={5}>
                <FormControl fullWidth>
                  <InputLabel>Article</InputLabel>
                  <Select
                    value={selectedItem}
                    onChange={(e) => setSelectedItem(e.target.value)}
                    label="Article"
                  >
                    {availableItems.map((item) => (
                      <MenuItem key={item.id} value={item.id}>
                        {item.name} ({item.quantity} disponibles)
                      </MenuItem>
                    ))}
                  </Select>
                </FormControl>
              </Grid>
              <Grid item xs={12} md={4}>
                <TextField
                  fullWidth
                  label="Quantité"
                  type="number"
                  value={selectedItemQuantity}
                  onChange={(e) => setSelectedItemQuantity(parseInt(e.target.value, 10) || 0)}
                  InputProps={{ inputProps: { min: 1 } }}
                />
              </Grid>
              <Grid item xs={12} md={3}>
                <Button
                  fullWidth
                  variant="outlined"
                  onClick={handleAddItem}
                  disabled={!selectedItem || selectedItemQuantity <= 0}
                >
                  Ajouter
                </Button>
              </Grid>
            </Grid>

            <Paper variant="outlined" sx={{ p: 2, mb: 3 }}>
              {renderItems()}
            </Paper>

            <Divider sx={{ my: 3 }} />

            <Typography variant="h6" gutterBottom>
              Bénéficiaires
            </Typography>
            <Grid container spacing={2} sx={{ mb: 2 }}>
              <Grid item xs={12} md={9}>
                <FormControl fullWidth>
                  <InputLabel>Réfugié</InputLabel>
                  <Select
                    value={selectedRefugee}
                    onChange={(e) => setSelectedRefugee(e.target.value)}
                    label="Réfugié"
                  >
                    {availableRefugees.map((refugee) => (
                      <MenuItem key={refugee.id} value={refugee.id}>
                        {refugee.first_name} {refugee.last_name} ({refugee.registration_number})
                      </MenuItem>
                    ))}
                  </Select>
                </FormControl>
              </Grid>
              <Grid item xs={12} md={3}>
                <Button
                  fullWidth
                  variant="outlined"
                  onClick={handleAddBeneficiary}
                  disabled={!selectedRefugee}
                >
                  Ajouter
                </Button>
              </Grid>
            </Grid>

            <Paper variant="outlined" sx={{ p: 2, mb: 3 }}>
              {renderBeneficiaries()}
            </Paper>

            <Box sx={{ display: 'flex', justifyContent: 'flex-end', mt: 3 }}>
              <Button
                variant="contained"
                color="primary"
                type="submit"
                disabled={saving}
                startIcon={<SaveIcon />}
                sx={{ ml: 1 }}
              >
                {saving ? 'Enregistrement...' : 'Enregistrer'}
              </Button>
            </Box>
          </form>
        </Paper>
      </Box>

      <Snackbar
        open={success}
        autoHideDuration={6000}
        onClose={() => setSuccess(false)}
      >
        <Alert severity="success" sx={{ width: '100%' }}>
          Distribution enregistrée avec succès!
        </Alert>
      </Snackbar>
    </Container>
  );
}

export default DistributionDetail;