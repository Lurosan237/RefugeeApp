import React, { useState, useEffect } from 'react';
import { 
  Container, 
  Grid, 
  Paper, 
  Typography, 
  Box,
  Card,
  CardContent,
  Divider,
  CircularProgress
} from '@mui/material';
import { 
  People as PeopleIcon,
  LocalShipping as DistributionIcon,
  Inventory as InventoryIcon,
  Warning as WarningIcon
} from '@mui/icons-material';
// Import des services réels (commentés pendant le développement sans backend)
import refugeeService from '../services/refugeeService';
import distributionService from '../services/distributionService';
import stockService from '../services/stockService';

// Import des services mock pour le développement sans backend
// import { mockRefugeeService as refugeeService, 
//          mockDistributionService as distributionService, 
//          mockStockService as stockService } from '../services/mockServices';

const StatCard = ({ title, value, icon, color }) => {
  return (
    <Card sx={{ height: '100%' }}>
      <CardContent>
        <Grid container spacing={3} sx={{ justifyContent: 'space-between' }}>
          <Grid item>
            <Typography color="textSecondary" gutterBottom variant="overline">
              {title}
            </Typography>
            <Typography color="textPrimary" variant="h4">
              {value}
            </Typography>
          </Grid>
          <Grid item>
            <Box
              sx={{
                backgroundColor: color,
                borderRadius: 1,
                p: 1,
                color: 'white'
              }}
            >
              {icon}
            </Box>
          </Grid>
        </Grid>
      </CardContent>
    </Card>
  );
};

function Dashboard() {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [stats, setStats] = useState({
    refugees: { total: 0, active: 0 },
    distributions: { total: 0, pending: 0, completed: 0 },
    stock: { totalItems: 0, lowStock: 0 }
  });

  useEffect(() => {
    const fetchDashboardData = async () => {
      console.log('[Dashboard] Starting to fetch dashboard data.');
      try {
        setLoading(true);
        console.log('[Dashboard] Fetching refugee statistics...');
        const refugeeStats = await refugeeService.getStatistics();
        console.log('[Dashboard] Refugee statistics received:', refugeeStats);
        
        console.log('[Dashboard] Fetching distribution statistics...');
        const distributionStats = await distributionService.getStatistics();
        console.log('[Dashboard] Distribution statistics received:', distributionStats);
        
        console.log('[Dashboard] Fetching stock statistics...');
        const stockStats = await stockService.getStatistics();
        console.log('[Dashboard] Stock statistics received:', stockStats);
        
        setStats({
          refugees: refugeeStats,
          distributions: distributionStats,
          stock: stockStats
        });
        
        setLoading(false);
        console.log('[Dashboard] Dashboard data loaded successfully.');
      } catch (err) {
        console.error('[Dashboard] Error loading dashboard data:', err.response ? err.response.data : err.message, err.stack);
        setError('Erreur lors du chargement des données du tableau de bord');
        setLoading(false);
      }
    };
    
    // Ajouter un délai artificiel pour simuler le chargement
    // En production, ce délai devrait être supprimé ou conditionnel
    console.log('[Dashboard] Simulating data loading delay.');
    setTimeout(() => {
      fetchDashboardData();
    }, 800);
  }, []);
  
  // Commentaire pour les développeurs: Ce composant utilise actuellement des données mock
  // Pour utiliser les données réelles, décommentez les imports des services réels
  // et commentez les imports des services mock.

  if (loading) {
    console.log('[Dashboard] Rendering loading state.');
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '80vh' }}>
        <CircularProgress />
      </Box>
    );
  }

  if (error) {
    console.log('[Dashboard] Rendering error state:', error);
    return (
      <Container maxWidth="lg">
        <Box sx={{ mt: 4, mb: 4 }}>
          <Typography variant="h4" color="error" gutterBottom>
            {error}
          </Typography>
        </Box>
      </Container>
    );
  }

  return (
    <Container maxWidth="lg">
      <Box sx={{ mt: 4, mb: 4 }}>
        <Typography variant="h4" gutterBottom>
          Tableau de bord
        </Typography>
        <Typography variant="subtitle1" color="textSecondary">
          Aperçu de la gestion des réfugiés et des distributions
        </Typography>
        {console.log('[Dashboard] Rendering main content with stats:', stats)}
      </Box>
      
      <Grid container spacing={3}>
        {/* Statistiques des réfugiés */}
        <Grid item xs={12} sm={6} md={3}>
          <StatCard 
            title="Total Réfugiés" 
            value={stats.refugees.total} 
            icon={<PeopleIcon />} 
            color="#1976d2"
          />
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <StatCard 
            title="Réfugiés Actifs" 
            value={stats.refugees.active} 
            icon={<PeopleIcon />} 
            color="#4caf50"
          />
        </Grid>
        
        {/* Statistiques des distributions */}
        <Grid item xs={12} sm={6} md={3}>
          <StatCard 
            title="Distributions Totales" 
            value={stats.distributions.total} 
            icon={<DistributionIcon />} 
            color="#ff9800"
          />
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <StatCard 
            title="Distributions En Attente" 
            value={stats.distributions.pending} 
            icon={<DistributionIcon />} 
            color="#f44336"
          />
        </Grid>
        
        {/* Statistiques des stocks */}
        <Grid item xs={12} sm={6} md={6}>
          <StatCard 
            title="Produits en Stock" 
            value={stats.stock.totalItems} 
            icon={<InventoryIcon />} 
            color="#673ab7"
          />
        </Grid>
        <Grid item xs={12} sm={6} md={6}>
          <StatCard 
            title="Produits en Stock Faible" 
            value={stats.stock.lowStock} 
            icon={<WarningIcon />} 
            color="#e91e63"
          />
        </Grid>
        
        {/* Résumé des activités récentes */}
        <Grid item xs={12}>
          <Paper sx={{ p: 3 }}>
            <Typography variant="h6" gutterBottom>
              Activités Récentes
            </Typography>
            <Divider sx={{ my: 2 }} />
            <Typography variant="body1">
              Les données d'activités récentes seront affichées ici lorsqu'elles seront disponibles.
            </Typography>
          </Paper>
        </Grid>
      </Grid>
    </Container>
  );
}

export default Dashboard;