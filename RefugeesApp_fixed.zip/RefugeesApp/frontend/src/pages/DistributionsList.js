import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Container,
  Paper,
  Typography,
  Box,
  Button,
  TextField,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TablePagination,
  IconButton,
  Chip,
  InputAdornment,
  CircularProgress,
  Dialog,
  DialogActions,
  DialogContent,
  DialogContentText,
  DialogTitle,
} from '@mui/material';
import {
  Add as AddIcon,
  Search as SearchIcon,
  Edit as EditIcon,
  Delete as DeleteIcon,
  Visibility as VisibilityIcon,
  CheckCircle as CheckCircleIcon,
} from '@mui/icons-material';
// Import du service réel (commenté pendant le développement sans backend)
// import distributionService from '../services/distributionService';

// Import du service mock pour le développement sans backend
import distributionService from '../services/distributionService';

function DistributionsList() {
  const navigate = useNavigate();
  const [distributions, setDistributions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(10);
  const [totalCount, setTotalCount] = useState(0);
  const [searchTerm, setSearchTerm] = useState('');
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [distributionToDelete, setDistributionToDelete] = useState(null);
  const [completeDialogOpen, setCompleteDialogOpen] = useState(false);
  const [distributionToComplete, setDistributionToComplete] = useState(null);

  // Utilisation de useCallback pour mémoriser fetchDistributions
  const fetchDistributions = React.useCallback(async (pageNum = page, limit = rowsPerPage, search = searchTerm) => {
    try {
      setLoading(true);
      const data = await distributionService.getAll(pageNum + 1, limit, search);
      if (data && Array.isArray(data.results) && typeof data.count === 'number') {
        setDistributions(data.results);
        setTotalCount(data.count);
        setError(null);
      } else {
        console.error('DistributionsList: Invalid data structure received from API:', data);
        setDistributions([]);
        setTotalCount(0);
        // setError('Format de données invalide reçu du serveur.'); // Message retiré comme demandé
      }
    } catch (err) {
      console.error('Error fetching distributions:', err);
      setDistributions([]);
      setTotalCount(0);
      const errorMessage = err.response?.data?.detail || 'Erreur lors du chargement des distributions.';
      setError(errorMessage);
    } finally {
      setLoading(false);
    }
  }, [page, rowsPerPage, searchTerm]); // Ajout des dépendances pour useCallback

  useEffect(() => {
    fetchDistributions();
  }, [fetchDistributions]); // Ajout de fetchDistributions comme dépendance

  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  const handleSearch = (e) => {
    e.preventDefault();
    setPage(0);
    fetchDistributions(0, rowsPerPage, searchTerm);
  };

  const handleViewDistribution = (id) => {
    navigate(`/distributions/${id}`);
  };

  const handleEditDistribution = (id) => {
    navigate(`/distributions/${id}`);
  };

  const handleDeleteClick = (distribution) => {
    setDistributionToDelete(distribution);
    setDeleteDialogOpen(true);
  };

  const handleDeleteConfirm = async () => {
    if (!distributionToDelete) return;

    try {
      await distributionService.delete(distributionToDelete.id);
      fetchDistributions();
      setDeleteDialogOpen(false);
      setDistributionToDelete(null);
    } catch (err) {
      setError('Erreur lors de la suppression de la distribution');
      console.error('Error deleting distribution:', err);
    }
  };

  const handleDeleteCancel = () => {
    setDeleteDialogOpen(false);
    setDistributionToDelete(null);
  };

  const handleCompleteClick = (distribution) => {
    setDistributionToComplete(distribution);
    setCompleteDialogOpen(true);
  };

  const handleCompleteConfirm = async () => {
    if (!distributionToComplete) return;

    try {
      await distributionService.markAsCompleted(distributionToComplete.id);
      fetchDistributions();
      setCompleteDialogOpen(false);
      setDistributionToComplete(null);
    } catch (err) {
      setError('Erreur lors de la finalisation de la distribution');
      console.error('Error completing distribution:', err);
    }
  };

  const handleCompleteCancel = () => {
    setCompleteDialogOpen(false);
    setDistributionToComplete(null);
  };

  const getStatusChip = (status) => {
    let color = 'default';
    switch (status) {
      case 'Pending':
        color = 'warning';
        break;
      case 'In Progress':
        color = 'info';
        break;
      case 'Completed':
        color = 'success';
        break;
      case 'Cancelled':
        color = 'error';
        break;
      default:
        color = 'default';
    }
    return <Chip label={status} color={color} size="small" />;
  };

  return (
    <Container maxWidth="lg">
      <Box sx={{ mt: 4, mb: 4 }}>
        <Typography variant="h4" gutterBottom>
          Gestion des Distributions
        </Typography>
        <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 2 }}>
          <form onSubmit={handleSearch}>
            <TextField
              variant="outlined"
              size="small"
              placeholder="Rechercher..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              InputProps={{
                startAdornment: (
                  <InputAdornment position="start">
                    <SearchIcon />
                  </InputAdornment>
                ),
              }}
            />
          </form>
          <Button
            variant="contained"
            color="primary"
            startIcon={<AddIcon />}
            onClick={() => navigate('/distributions/new')}
          >
            Nouvelle Distribution
          </Button>
        </Box>

        {error && (
          <Typography color="error" sx={{ mb: 2 }}>
            {error}
          </Typography>
        )}

        <Paper sx={{ width: '100%', overflow: 'hidden' }}>
          {loading ? (
            <Box sx={{ display: 'flex', justifyContent: 'center', p: 3 }}>
              <CircularProgress />
            </Box>
          ) : (
            <>
              <TableContainer sx={{ maxHeight: 440 }}>
                <Table stickyHeader aria-label="sticky table">
                  <TableHead>
                    <TableRow>
                      <TableCell>ID</TableCell>
                      <TableCell>Date</TableCell>
                      <TableCell>Lieu</TableCell>
                      <TableCell>Nombre de Bénéficiaires</TableCell>
                      <TableCell>Statut</TableCell>
                      <TableCell align="right">Actions</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {distributions.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={6} align="center">
                          Aucune distribution trouvée
                        </TableCell>
                      </TableRow>
                    ) : (
                      distributions.map((distribution) => (
                        <TableRow hover key={distribution.id}>
                          <TableCell>{distribution.id}</TableCell>
                          <TableCell>{new Date(distribution.date).toLocaleDateString()}</TableCell>
                          <TableCell>{distribution.location}</TableCell>
                          <TableCell>{distribution.beneficiaries_count}</TableCell>
                          <TableCell>{getStatusChip(distribution.status)}</TableCell>
                          <TableCell align="right">
                            <IconButton
                              color="primary"
                              onClick={() => handleViewDistribution(distribution.id)}
                              size="small"
                            >
                              <VisibilityIcon fontSize="small" />
                            </IconButton>
                            <IconButton
                              color="secondary"
                              onClick={() => handleEditDistribution(distribution.id)}
                              size="small"
                              disabled={distribution.status === 'Completed'}
                            >
                              <EditIcon fontSize="small" />
                            </IconButton>
                            <IconButton
                              color="success"
                              onClick={() => handleCompleteClick(distribution)}
                              size="small"
                              disabled={distribution.status === 'Completed'}
                            >
                              <CheckCircleIcon fontSize="small" />
                            </IconButton>
                            <IconButton
                              color="error"
                              onClick={() => handleDeleteClick(distribution)}
                              size="small"
                              disabled={distribution.status === 'Completed'}
                            >
                              <DeleteIcon fontSize="small" />
                            </IconButton>
                          </TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </TableContainer>
              <TablePagination
                rowsPerPageOptions={[5, 10, 25]}
                component="div"
                count={totalCount}
                rowsPerPage={rowsPerPage}
                page={page}
                onPageChange={handleChangePage}
                onRowsPerPageChange={handleChangeRowsPerPage}
                labelRowsPerPage="Lignes par page:"
              />
            </>
          )}
        </Paper>
      </Box>

      {/* Dialogue de confirmation de suppression */}
      <Dialog
        open={deleteDialogOpen}
        onClose={handleDeleteCancel}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description"
      >
        <DialogTitle id="alert-dialog-title">
          Confirmer la suppression
        </DialogTitle>
        <DialogContent>
          <DialogContentText id="alert-dialog-description">
            Êtes-vous sûr de vouloir supprimer cette distribution ? Cette action est irréversible.
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleDeleteCancel}>Annuler</Button>
          <Button onClick={handleDeleteConfirm} color="error" autoFocus>
            Supprimer
          </Button>
        </DialogActions>
      </Dialog>

      {/* Dialogue de confirmation de finalisation */}
      <Dialog
        open={completeDialogOpen}
        onClose={handleCompleteCancel}
        aria-labelledby="complete-dialog-title"
        aria-describedby="complete-dialog-description"
      >
        <DialogTitle id="complete-dialog-title">
          Confirmer la finalisation
        </DialogTitle>
        <DialogContent>
          <DialogContentText id="complete-dialog-description">
            Êtes-vous sûr de vouloir marquer cette distribution comme terminée ? Cette action est irréversible.
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCompleteCancel}>Annuler</Button>
          <Button onClick={handleCompleteConfirm} color="primary" autoFocus>
            Confirmer
          </Button>
        </DialogActions>
      </Dialog>
    </Container>
  );
}

export default DistributionsList;