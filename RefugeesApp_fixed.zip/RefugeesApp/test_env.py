import os
import sys
import platform

print("=== Environment Information ===")
print(f"Python Version: {sys.version}")
print(f"Platform: {platform.platform()}")
print(f"Current Working Directory: {os.getcwd()}")
print(f"Python Executable: {sys.executable}")
print("\n=== Python Path ===")
for path in sys.path:
    print(f"- {path}")

print("\n=== Environment Variables ===")
for key, value in os.environ.items():
    if 'PYTHON' in key or 'DJANGO' in key or 'PATH' in key:
        print(f"{key}: {value}")

print("\n=== Django Installation Check ===")
try:
    import django
    print(f"Django Version: {django.get_version()}")
    print(f"Django Path: {django.__file__}")
    
    # Try to import the settings module
    try:
        from refugee_management.refugee_management import settings
        print("\nSuccessfully imported settings module:")
        print(f"- DEBUG: {settings.DEBUG}")
        print(f"- INSTALLED_APPS: {settings.INSTALLED_APPS}")
    except ImportError as e:
        print(f"\nError importing settings: {e}")
        import traceback
        traceback.print_exc()
    
except ImportError:
    print("Django is not installed or not in the Python path.")
    print("Try running: pip install django")
