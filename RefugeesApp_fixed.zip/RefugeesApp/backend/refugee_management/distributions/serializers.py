from rest_framework import serializers
from .models import Distribution, DistributionItem, DistributionItem_Distribution, DistributionRecipient
from refugees.serializers import RefugeeSerializer


class DistributionItemSerializer(serializers.ModelSerializer):
    """Sérialiseur pour le modèle DistributionItem."""
    
    class Meta:
        model = DistributionItem
        fields = ['id', 'name', 'description', 'unit', 'created_at', 'updated_at']
        read_only_fields = ['id', 'created_at', 'updated_at']


class DistributionItemDistributionSerializer(serializers.ModelSerializer):
    """Sérialiseur pour le modèle DistributionItem_Distribution."""
    
    item_details = DistributionItemSerializer(source='item', read_only=True)
    
    class Meta:
        model = DistributionItem_Distribution
        fields = ['id', 'item', 'item_details', 'quantity']
        read_only_fields = ['id']


class DistributionRecipientSerializer(serializers.ModelSerializer):
    """Sérialiseur pour le modèle DistributionRecipient."""
    
    refugee_details = RefugeeSerializer(source='refugee', read_only=True)
    
    class Meta:
        model = DistributionRecipient
        fields = ['id', 'refugee', 'refugee_details', 'status', 'received_at', 'notes']
        read_only_fields = ['id', 'received_at']


class DistributionSerializer(serializers.ModelSerializer):
    """Sérialiseur pour le modèle Distribution."""
    
    distribution_items = DistributionItemDistributionSerializer(many=True, read_only=True)
    distribution_recipients = DistributionRecipientSerializer(many=True, read_only=True)
    status_display = serializers.CharField(source='get_status_display', read_only=True)
    is_upcoming = serializers.BooleanField(read_only=True)
    is_past_due = serializers.BooleanField(read_only=True)
    
    class Meta:
        model = Distribution
        fields = [
            'id', 'distribution_id', 'title', 'description', 'location',
            'distribution_date', 'status', 'status_display', 'is_upcoming',
            'is_past_due', 'distribution_items', 'distribution_recipients',
            'created_at', 'updated_at'
        ]
        read_only_fields = ['id', 'distribution_id', 'created_at', 'updated_at']


class DistributionCreateSerializer(serializers.ModelSerializer):
    """Sérialiseur pour la création d'une distribution avec ses articles."""
    
    items = serializers.ListField(
        child=serializers.DictField(),
        write_only=True,
        required=False
    )
    
    refugees = serializers.ListField(
        child=serializers.IntegerField(),
        write_only=True,
        required=False
    )
    
    class Meta:
        model = Distribution
        fields = [
            'id', 'title', 'description', 'location', 'distribution_date',
            'status', 'items', 'refugees'
        ]
        read_only_fields = ['id']
    
    def create(self, validated_data):
        items_data = validated_data.pop('items', [])
        refugees_data = validated_data.pop('refugees', [])
        
        distribution = Distribution.objects.create(**validated_data)
        
        # Ajouter les articles à la distribution
        for item_data in items_data:
            item_id = item_data.get('item_id')
            quantity = item_data.get('quantity', 0)
            
            if item_id and quantity > 0:
                try:
                    item = DistributionItem.objects.get(pk=item_id)
                    DistributionItem_Distribution.objects.create(
                        distribution=distribution,
                        item=item,
                        quantity=quantity
                    )
                except DistributionItem.DoesNotExist:
                    pass
        
        # Ajouter les réfugiés à la distribution
        for refugee_id in refugees_data:
            try:
                from refugees.models import Refugee
                refugee = Refugee.objects.get(pk=refugee_id)
                DistributionRecipient.objects.create(
                    distribution=distribution,
                    refugee=refugee
                )
            except Refugee.DoesNotExist:
                pass
        
        return distribution