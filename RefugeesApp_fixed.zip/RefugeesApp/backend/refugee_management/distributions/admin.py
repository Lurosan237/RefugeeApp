from django.contrib import admin
from .models import DistributionItem, Distribution, DistributionItem_Distribution, DistributionRecipient


@admin.register(DistributionItem)
class DistributionItemAdmin(admin.ModelAdmin):
    list_display = ('name', 'unit', 'created_at', 'updated_at')
    search_fields = ('name', 'description')


class DistributionItemInline(admin.TabularInline):
    model = DistributionItem_Distribution
    extra = 1


class DistributionRecipientInline(admin.TabularInline):
    model = DistributionRecipient
    extra = 1
    autocomplete_fields = ['refugee']


@admin.register(Distribution)
class DistributionAdmin(admin.ModelAdmin):
    list_display = ('distribution_id', 'title', 'location', 'distribution_date', 'status', 'created_at')
    list_filter = ('status', 'distribution_date', 'location')
    search_fields = ('distribution_id', 'title', 'description', 'location')
    readonly_fields = ('distribution_id', 'created_at', 'updated_at')
    inlines = [DistributionItemInline, DistributionRecipientInline]


@admin.register(DistributionRecipient)
class DistributionRecipientAdmin(admin.ModelAdmin):
    list_display = ('distribution', 'refugee', 'received_at', 'notes')
    list_filter = ('distribution__distribution_date', 'refugee__nationality')
    search_fields = ('distribution__title', 'refugee__first_name', 'refugee__last_name', 'refugee__registration_id')
    autocomplete_fields = ['distribution', 'refugee']


# Note: DistributionItem_Distribution is managed via the DistributionAdmin inline
# admin.site.register(DistributionItem_Distribution)