from django.db import models
from django.utils.translation import gettext_lazy as _
from django.utils import timezone
import uuid
from refugees.models import Refugee

def generate_distribution_id():
    """Génère un identifiant unique pour une distribution."""
    return f"DIST-{uuid.uuid4().hex[:8].upper()}"


class DistributionItem(models.Model):
    """Modèle pour les articles à distribuer."""
    
    name = models.CharField(_('nom'), max_length=100)
    description = models.TextField(_('description'), blank=True, null=True)
    unit = models.CharField(_('unité'), max_length=50, default='kg')
    
    # Métadonnées
    created_at = models.DateTimeField(_('créé le'), auto_now_add=True)
    updated_at = models.DateTimeField(_('mis à jour le'), auto_now=True)
    
    class Meta:
        verbose_name = _('article de distribution')
        verbose_name_plural = _('articles de distribution')
        ordering = ['name']
    
    def __str__(self):
        return self.name


class Distribution(models.Model):
    """Modèle pour les distributions alimentaires."""
    
    class Status(models.TextChoices):
        PLANNED = 'PLANNED', _('Planifiée')
        IN_PROGRESS = 'IN_PROGRESS', _('En cours')
        COMPLETED = 'COMPLETED', _('Terminée')
        CANCELLED = 'CANCELLED', _('Annulée')
    
    # Identifiant unique pour chaque distribution
    distribution_id = models.CharField(
        _('numéro de distribution'),
        max_length=20,
        unique=True,
        default=generate_distribution_id,  # Utiliser la fonction nommée
        help_text=_('Identifiant unique de la distribution')
    )
    
    # Informations sur la distribution
    title = models.CharField(_('titre'), max_length=200)
    description = models.TextField(_('description'), blank=True, null=True)
    location = models.CharField(_('lieu'), max_length=200)
    distribution_date = models.DateTimeField(_('date de distribution'))
    status = models.CharField(
        _('statut'),
        max_length=20,
        choices=Status.choices,
        default=Status.PLANNED
    )
    
    # Relations
    refugees = models.ManyToManyField(
        Refugee,
        through='DistributionRecipient',
        related_name='distributions',
        verbose_name=_('réfugiés')
    )
    
    # Métadonnées
    created_at = models.DateTimeField(_('créé le'), auto_now_add=True)
    updated_at = models.DateTimeField(_('mis à jour le'), auto_now=True)
    
    class Meta:
        verbose_name = _('distribution')
        verbose_name_plural = _('distributions')
        ordering = ['-distribution_date']
    
    def __str__(self):
        return f"{self.distribution_id} - {self.title} ({self.get_status_display()})"
    
    @property
    def is_upcoming(self):
        return self.distribution_date > timezone.now() and self.status == self.Status.PLANNED
    
    @property
    def is_past_due(self):
        return self.distribution_date < timezone.now() and self.status == self.Status.PLANNED


class DistributionItem_Distribution(models.Model):
    """Modèle de liaison entre Distribution et DistributionItem avec quantité."""
    
    distribution = models.ForeignKey(
        Distribution,
        on_delete=models.CASCADE,
        related_name='distribution_items',
        verbose_name=_('distribution')
    )
    item = models.ForeignKey(
        DistributionItem,
        on_delete=models.CASCADE,
        related_name='distributions',
        verbose_name=_('article')
    )
    quantity = models.DecimalField(
        _('quantité'),
        max_digits=10,
        decimal_places=2,
        default=0
    )
    
    class Meta:
        verbose_name = _('article de la distribution')
        verbose_name_plural = _('articles de la distribution')
        unique_together = ['distribution', 'item']
    
    def __str__(self):
        return f"{self.item.name} ({self.quantity} {self.item.unit}) - {self.distribution.title}"


class DistributionRecipient(models.Model):
    """Modèle de liaison entre Distribution et Refugee."""
    
    class Status(models.TextChoices):
        REGISTERED = 'REGISTERED', _('Inscrit')
        RECEIVED = 'RECEIVED', _('Reçu')
        ABSENT = 'ABSENT', _('Absent')
    
    distribution = models.ForeignKey(
        Distribution,
        on_delete=models.CASCADE,
        related_name='distribution_recipients',
        verbose_name=_('distribution')
    )
    refugee = models.ForeignKey(
        Refugee,
        on_delete=models.CASCADE,
        related_name='distribution_receipts',
        verbose_name=_('réfugié')
    )
    status = models.CharField(
        _('statut'),
        max_length=20,
        choices=Status.choices,
        default=Status.REGISTERED
    )
    received_at = models.DateTimeField(_('reçu le'), null=True, blank=True)
    notes = models.TextField(_('notes'), blank=True, null=True)
    
    class Meta:
        verbose_name = _('bénéficiaire de distribution')
        verbose_name_plural = _('bénéficiaires de distribution')
        unique_together = ['distribution', 'refugee']
    
    def __str__(self):
        return f"{self.refugee.get_full_name()} - {self.distribution.title}"
    
    def mark_as_received(self):
        self.status = self.Status.RECEIVED
        self.received_at = timezone.now()
        self.save()