from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import DistributionViewSet, DistributionItemViewSet

router = DefaultRouter()
router.register(r'items', DistributionItemViewSet)
router.register(r'', DistributionViewSet)

urlpatterns = [
    path('', include(router.urls)),
]