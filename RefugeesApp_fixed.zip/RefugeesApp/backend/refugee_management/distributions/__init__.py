"""
Distributions Module

This module handles aid distribution management in the Refugee Management System.
"""

# Comment out early imports to avoid AppRegistryNotReady error
# from . import models  # noqa # noqa