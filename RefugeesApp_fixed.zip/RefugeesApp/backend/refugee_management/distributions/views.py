from rest_framework import viewsets, permissions, status, filters
from rest_framework.decorators import action
from rest_framework.response import Response
from django.utils import timezone
from django.db.models import Q
from .models import Distribution, DistributionItem, DistributionItem_Distribution, DistributionRecipient
from .serializers import (
    DistributionSerializer, DistributionItemSerializer,
    DistributionItemDistributionSerializer, DistributionRecipientSerializer,
    DistributionCreateSerializer
)
from users.permissions import IsAdmin, IsAdminOrManager


class DistributionItemViewSet(viewsets.ModelViewSet):
    """ViewSet pour la gestion des articles de distribution."""
    
    queryset = DistributionItem.objects.all()
    serializer_class = DistributionItemSerializer
    permission_classes = [permissions.IsAuthenticated, IsAdminOrManager]
    filter_backends = [filters.SearchFilter, filters.OrderingFilter]
    search_fields = ['name', 'description']
    ordering_fields = ['name', 'created_at']
    ordering = ['name']


from django.db.models import Count, Q # Import Count and Q

class DistributionViewSet(viewsets.ModelViewSet):
    """ViewSet pour la gestion des distributions."""
    
    queryset = Distribution.objects.all()
    permission_classes = [permissions.IsAuthenticated, IsAdminOrManager]
    filter_backends = [filters.SearchFilter, filters.OrderingFilter]
    search_fields = ['title', 'description', 'location']
    ordering_fields = ['distribution_date', 'status', 'created_at']
    ordering = ['-distribution_date']
    
    def get_serializer_class(self):
        if self.action == 'create':
            return DistributionCreateSerializer
        return DistributionSerializer
    
    @action(detail=False, methods=['get'], permission_classes=[permissions.IsAuthenticated, IsAdminOrManager])
    def statistics(self, request):
        total_distributions = Distribution.objects.count()
        pending_distributions = Distribution.objects.filter(status=Distribution.Status.PLANNED).count()
        # Assuming 'COMPLETED' is a status. Adjust if the status name is different.
        completed_distributions = Distribution.objects.filter(status=Distribution.Status.COMPLETED).count() 
        # Add other relevant statuses if needed, e.g., IN_PROGRESS

        return Response({
            'total': total_distributions,
            'pending': pending_distributions,
            'completed': completed_distributions
        })

    def get_queryset(self):
        queryset = super().get_queryset()
        
        # Filtrer par statut
        status_param = self.request.query_params.get('status', None)
        if status_param:
            queryset = queryset.filter(status=status_param)
        
        # Filtrer par date (aujourd'hui, cette semaine, ce mois)
        date_filter = self.request.query_params.get('date_filter', None)
        today = timezone.now().date()
        
        if date_filter == 'today':
            queryset = queryset.filter(distribution_date__date=today)
        elif date_filter == 'week':
            start_of_week = today - timezone.timedelta(days=today.weekday())
            end_of_week = start_of_week + timezone.timedelta(days=6)
            queryset = queryset.filter(distribution_date__date__range=[start_of_week, end_of_week])
        elif date_filter == 'month':
            queryset = queryset.filter(
                distribution_date__year=today.year,
                distribution_date__month=today.month
            )
        elif date_filter == 'upcoming':
            queryset = queryset.filter(
                distribution_date__gt=timezone.now(),
                status=Distribution.Status.PLANNED
            )
        
        return queryset
    
    @action(detail=True, methods=['post'])
    def add_item(self, request, pk=None):
        """Ajoute un article à la distribution."""
        distribution = self.get_object()
        item_id = request.data.get('item_id')
        quantity = request.data.get('quantity', 0)
        
        if not item_id or quantity <= 0:
            return Response(
                {'error': 'L\'identifiant de l\'article et une quantité positive sont requis.'},
                status=status.HTTP_400_BAD_REQUEST
            )
        
        try:
            item = DistributionItem.objects.get(pk=item_id)
            
            # Vérifier si l'article existe déjà dans la distribution
            distribution_item, created = DistributionItem_Distribution.objects.get_or_create(
                distribution=distribution,
                item=item,
                defaults={'quantity': quantity}
            )
            
            if not created:
                distribution_item.quantity = quantity
                distribution_item.save()
            
            serializer = DistributionItemDistributionSerializer(distribution_item)
            return Response(serializer.data)
            
        except DistributionItem.DoesNotExist:
            return Response(
                {'error': 'Article non trouvé.'},
                status=status.HTTP_404_NOT_FOUND
            )
    
    @action(detail=True, methods=['post'])
    def remove_item(self, request, pk=None):
        """Supprime un article de la distribution."""
        distribution = self.get_object()
        item_id = request.data.get('item_id')
        
        if not item_id:
            return Response(
                {'error': 'L\'identifiant de l\'article est requis.'},
                status=status.HTTP_400_BAD_REQUEST
            )
        
        try:
            distribution_item = DistributionItem_Distribution.objects.get(
                distribution=distribution,
                item_id=item_id
            )
            distribution_item.delete()
            return Response(status=status.HTTP_204_NO_CONTENT)
            
        except DistributionItem_Distribution.DoesNotExist:
            return Response(
                {'error': 'Article non trouvé dans cette distribution.'},
                status=status.HTTP_404_NOT_FOUND
            )
    
    @action(detail=True, methods=['post'])
    def add_refugee(self, request, pk=None):
        """Ajoute un réfugié à la distribution."""
        distribution = self.get_object()
        refugee_id = request.data.get('refugee_id')
        
        if not refugee_id:
            return Response(
                {'error': 'L\'identifiant du réfugié est requis.'},
                status=status.HTTP_400_BAD_REQUEST
            )
        
        try:
            from refugees.models import Refugee
            refugee = Refugee.objects.get(pk=refugee_id)
            
            # Vérifier si le réfugié existe déjà dans la distribution
            recipient, created = DistributionRecipient.objects.get_or_create(
                distribution=distribution,
                refugee=refugee
            )
            
            serializer = DistributionRecipientSerializer(recipient)
            return Response(serializer.data)
            
        except Refugee.DoesNotExist:
            return Response(
                {'error': 'Réfugié non trouvé.'},
                status=status.HTTP_404_NOT_FOUND
            )
    
    @action(detail=True, methods=['post'])
    def remove_refugee(self, request, pk=None):
        """Supprime un réfugié de la distribution."""
        distribution = self.get_object()
        refugee_id = request.data.get('refugee_id')
        
        if not refugee_id:
            return Response(
                {'error': 'L\'identifiant du réfugié est requis.'},
                status=status.HTTP_400_BAD_REQUEST
            )
        
        try:
            recipient = DistributionRecipient.objects.get(
                distribution=distribution,
                refugee_id=refugee_id
            )
            recipient.delete()
            return Response(status=status.HTTP_204_NO_CONTENT)
            
        except DistributionRecipient.DoesNotExist:
            return Response(
                {'error': 'Réfugié non trouvé dans cette distribution.'},
                status=status.HTTP_404_NOT_FOUND
            )
    
    @action(detail=True, methods=['post'])
    def update_recipient_status(self, request, pk=None):
        """Met à jour le statut d'un bénéficiaire de la distribution."""
        distribution = self.get_object()
        refugee_id = request.data.get('refugee_id')
        new_status = request.data.get('status')
        notes = request.data.get('notes', '')
        
        if not refugee_id or not new_status:
            return Response(
                {'error': 'L\'identifiant du réfugié et le nouveau statut sont requis.'},
                status=status.HTTP_400_BAD_REQUEST
            )
        
        try:
            recipient = DistributionRecipient.objects.get(
                distribution=distribution,
                refugee_id=refugee_id
            )
            
            # Vérifier si le statut est valide
            if new_status not in dict(DistributionRecipient.Status.choices):
                return Response(
                    {'error': 'Statut invalide.'},
                    status=status.HTTP_400_BAD_REQUEST
                )
            
            recipient.status = new_status
            recipient.notes = notes
            
            # Si le statut est RECEIVED, mettre à jour la date de réception
            if new_status == DistributionRecipient.Status.RECEIVED:
                recipient.received_at = timezone.now()
            
            recipient.save()
            serializer = DistributionRecipientSerializer(recipient)
            return Response(serializer.data)
            
        except DistributionRecipient.DoesNotExist:
            return Response(
                {'error': 'Réfugié non trouvé dans cette distribution.'},
                status=status.HTTP_404_NOT_FOUND
            )
    
    @action(detail=True, methods=['post'])
    def update_status(self, request, pk=None):
        """Met à jour le statut de la distribution."""
        distribution = self.get_object()
        new_status = request.data.get('status')
        
        if not new_status:
            return Response(
                {'error': 'Le nouveau statut est requis.'},
                status=status.HTTP_400_BAD_REQUEST
            )
        
        # Vérifier si le statut est valide
        if new_status not in dict(Distribution.Status.choices):
            return Response(
                {'error': 'Statut invalide.'},
                status=status.HTTP_400_BAD_REQUEST
            )
        
        distribution.status = new_status
        distribution.save()
        
        serializer = self.get_serializer(distribution)
        return Response(serializer.data)