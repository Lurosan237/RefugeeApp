from django.contrib import admin
from django.urls import path, include
from django.views.generic import RedirectView
from django.conf import settings
from django.conf.urls.static import static
from rest_framework_simplejwt.views import TokenRefreshView
from users.views import MyTokenObtainPairView # Importer la vue personnalisée

urlpatterns = [
    path('admin/', admin.site.urls),
    # JWT Authentication endpoints
    path('api/token/', MyTokenObtainPairView.as_view(), name='token_obtain_pair'), # Utiliser la vue personnalisée
    path('api/token/refresh/', TokenRefreshView.as_view(), name='token_refresh'),
    # API endpoints
    path('api/users/', include('users.urls')),
    path('api/refugees/', include('refugees.urls')),
    path('api/distributions/', include('distributions.urls')),
    path('api/stocks/', include('stocks.urls')),
    path('api/reports/', include('reports.urls')),
    # Redirect root to admin login
    path('', RedirectView.as_view(url='/admin/', permanent=True)),
]

# Serve media files in development
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
    urlpatterns += [
        path('__debug__/', include('debug_toolbar.urls')),
    ]