from rest_framework import serializers
from datetime import datetime, date
from .models import Refugee

class RefugeeSerializer(serializers.ModelSerializer):
    date_of_birth = serializers.DateField(required=False, allow_null=True)
    arrival_date = serializers.DateField(required=True)

    class Meta:
        model = Refugee
        fields = '__all__'

    def to_representation(self, instance):
        data = super().to_representation(instance)
        # Format dates as YYYY-MM-DD strings
        if isinstance(instance.date_of_birth, (datetime, date)):
            data['date_of_birth'] = instance.date_of_birth.strftime('%Y-%m-%d')
        if isinstance(instance.arrival_date, (datetime, date)):
            data['arrival_date'] = instance.arrival_date.strftime('%Y-%m-%d')
        return data

    def validate_date_of_birth(self, value):
        if value and isinstance(value, str):
            try:
                return datetime.strptime(value, '%Y-%m-%d').date()
            except ValueError:
                raise serializers.ValidationError("Invalid date format. Use YYYY-MM-DD")
        return value

    def validate_arrival_date(self, value):
        if value and isinstance(value, str):
            try:
                return datetime.strptime(value, '%Y-%m-%d').date()
            except ValueError:
                raise serializers.ValidationError("Invalid date format. Use YYYY-MM-DD")
        return value

    def validate(self, data):
        if data.get('date_of_birth') and data.get('arrival_date'):
            if data['date_of_birth'] > data['arrival_date']:
                raise serializers.ValidationError(
                    {"date_of_birth": "Date of birth cannot be after arrival date"}
                )
        return data