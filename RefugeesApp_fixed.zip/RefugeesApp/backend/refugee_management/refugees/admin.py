from django.contrib import admin
from django.utils.translation import gettext_lazy as _
from django.utils import timezone
import uuid
from .models import Refugee

class RefugeeAdmin(admin.ModelAdmin):
    readonly_fields = ('registration_date', 'registration_id')
    list_display = ('registration_id', 'first_name', 'last_name', 'nationality', 'registration_date')
    search_fields = ('registration_id', 'first_name', 'last_name')
    list_filter = ('nationality', 'gender')
    fieldsets = (
        (None, {
            'fields': (('first_name', 'last_name'), 'registration_id')
        }),
        (_('Personal Information'), {
            'fields': ('gender', 'date_of_birth', 'nationality', 'arrival_date')
        }),
        (_('Status'), {
            'fields': ('registration_date',)
        })
    )

    def save_model(self, request, obj, form, change):
        if not obj.registration_id:
            obj.registration_id = f"R{timezone.now().strftime('%Y%m')}-{uuid.uuid4().hex[:6].upper()}"
        super().save_model(request, obj, form, change)

admin.site.register(Refugee, RefugeeAdmin)