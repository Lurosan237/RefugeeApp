from rest_framework import viewsets
from .models import Refugee
from .serializers import RefugeeSerializer

from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework import permissions # Assurez-vous que permissions est importé
from users.permissions import IsAdminOrManager # Importer la permission personnalisée
from rest_framework import status

class RefugeeViewSet(viewsets.ModelViewSet):
    queryset = Refugee.objects.all()
    serializer_class = RefugeeSerializer
    permission_classes = [permissions.IsAuthenticated, IsAdminOrManager]

    @action(detail=False, methods=['get'])
    def statistics(self, request):
        try:
            total_refugees = Refugee.objects.count()
            active_refugees = Refugee.objects.filter(is_active=True).count()
            
            return Response({
                'total': total_refugees,
                'active': active_refugees
            })
        except Exception as e:
            return Response(
                {'error': str(e)},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )