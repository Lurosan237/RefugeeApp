from django.db import models
from django.utils.translation import gettext_lazy as _

class BaseRefugee(models.Model):
    registration_id = models.CharField(
        _('numéro d\'enregistrement'),
        max_length=50,
        unique=True,
        editable=False
    )
    first_name = models.CharField(_('prénom'), max_length=100)
    last_name = models.CharField(_('nom'), max_length=100)
    gender = models.CharField(
        _('genre'),
        max_length=1,
        choices=[
            ('M', _('Masculin')),
            ('F', _('Féminin')),
            ('O', _('Autre'))
        ]
    )
    date_of_birth = models.DateField(_('date de naissance'), null=True, blank=True)
    nationality = models.CharField(_('nationalité'), max_length=100)
    arrival_date = models.DateField(_('date d\'arrivée'))
    registration_date = models.DateField(_('date d\'enregistrement'), auto_now_add=True)

    class Meta:
        abstract = True