"""
Refugees Module

This module handles refugee registration and management in the Refugee Management System.
"""

# Comment out early imports to avoid AppRegistryNotReady error
# from . import models  # noqa