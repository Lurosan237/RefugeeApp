from django.db import models
from django.utils.translation import gettext_lazy as _
from django.utils import timezone
import uuid
from .base_models import RefugeeBase

def generate_registration_id():
    """
    Generate a unique registration ID for refugees.
    Format: R{YEAR}{MONTH}-{6 random chars}
    Example: R202505-A1B2C3
    """
    return f"R{timezone.now().strftime('%Y%m')}-{uuid.uuid4().hex[:6].upper()}"

class Refugee(RefugeeBase):
    class Meta:
        verbose_name = 'réfugié'
        verbose_name_plural = 'réfugiés'
        ordering = ['-registration_date', 'last_name', 'first_name']

    def __str__(self):
        return f"{self.first_name} {self.last_name} ({self.registration_id})"

    def save(self, *args, **kwargs):
        if not self.registration_id:
            self.registration_id = generate_registration_id()
        super().save(*args, **kwargs)
