from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import RefugeeViewSet

router = DefaultRouter()
router.register(r'', RefugeeViewSet, basename='refugee')

# Assurez-vous que les routes pour les actions personnalisées sont correctement exposées
urlpatterns = [
    path('', include(router.urls)),
    # Ajout explicite de la route statistics pour garantir son exposition
    path('statistics/', RefugeeViewSet.as_view({'get': 'statistics'}), name='refugee-statistics'),
]
