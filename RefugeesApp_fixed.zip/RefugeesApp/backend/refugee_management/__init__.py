"""
Refugee Management System - Main Package

This is the main package for the Refugee Management System.
"""

# Import all submodules to ensure they're registered properly
try:
    import refugee_management.users
except ImportError as e:
    print(f"Warning: Could not import users module: {e}")

try:
    import refugee_management.refugees
except ImportError as e:
    print(f"Warning: Could not import refugees module: {e}")

try:
    import refugee_management.distributions
except ImportError as e:
    print(f"Warning: Could not import distributions module: {e}")

try:
    import refugee_management.stocks
except ImportError as e:
    print(f"Warning: Could not import stocks module: {e}")

try:
    import refugee_management.reports
except ImportError as e:
    print(f"Warning: Could not import reports module: {e}")

__all__ = [
    'users',
    'refugees',
    'distributions',
    'stocks',
    'reports',
]
