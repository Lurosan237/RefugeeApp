"""
Users Module

This module handles user authentication and authorization in the Refugee Management System.
"""

# Comment out early imports to avoid AppRegistryNotReady error
# from . import models  # noqa