from django.contrib.auth.backends import ModelBackend
from django.contrib.auth import get_user_model

User = get_user_model()

class EmailBackend(ModelBackend):
    """
    Backend d'authentification personnalisé qui permet l'authentification avec l'email.
    """
    def authenticate(self, request, username=None, password=None, email=None, **kwargs):
        # Si l'email est fourni directement, l'utiliser
        if email is None:
            # Sinon, utiliser le username comme email
            email = username
            
        if email is None or password is None:
            return None
            
        try:
            # Rechercher l'utilisateur par email
            user = User.objects.get(email=email)
            
            # Vérifier le mot de passe
            if user.check_password(password):
                return user
                
        except User.DoesNotExist:
            # Exécuter la méthode de hachage du mot de passe pour éviter les attaques par timing
            User().set_password(password)
            
        return None
