from rest_framework import permissions


class IsAdmin(permissions.BasePermission):
    """Permission personnalisée pour restreindre l'accès aux administrateurs."""
    
    def has_permission(self, request, view):
        return request.user and request.user.is_authenticated and request.user.is_admin


class IsManager(permissions.BasePermission):
    """Permission personnalisée pour restreindre l'accès aux gestionnaires."""
    
    def has_permission(self, request, view):
        return request.user and request.user.is_authenticated and request.user.is_manager


class IsAdminOrManager(permissions.BasePermission):
    """Permission personnalisée pour restreindre l'accès aux administrateurs ou aux gestionnaires."""

    def has_permission(self, request, view):
        return request.user and request.user.is_authenticated and (request.user.is_admin or request.user.is_manager)