from rest_framework import serializers
from django.contrib.auth import get_user_model
from .models import Admin, Manager
from django.contrib.auth.backends import ModelBackend

User = get_user_model()


class UserSerializer(serializers.ModelSerializer):
    """Sérialiseur pour le modèle User."""
    
    password = serializers.CharField(write_only=True, required=False)
    
    class Meta:
        model = User
        fields = ['id', 'email', 'first_name', 'last_name', 'user_type', 'password', 'is_active']
        read_only_fields = ['id']
    
    def create(self, validated_data):
        password = validated_data.pop('password', None)
        user = User.objects.create(**validated_data)
        if password:
            user.set_password(password)
            user.save()
        return user
    
    def update(self, instance, validated_data):
        password = validated_data.pop('password', None)
        user = super().update(instance, validated_data)
        if password:
            user.set_password(password)
            user.save()
        return user


class AdminSerializer(serializers.ModelSerializer):
    """Sérialiseur pour le modèle Admin."""
    
    password = serializers.CharField(write_only=True, required=False)
    
    class Meta:
        model = Admin
        fields = ['id', 'email', 'first_name', 'last_name', 'password', 'is_active']
        read_only_fields = ['id']
    
    def create(self, validated_data):
        password = validated_data.pop('password', None)
        admin = Admin.objects.create(**validated_data)
        if password:
            admin.set_password(password)
            admin.save()
        return admin
    
    def update(self, instance, validated_data):
        password = validated_data.pop('password', None)
        admin = super().update(instance, validated_data)
        if password:
            admin.set_password(password)
            admin.save()
        return admin


from rest_framework_simplejwt.serializers import TokenObtainPairSerializer
from rest_framework_simplejwt.views import TokenObtainPairView

class MyTokenObtainPairSerializer(TokenObtainPairSerializer):
    username_field = 'email'
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['email'] = serializers.CharField(required=True)
        self.fields['password'] = serializers.CharField(required=True, style={'input_type': 'password'})
        self.fields.pop('username', None)  # Supprimer le champ username
    
    def validate(self, attrs):
        # Utiliser l'email comme identifiant pour l'authentification
        attrs['username'] = attrs.get('email')
        return super().validate(attrs)
    
    @classmethod
    def get_token(cls, user):
        token = super().get_token(user)

        # Add custom claims
        token['user_type'] = user.user_type
        # Si vous voulez l'appeler 'role' dans le token pour correspondre à PrivateRoute.js
        token['role'] = user.user_type 
        token['email'] = user.email
        token['first_name'] = user.first_name
        token['last_name'] = user.last_name

        return token

class ManagerSerializer(serializers.ModelSerializer):
    """Sérialiseur pour le modèle Manager."""
    
    password = serializers.CharField(write_only=True, required=False)
    
    class Meta:
        model = Manager
        fields = ['id', 'email', 'first_name', 'last_name', 'password', 'is_active']
        read_only_fields = ['id']
    
    def create(self, validated_data):
        password = validated_data.pop('password', None)
        manager = Manager.objects.create(**validated_data)
        if password:
            manager.set_password(password)
            manager.save()
        return manager
    
    def update(self, instance, validated_data):
        password = validated_data.pop('password', None)
        manager = super().update(instance, validated_data)
        if password:
            manager.set_password(password)
            manager.save()
        return manager
