from django.db import models
from django.contrib.auth.models import AbstractUser, BaseUserManager
from django.utils.translation import gettext_lazy as _


class UserManager(BaseUserManager):
    """Gestionnaire personnalisé pour le modèle User."""
    
    def create_user(self, email, password=None, **extra_fields):
        """Crée et enregistre un utilisateur avec l'email et le mot de passe donnés."""
        if not email:
            raise ValueError(_('L\'email est obligatoire'))
        email = self.normalize_email(email)
        user = self.model(email=email, **extra_fields)
        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_superuser(self, email, password=None, **extra_fields):
        """Crée et enregistre un superutilisateur avec l'email et le mot de passe donnés."""
        extra_fields.setdefault('is_staff', True)
        extra_fields.setdefault('is_superuser', True)
        extra_fields.setdefault('is_active', True)
        extra_fields.setdefault('user_type', User.Types.ADMIN)
        
        if extra_fields.get('is_staff') is not True:
            raise ValueError(_('Le superutilisateur doit avoir is_staff=True.'))
        if extra_fields.get('is_superuser') is not True:
            raise ValueError(_('Le superutilisateur doit avoir is_superuser=True.'))
        
        return self.create_user(email, password, **extra_fields)


class User(AbstractUser):
    """Modèle d'utilisateur personnalisé avec email comme identifiant unique."""
    
    class Types(models.TextChoices):
        ADMIN = 'ADMIN', _('Administrateur')
        MANAGER = 'MANAGER', _('Gestionnaire')
    
    username = None
    email = models.EmailField(_('adresse email'), unique=True)
    first_name = models.CharField(_('prénom'), max_length=150)
    last_name = models.CharField(_('nom'), max_length=150)
    user_type = models.CharField(
        _('type d\'utilisateur'),
        max_length=10,
        choices=Types.choices,
        default=Types.ADMIN,
    )
    date_joined = models.DateTimeField(_('date d\'inscription'), auto_now_add=True)
    
    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = ['first_name', 'last_name']
    
    objects = UserManager()
    
    def __str__(self):
        return f"{self.get_full_name()} ({self.email})"
    
    @property
    def is_admin(self):
        return self.user_type == self.Types.ADMIN
    
    @property
    def is_manager(self):
        return self.user_type == self.Types.MANAGER


class AdminManager(models.Manager):
    """Gestionnaire pour le modèle Admin."""
    
    def get_queryset(self):
        return super().get_queryset().filter(user_type=User.Types.ADMIN)


class Admin(User):
    """Modèle pour les administrateurs (ONG)."""
    
    objects = AdminManager()
    
    class Meta:
        proxy = True
    
    def save(self, *args, **kwargs):
        if not self.pk:
            self.user_type = User.Types.ADMIN
        return super().save(*args, **kwargs)


class ManagerManager(models.Manager):
    """Gestionnaire pour le modèle Manager."""
    
    def get_queryset(self):
        return super().get_queryset().filter(user_type=User.Types.MANAGER)


class Manager(User):
    """Modèle pour les gestionnaires (Chargés de stock)."""
    
    objects = ManagerManager()
    
    class Meta:
        proxy = True
    
    def save(self, *args, **kwargs):
        if not self.pk:
            self.user_type = User.Types.MANAGER
        return super().save(*args, **kwargs)