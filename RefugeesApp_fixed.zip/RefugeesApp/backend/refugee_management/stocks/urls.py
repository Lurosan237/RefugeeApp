from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import StockItemViewSet, StockMovementViewSet, SupplierViewSet, PurchaseViewSet

router = DefaultRouter()
router.register(r'', StockItemViewSet, basename='stock') # Changed 'items' to '' and added basename
router.register(r'movements', StockMovementViewSet)
router.register(r'suppliers', SupplierViewSet)
router.register(r'purchases', PurchaseViewSet)

urlpatterns = [
    path('', include(router.urls)),
]