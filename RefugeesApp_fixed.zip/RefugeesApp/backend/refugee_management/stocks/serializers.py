from rest_framework import serializers
from .models import StockItem, StockMovement, Supplier, Purchase, PurchaseItem
from distributions.serializers import DistributionItemSerializer


class StockItemSerializer(serializers.ModelSerializer):
    """Sérialiseur pour le modèle StockItem."""
    
    item_details = DistributionItemSerializer(source='item', read_only=True)
    is_expired = serializers.BooleanField(read_only=True)
    expires_soon = serializers.BooleanField(read_only=True)
    
    class Meta:
        model = StockItem
        fields = [
            'id', 'item', 'item_details', 'quantity', 'batch_number', 'expiry_date',
            'location', 'notes', 'is_expired', 'expires_soon', 'created_at', 'updated_at'
        ]
        read_only_fields = ['id', 'created_at', 'updated_at']


class StockMovementSerializer(serializers.ModelSerializer):
    """Sérialiseur pour le modèle StockMovement."""
    
    stock_item_details = StockItemSerializer(source='stock_item', read_only=True)
    movement_type_display = serializers.CharField(source='get_movement_type_display', read_only=True)
    created_by_name = serializers.CharField(source='created_by.get_full_name', read_only=True)
    
    class Meta:
        model = StockMovement
        fields = [
            'id', 'stock_item', 'stock_item_details', 'movement_type', 'movement_type_display',
            'quantity', 'reference', 'notes', 'distribution', 'created_at', 'created_by',
            'created_by_name'
        ]
        read_only_fields = ['id', 'created_at', 'created_by', 'created_by_name']
    
    def create(self, validated_data):
        # Récupérer l'utilisateur qui fait la requête
        request = self.context.get('request')
        if request and hasattr(request, 'user'):
            validated_data['created_by'] = request.user
        
        return super().create(validated_data)


class SupplierSerializer(serializers.ModelSerializer):
    """Sérialiseur pour le modèle Supplier."""
    
    class Meta:
        model = Supplier
        fields = [
            'id', 'name', 'contact_person', 'email', 'phone', 'address',
            'notes', 'created_at', 'updated_at'
        ]
        read_only_fields = ['id', 'created_at', 'updated_at']


class PurchaseItemSerializer(serializers.ModelSerializer):
    """Sérialiseur pour le modèle PurchaseItem."""
    
    item_details = DistributionItemSerializer(source='item', read_only=True)
    total_price = serializers.DecimalField(
        max_digits=10, decimal_places=2, read_only=True
    )
    is_fully_received = serializers.BooleanField(read_only=True)
    
    class Meta:
        model = PurchaseItem
        fields = [
            'id', 'purchase', 'item', 'item_details', 'quantity_ordered',
            'quantity_received', 'unit_price', 'total_price', 'is_fully_received',
            'notes'
        ]
        read_only_fields = ['id', 'purchase']


class PurchaseSerializer(serializers.ModelSerializer):
    """Sérialiseur pour le modèle Purchase."""
    
    items = PurchaseItemSerializer(many=True, read_only=True)
    supplier_details = SupplierSerializer(source='supplier', read_only=True)
    status_display = serializers.CharField(source='get_status_display', read_only=True)
    created_by_name = serializers.CharField(source='created_by.get_full_name', read_only=True)
    
    class Meta:
        model = Purchase
        fields = [
            'id', 'supplier', 'supplier_details', 'reference', 'order_date',
            'expected_delivery_date', 'status', 'status_display', 'notes',
            'items', 'created_at', 'updated_at', 'created_by', 'created_by_name'
        ]
        read_only_fields = ['id', 'created_at', 'updated_at', 'created_by', 'created_by_name']
    
    def create(self, validated_data):
        # Récupérer l'utilisateur qui fait la requête
        request = self.context.get('request')
        if request and hasattr(request, 'user'):
            validated_data['created_by'] = request.user
        
        return super().create(validated_data)


class PurchaseCreateSerializer(serializers.ModelSerializer):
    """Sérialiseur pour la création d'un achat avec ses articles."""
    
    items = serializers.ListField(
        child=serializers.DictField(),
        write_only=True,
        required=True
    )
    
    class Meta:
        model = Purchase
        fields = [
            'id', 'supplier', 'reference', 'order_date', 'expected_delivery_date',
            'status', 'notes', 'items'
        ]
        read_only_fields = ['id']
    
    def create(self, validated_data):
        items_data = validated_data.pop('items', [])
        
        # Récupérer l'utilisateur qui fait la requête
        request = self.context.get('request')
        if request and hasattr(request, 'user'):
            validated_data['created_by'] = request.user
        
        purchase = Purchase.objects.create(**validated_data)
        
        # Ajouter les articles à l'achat
        for item_data in items_data:
            item_id = item_data.get('item_id')
            quantity_ordered = item_data.get('quantity_ordered', 0)
            unit_price = item_data.get('unit_price')
            notes = item_data.get('notes', '')
            
            if item_id and quantity_ordered > 0:
                try:
                    from distributions.models import DistributionItem
                    item = DistributionItem.objects.get(pk=item_id)
                    PurchaseItem.objects.create(
                        purchase=purchase,
                        item=item,
                        quantity_ordered=quantity_ordered,
                        unit_price=unit_price,
                        notes=notes
                    )
                except DistributionItem.DoesNotExist:
                    pass
        
        return purchase


class PurchaseReceiveSerializer(serializers.Serializer):
    """Sérialiseur pour la réception d'articles d'un achat."""
    
    items = serializers.ListField(
        child=serializers.DictField(),
        required=True
    )
    
    def validate_items(self, value):
        if not value:
            raise serializers.ValidationError("Au moins un article doit être spécifié.")
        
        for item in value:
            if 'purchase_item_id' not in item:
                raise serializers.ValidationError("L'identifiant de l'article d'achat est requis.")
            if 'quantity_received' not in item:
                raise serializers.ValidationError("La quantité reçue est requise.")
            if float(item['quantity_received']) <= 0:
                raise serializers.ValidationError("La quantité reçue doit être positive.")
        
        return value
    
    def create(self, validated_data):
        items_data = validated_data.get('items', [])
        purchase = None
        received_items = []
        
        # Récupérer l'utilisateur qui fait la requête
        request = self.context.get('request')
        user = request.user if request and hasattr(request, 'user') else None
        
        for item_data in items_data:
            purchase_item_id = item_data.get('purchase_item_id')
            quantity_received = float(item_data.get('quantity_received', 0))
            batch_number = item_data.get('batch_number')
            expiry_date = item_data.get('expiry_date')
            location = item_data.get('location')
            notes = item_data.get('notes', '')
            
            try:
                purchase_item = PurchaseItem.objects.get(pk=purchase_item_id)
                purchase = purchase_item.purchase
                
                # Mettre à jour la quantité reçue
                purchase_item.quantity_received += quantity_received
                purchase_item.save()
                
                # Créer ou mettre à jour l'article en stock
                stock_item, created = StockItem.objects.get_or_create(
                    item=purchase_item.item,
                    batch_number=batch_number,
                    expiry_date=expiry_date,
                    defaults={
                        'quantity': 0,
                        'location': location,
                        'notes': notes
                    }
                )
                
                # Créer un mouvement de stock
                movement = StockMovement.objects.create(
                    stock_item=stock_item,
                    movement_type=StockMovement.MovementType.IN,
                    quantity=quantity_received,
                    reference=f"Réception commande {purchase.reference or purchase.id}",
                    notes=notes,
                    created_by=user
                )
                
                received_items.append({
                    'purchase_item': purchase_item,
                    'stock_item': stock_item,
                    'movement': movement
                })
                
            except PurchaseItem.DoesNotExist:
                pass
        
        # Mettre à jour le statut de l'achat si nécessaire
        if purchase:
            all_items = purchase.items.all()
            fully_received = all(item.is_fully_received for item in all_items)
            partially_received = any(item.quantity_received > 0 for item in all_items)
            
            if fully_received:
                purchase.status = Purchase.Status.RECEIVED
            elif partially_received:
                purchase.status = Purchase.Status.PARTIAL
            
            purchase.save()
        
        return received_items