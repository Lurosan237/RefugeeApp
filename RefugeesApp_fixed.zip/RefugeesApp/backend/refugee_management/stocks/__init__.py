"""
Stocks Module

This module handles inventory and stock management in the Refugee Management System.
"""

# Comment out early imports to avoid AppRegistryNotReady error
# from . import models  # noqaels  # noqa