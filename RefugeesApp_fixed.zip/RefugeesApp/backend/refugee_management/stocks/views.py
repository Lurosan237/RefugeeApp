from rest_framework import viewsets, permissions, status, filters
from rest_framework.decorators import action
from rest_framework.response import Response
from django.db.models import Sum, F, Q
from django.utils import timezone
from .models import StockItem, StockMovement, Supplier, Purchase, PurchaseItem
from .serializers import (
    StockItemSerializer, StockMovementSerializer, SupplierSerializer,
    PurchaseSerializer, PurchaseItemSerializer, PurchaseCreateSerializer,
    PurchaseReceiveSerializer
)
from users.permissions import IsAdmin, IsAdminOrManager


class StockItemViewSet(viewsets.ModelViewSet):
    """ViewSet pour la gestion des articles en stock."""
    
    queryset = StockItem.objects.all()
    serializer_class = StockItemSerializer
    permission_classes = [permissions.IsAuthenticated, IsAdminOrManager]
    filter_backends = [filters.SearchFilter, filters.OrderingFilter]
    search_fields = ['item__name', 'batch_number', 'location']
    ordering_fields = ['item__name', 'quantity', 'expiry_date', 'created_at']
    ordering = ['item__name']
    
    def get_queryset(self):
        queryset = super().get_queryset()
        
        # Filtrer par article
        item_id = self.request.query_params.get('item_id', None)
        if item_id:
            queryset = queryset.filter(item_id=item_id)
        
        # Filtrer par date d'expiration
        expiry_filter = self.request.query_params.get('expiry_filter', None)
        today = timezone.now().date()
        
        if expiry_filter == 'expired':
            queryset = queryset.filter(expiry_date__lt=today)
        elif expiry_filter == 'expires_soon':
            thirty_days_later = today + timezone.timedelta(days=30)
            queryset = queryset.filter(expiry_date__range=[today, thirty_days_later])
        elif expiry_filter == 'valid':
            queryset = queryset.filter(Q(expiry_date__gt=today) | Q(expiry_date__isnull=True))
        
        # Filtrer par quantité
        min_quantity = self.request.query_params.get('min_quantity', None)
        if min_quantity:
            queryset = queryset.filter(quantity__gte=float(min_quantity))
        
        max_quantity = self.request.query_params.get('max_quantity', None)
        if max_quantity:
            queryset = queryset.filter(quantity__lte=float(max_quantity))
        
        return queryset
    
    @action(detail=False, methods=['get'])
    def statistics(self, request):
        """Récupère les statistiques des stocks."""
        total_items = StockItem.objects.count()
        total_quantity = StockItem.objects.aggregate(total=Sum('quantity'))['total'] or 0
        
        today = timezone.now().date()
        expired_items = StockItem.objects.filter(expiry_date__lt=today).count()
        thirty_days_later = today + timezone.timedelta(days=30)
        expiring_soon = StockItem.objects.filter(expiry_date__range=[today, thirty_days_later]).count()
        
        low_stock_items = StockItem.objects.filter(quantity__lt=10).count()  # Exemple de seuil
        
        return Response({
            'totalItems': total_items, # Modifié pour correspondre à Dashboard.js
            'total_quantity': total_quantity,
            'expired_items': expired_items,
            'expiring_soon': expiring_soon,
            'lowStock': low_stock_items # Modifié pour correspondre à Dashboard.js
        })


class StockMovementViewSet(viewsets.ModelViewSet):
    """ViewSet pour la gestion des mouvements de stock."""
    
    queryset = StockMovement.objects.all()
    serializer_class = StockMovementSerializer
    permission_classes = [permissions.IsAuthenticated, IsAdminOrManager]
    filter_backends = [filters.SearchFilter, filters.OrderingFilter]
    search_fields = ['stock_item__item__name', 'reference', 'notes']
    ordering_fields = ['created_at', 'movement_type']
    ordering = ['-created_at']
    
    def get_queryset(self):
        queryset = super().get_queryset()
        
        # Filtrer par type de mouvement
        movement_type = self.request.query_params.get('movement_type', None)
        if movement_type:
            queryset = queryset.filter(movement_type=movement_type)
        
        # Filtrer par article
        item_id = self.request.query_params.get('item_id', None)
        if item_id:
            queryset = queryset.filter(stock_item__item_id=item_id)
        
        # Filtrer par date
        start_date = self.request.query_params.get('start_date', None)
        if start_date:
            queryset = queryset.filter(created_at__date__gte=start_date)
        
        end_date = self.request.query_params.get('end_date', None)
        if end_date:
            queryset = queryset.filter(created_at__date__lte=end_date)
        
        # Filtrer par distribution
        distribution_id = self.request.query_params.get('distribution_id', None)
        if distribution_id:
            queryset = queryset.filter(distribution_id=distribution_id)
        
        return queryset
    
    def perform_create(self, serializer):
        serializer.save(created_by=self.request.user)


class SupplierViewSet(viewsets.ModelViewSet):
    """ViewSet pour la gestion des fournisseurs."""
    
    queryset = Supplier.objects.all()
    serializer_class = SupplierSerializer
    permission_classes = [permissions.IsAuthenticated, IsAdminOrManager]
    filter_backends = [filters.SearchFilter, filters.OrderingFilter]
    search_fields = ['name', 'contact_person', 'email', 'phone']
    ordering_fields = ['name', 'created_at']
    ordering = ['name']


class PurchaseViewSet(viewsets.ModelViewSet):
    """ViewSet pour la gestion des achats."""
    
    queryset = Purchase.objects.all()
    permission_classes = [permissions.IsAuthenticated, IsAdminOrManager]
    filter_backends = [filters.SearchFilter, filters.OrderingFilter]
    search_fields = ['reference', 'supplier__name', 'notes']
    ordering_fields = ['order_date', 'expected_delivery_date', 'status', 'created_at']
    ordering = ['-order_date']
    
    def get_serializer_class(self):
        if self.action == 'create':
            return PurchaseCreateSerializer
        return PurchaseSerializer
    
    def get_queryset(self):
        queryset = super().get_queryset()
        
        # Filtrer par statut
        status_param = self.request.query_params.get('status', None)
        if status_param:
            queryset = queryset.filter(status=status_param)
        
        # Filtrer par fournisseur
        supplier_id = self.request.query_params.get('supplier_id', None)
        if supplier_id:
            queryset = queryset.filter(supplier_id=supplier_id)
        
        # Filtrer par date de commande
        start_date = self.request.query_params.get('start_date', None)
        if start_date:
            queryset = queryset.filter(order_date__gte=start_date)
        
        end_date = self.request.query_params.get('end_date', None)
        if end_date:
            queryset = queryset.filter(order_date__lte=end_date)
        
        return queryset
    
    def perform_create(self, serializer):
        serializer.save(created_by=self.request.user)
    
    @action(detail=True, methods=['post'])
    def add_item(self, request, pk=None):
        """Ajoute un article à l'achat."""
        purchase = self.get_object()
        item_id = request.data.get('item_id')
        quantity_ordered = request.data.get('quantity_ordered', 0)
        unit_price = request.data.get('unit_price')
        notes = request.data.get('notes', '')
        
        if not item_id or quantity_ordered <= 0:
            return Response(
                {'error': 'L\'identifiant de l\'article et une quantité positive sont requis.'},
                status=status.HTTP_400_BAD_REQUEST
            )
        
        try:
            from distributions.models import DistributionItem
            item = DistributionItem.objects.get(pk=item_id)
            
            # Vérifier si l'article existe déjà dans l'achat
            purchase_item, created = PurchaseItem.objects.get_or_create(
                purchase=purchase,
                item=item,
                defaults={
                    'quantity_ordered': quantity_ordered,
                    'unit_price': unit_price,
                    'notes': notes
                }
            )
            
            if not created:
                purchase_item.quantity_ordered = quantity_ordered
                purchase_item.unit_price = unit_price
                purchase_item.notes = notes
                purchase_item.save()
            
            serializer = PurchaseItemSerializer(purchase_item)
            return Response(serializer.data)
            
        except DistributionItem.DoesNotExist:
            return Response(
                {'error': 'Article non trouvé.'},
                status=status.HTTP_404_NOT_FOUND
            )
    
    @action(detail=True, methods=['post'])
    def remove_item(self, request, pk=None):
        """Supprime un article de l'achat."""
        purchase = self.get_object()
        item_id = request.data.get('item_id')
        
        if not item_id:
            return Response(
                {'error': 'L\'identifiant de l\'article est requis.'},
                status=status.HTTP_400_BAD_REQUEST
            )
        
        try:
            purchase_item = PurchaseItem.objects.get(
                purchase=purchase,
                item_id=item_id
            )
            purchase_item.delete()
            return Response(status=status.HTTP_204_NO_CONTENT)
            
        except PurchaseItem.DoesNotExist:
            return Response(
                {'error': 'Article non trouvé dans cet achat.'},
                status=status.HTTP_404_NOT_FOUND
            )
    
    @action(detail=True, methods=['post'])
    def receive_items(self, request, pk=None):
        """Réceptionne des articles de l'achat."""
        purchase = self.get_object()
        
        serializer = PurchaseReceiveSerializer(data=request.data, context={'request': request})
        if serializer.is_valid():
            received_items = serializer.save()
            
            # Mettre à jour le statut de l'achat si nécessaire
            all_items = purchase.items.all()
            fully_received = all(item.is_fully_received for item in all_items)
            partially_received = any(item.quantity_received > 0 for item in all_items)
            
            if fully_received:
                purchase.status = Purchase.Status.RECEIVED
            elif partially_received:
                purchase.status = Purchase.Status.PARTIAL
            
            purchase.save()
            
            return Response({'status': 'Articles réceptionnés avec succès.'})
        
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    
    @action(detail=True, methods=['post'])
    def update_status(self, request, pk=None):
        """Met à jour le statut de l'achat."""
        purchase = self.get_object()
        new_status = request.data.get('status')
        
        if not new_status:
            return Response(
                {'error': 'Le nouveau statut est requis.'},
                status=status.HTTP_400_BAD_REQUEST
            )
        
        # Vérifier si le statut est valide
        if new_status not in dict(Purchase.Status.choices):
            return Response(
                {'error': 'Statut invalide.'},
                status=status.HTTP_400_BAD_REQUEST
            )
        
        purchase.status = new_status
        purchase.save()
        
        serializer = self.get_serializer(purchase)
        return Response(serializer.data)