from django.db import models
from django.utils.translation import gettext_lazy as _
from django.utils import timezone
from distributions.models import DistributionItem


class StockItem(models.Model):
    """Modèle pour les articles en stock."""
    
    item = models.ForeignKey(
        DistributionItem,
        on_delete=models.CASCADE,
        related_name='stock_items',
        verbose_name=_('article')
    )
    quantity = models.DecimalField(
        _('quantité'),
        max_digits=10,
        decimal_places=2,
        default=0
    )
    batch_number = models.CharField(_('numéro de lot'), max_length=50, blank=True, null=True)
    expiry_date = models.DateField(_('date d\'expiration'), blank=True, null=True)
    location = models.CharField(_('emplacement'), max_length=100, blank=True, null=True)
    notes = models.TextField(_('notes'), blank=True, null=True)
    
    # Métadonnées
    created_at = models.DateTimeField(_('créé le'), auto_now_add=True)
    updated_at = models.DateTimeField(_('mis à jour le'), auto_now=True)
    
    class Meta:
        verbose_name = _('article en stock')
        verbose_name_plural = _('articles en stock')
        ordering = ['item__name', '-expiry_date']
    
    def __str__(self):
        return f"{self.item.name} - {self.quantity} {self.item.unit} (Lot: {self.batch_number or 'N/A'})"
    
    @property
    def is_expired(self):
        if self.expiry_date:
            return self.expiry_date < timezone.now().date()
        return False
    
    @property
    def expires_soon(self):
        if self.expiry_date:
            days_until_expiry = (self.expiry_date - timezone.now().date()).days
            return 0 <= days_until_expiry <= 30
        return False


class StockMovement(models.Model):
    """Modèle pour les mouvements de stock (entrées/sorties)."""
    
    class MovementType(models.TextChoices):
        IN = 'IN', _('Entrée')
        OUT = 'OUT', _('Sortie')
        ADJUSTMENT = 'ADJUSTMENT', _('Ajustement')
    
    stock_item = models.ForeignKey(
        StockItem,
        on_delete=models.CASCADE,
        related_name='movements',
        verbose_name=_('article en stock')
    )
    movement_type = models.CharField(
        _('type de mouvement'),
        max_length=10,
        choices=MovementType.choices
    )
    quantity = models.DecimalField(
        _('quantité'),
        max_digits=10,
        decimal_places=2
    )
    reference = models.CharField(_('référence'), max_length=100, blank=True, null=True)
    notes = models.TextField(_('notes'), blank=True, null=True)
    
    # Relation optionnelle avec une distribution
    distribution = models.ForeignKey(
        'distributions.Distribution',
        on_delete=models.SET_NULL,
        related_name='stock_movements',
        verbose_name=_('distribution'),
        blank=True,
        null=True
    )
    
    # Métadonnées
    created_at = models.DateTimeField(_('créé le'), auto_now_add=True)
    created_by = models.ForeignKey(
        'users.User',
        on_delete=models.SET_NULL,
        related_name='stock_movements',
        verbose_name=_('créé par'),
        blank=True,
        null=True
    )
    
    class Meta:
        verbose_name = _('mouvement de stock')
        verbose_name_plural = _('mouvements de stock')
        ordering = ['-created_at']
    
    def __str__(self):
        movement_type_display = self.get_movement_type_display()
        return f"{movement_type_display} - {self.stock_item.item.name} ({self.quantity} {self.stock_item.item.unit})"
    
    def save(self, *args, **kwargs):
        # Mettre à jour la quantité en stock
        if self.movement_type == self.MovementType.IN:
            self.stock_item.quantity += self.quantity
        elif self.movement_type == self.MovementType.OUT:
            self.stock_item.quantity -= self.quantity
        elif self.movement_type == self.MovementType.ADJUSTMENT:
            # Pour un ajustement, la quantité peut être positive ou négative
            self.stock_item.quantity += self.quantity
        
        self.stock_item.save()
        super().save(*args, **kwargs)


class Supplier(models.Model):
    """Modèle pour les fournisseurs d'articles."""
    
    name = models.CharField(_('nom'), max_length=100)
    contact_person = models.CharField(_('personne de contact'), max_length=100, blank=True, null=True)
    email = models.EmailField(_('email'), blank=True, null=True)
    phone = models.CharField(_('téléphone'), max_length=20, blank=True, null=True)
    address = models.TextField(_('adresse'), blank=True, null=True)
    notes = models.TextField(_('notes'), blank=True, null=True)
    
    # Métadonnées
    created_at = models.DateTimeField(_('créé le'), auto_now_add=True)
    updated_at = models.DateTimeField(_('mis à jour le'), auto_now=True)
    
    class Meta:
        verbose_name = _('fournisseur')
        verbose_name_plural = _('fournisseurs')
        ordering = ['name']
    
    def __str__(self):
        return self.name


class Purchase(models.Model):
    """Modèle pour les achats d'articles."""
    
    class Status(models.TextChoices):
        ORDERED = 'ORDERED', _('Commandé')
        PARTIAL = 'PARTIAL', _('Partiellement reçu')
        RECEIVED = 'RECEIVED', _('Reçu')
        CANCELLED = 'CANCELLED', _('Annulé')
    
    supplier = models.ForeignKey(
        Supplier,
        on_delete=models.CASCADE,
        related_name='purchases',
        verbose_name=_('fournisseur')
    )
    reference = models.CharField(_('référence'), max_length=100, blank=True, null=True)
    order_date = models.DateField(_('date de commande'), default=timezone.now)
    expected_delivery_date = models.DateField(_('date de livraison prévue'), blank=True, null=True)
    status = models.CharField(
        _('statut'),
        max_length=10,
        choices=Status.choices,
        default=Status.ORDERED
    )
    notes = models.TextField(_('notes'), blank=True, null=True)
    
    # Métadonnées
    created_at = models.DateTimeField(_('créé le'), auto_now_add=True)
    updated_at = models.DateTimeField(_('mis à jour le'), auto_now=True)
    created_by = models.ForeignKey(
        'users.User',
        on_delete=models.SET_NULL,
        related_name='purchases',
        verbose_name=_('créé par'),
        blank=True,
        null=True
    )
    
    class Meta:
        verbose_name = _('achat')
        verbose_name_plural = _('achats')
        ordering = ['-order_date']
    
    def __str__(self):
        return f"Commande {self.reference or self.id} - {self.supplier.name}"


class PurchaseItem(models.Model):
    """Modèle pour les articles d'un achat."""
    
    purchase = models.ForeignKey(
        Purchase,
        on_delete=models.CASCADE,
        related_name='items',
        verbose_name=_('achat')
    )
    item = models.ForeignKey(
        DistributionItem,
        on_delete=models.CASCADE,
        related_name='purchase_items',
        verbose_name=_('article')
    )
    quantity_ordered = models.DecimalField(
        _('quantité commandée'),
        max_digits=10,
        decimal_places=2
    )
    quantity_received = models.DecimalField(
        _('quantité reçue'),
        max_digits=10,
        decimal_places=2,
        default=0
    )
    unit_price = models.DecimalField(
        _('prix unitaire'),
        max_digits=10,
        decimal_places=2,
        blank=True,
        null=True
    )
    notes = models.TextField(_('notes'), blank=True, null=True)
    
    class Meta:
        verbose_name = _('article d\'achat')
        verbose_name_plural = _('articles d\'achat')
        unique_together = ['purchase', 'item']
    
    def __str__(self):
        return f"{self.item.name} - {self.quantity_ordered} {self.item.unit}"
    
    @property
    def total_price(self):
        if self.unit_price is not None:
            return self.quantity_ordered * self.unit_price
        return None
    
    @property
    def is_fully_received(self):
        return self.quantity_received >= self.quantity_ordered