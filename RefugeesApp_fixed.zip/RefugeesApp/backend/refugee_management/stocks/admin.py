from django.contrib import admin
from .models import StockItem, StockMovement


@admin.register(StockItem)
class StockItemAdmin(admin.ModelAdmin):
    list_display = ('item', 'quantity', 'unit', 'batch_number', 'expiry_date', 'location', 'is_expired', 'expires_soon')
    list_filter = ('item__name', 'expiry_date', 'location', 'created_at')
    search_fields = ('item__name', 'batch_number', 'location')
    readonly_fields = ('created_at', 'updated_at')
    autocomplete_fields = ['item']

    def unit(self, obj):
        return obj.item.unit
    unit.short_description = 'Unité'

    def is_expired(self, obj):
        return obj.is_expired
    is_expired.boolean = True
    is_expired.short_description = 'Expiré ?'

    def expires_soon(self, obj):
        return obj.expires_soon
    expires_soon.boolean = True
    expires_soon.short_description = 'Expire bientôt ?'


@admin.register(StockMovement)
class StockMovementAdmin(admin.ModelAdmin):
    list_display = ('stock_item', 'movement_type', 'quantity', 'reference', 'distribution', 'created_at', 'created_by')
    list_filter = ('movement_type', 'created_at', 'distribution')
    search_fields = ('stock_item__item__name', 'reference', 'distribution__distribution_id', 'created_by__email')
    readonly_fields = ('created_at',)
    autocomplete_fields = ['stock_item', 'distribution', 'created_by']

    def save_model(self, request, obj, form, change):
        if not obj.created_by:
            obj.created_by = request.user
        super().save_model(request, obj, form, change)