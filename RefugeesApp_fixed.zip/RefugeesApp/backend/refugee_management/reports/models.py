from django.db import models
from django.utils.translation import gettext_lazy as _
from django.utils import timezone
import uuid
from django.contrib.auth import get_user_model

User = get_user_model()

def generate_report_id():
    return f"RPT-{uuid.uuid4().hex[:8].upper()}"

class Report(models.Model):
    """Modèle pour les rapports d'activité."""
    
    class ReportType(models.TextChoices):
        DISTRIBUTION = 'DISTRIBUTION', _('Distribution')
        REFUGEE = 'REFUGEE', _('Réfugié')
        STOCK = 'STOCK', _('Stock')
        ACTIVITY = 'ACTIVITY', _('Activité générale')
    
    class Status(models.TextChoices):
        DRAFT = 'DRAFT', _('Brouillon')
        PUBLISHED = 'PUBLISHED', _('Publié')
        ARCHIVED = 'ARCHIVED', _('Archivé')
    
    # Identifiant unique pour chaque rapport
    report_id = models.CharField(
        _('numéro de rapport'),
        max_length=20,
        unique=True,
        default=generate_report_id,
        help_text=_('Identifiant unique du rapport')
    )
    
    # Informations sur le rapport
    title = models.CharField(_('titre'), max_length=200)
    description = models.TextField(_('description'), blank=True, null=True)
    report_type = models.CharField(
        _('type de rapport'),
        max_length=20,
        choices=ReportType.choices,
        default=ReportType.ACTIVITY
    )
    content = models.JSONField(_('contenu'), default=dict, help_text=_('Contenu du rapport au format JSON'))
    
    # Période couverte par le rapport
    start_date = models.DateField(_('date de début'), default=timezone.now)
    end_date = models.DateField(_('date de fin'), default=timezone.now)
    
    # Statut et métadonnées
    status = models.CharField(
        _('statut'),
        max_length=20,
        choices=Status.choices,
        default=Status.DRAFT
    )
    created_by = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True,
        related_name='created_reports',
        verbose_name=_('créé par')
    )
    created_at = models.DateTimeField(_('créé le'), auto_now_add=True)
    updated_at = models.DateTimeField(_('mis à jour le'), auto_now=True)
    published_at = models.DateTimeField(_('publié le'), null=True, blank=True)
    
    class Meta:
        verbose_name = _('rapport')
        verbose_name_plural = _('rapports')
        ordering = ['-created_at']
    
    def __str__(self):
        return f"{self.report_id} - {self.title} ({self.get_report_type_display()})"
    
    def publish(self):
        """Publier le rapport."""
        self.status = self.Status.PUBLISHED
        self.published_at = timezone.now()
        self.save()
    
    def archive(self):
        """Archiver le rapport."""
        self.status = self.Status.ARCHIVED
        self.save()