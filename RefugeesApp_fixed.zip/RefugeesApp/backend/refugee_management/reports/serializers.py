from rest_framework import serializers
from .models import Report
from django.contrib.auth import get_user_model

User = get_user_model()

class ReportSerializer(serializers.ModelSerializer):
    generated_by = serializers.SlugRelatedField(
        slug_field='username',  # Ou 'email' ou un autre champ unique de User
        queryset=User.objects.all(),
        allow_null=True,  # Permettre null si generated_by peut être null
        required=False    # Ne pas exiger si generated_by peut être null
    )
    report_type_display = serializers.CharField(source='get_report_type_display', read_only=True)

    class Meta:
        model = Report
        fields = ['id', 'name', 'report_type', 'report_type_display', 'generated_at', 'generated_by', 'file_path']
        read_only_fields = ['id', 'generated_at', 'report_type_display']

# Vous pourriez avoir besoin de sérialiseurs plus spécifiques si les vues retournent des données différentes
# pour les réfugiés, distributions, et stocks qui ne sont pas directement des objets Report.

# Par exemple, si RefugeeReportView doit retourner une liste de réfugiés:
# from ..refugees.models import Refugee  # Assurez-vous que ce chemin d'importation est correct
# from ..refugees.serializers import RefugeeSerializer # Assurez-vous que ce chemin d'importation est correct

# class RefugeeReportDataSerializer(serializers.Serializer):
#     # Définissez les champs que vous attendez pour les données du rapport sur les réfugiés
#     # Ceci est un exemple, adaptez-le à la structure de données réelle
#     count = serializers.IntegerField()
#     data = RefugeeSerializer(many=True) # Si vous retournez une liste d'objets Refugee

# De même pour DistributionReportView et StockReportView
# from ..distributions.models import Distribution
# from ..distributions.serializers import DistributionSerializer

# class DistributionReportDataSerializer(serializers.Serializer):
#     count = serializers.IntegerField()
#     data = DistributionSerializer(many=True)

# from ..stocks.models import Stock
# from ..stocks.serializers import StockSerializer

# class StockReportDataSerializer(serializers.Serializer):
#     count = serializers.IntegerField()
#     data = StockSerializer(many=True)