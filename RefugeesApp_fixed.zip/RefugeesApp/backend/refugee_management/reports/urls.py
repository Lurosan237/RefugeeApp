from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import RefugeeReportView, DistributionReportView, StockReportView #, ReportViewSet # Importez les vues nécessaires

router = DefaultRouter()
# Si vous avez un ReportViewSet pour les rapports génériques (comme la liste des rapports créés, leur téléchargement etc)
# router.register(r'', ReportViewSet, basename='report') # Note: ajustez le préfixe si nécessaire ou retirez si non utilisé pour la racine de /api/reports/

urlpatterns = [
    path('', include(router.urls)), # Pour les opérations CRUD sur les objets Report via ReportViewSet si utilisé
    path('refugees/', RefugeeReportView.as_view(), name='report-refugees'),
    path('distributions/', DistributionReportView.as_view(), name='report-distributions'),
    path('stocks/', StockReportView.as_view(), name='report-stocks'),
    # Ajoutez d'autres URLs spécifiques à l'application ici si nécessaire
    # Par exemple, si ReportViewSet gère /api/reports/ (liste, création) et /api/reports/{id}/ (détail, suppression, téléchargement)
    # alors les routes ci-dessus pour refugees, distributions, stocks sont pour les *données* de rapport spécifiques.
]