"""
Reports Module

This module handles reporting and analytics in the Refugee Management System.
"""

# Comment out early imports to avoid AppRegistryNotReady error
# from . import models  # noqart models  # noqa