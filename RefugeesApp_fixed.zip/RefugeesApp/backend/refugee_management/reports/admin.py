from django.contrib import admin
from django.utils.translation import gettext_lazy as _
from .models import Report


@admin.register(Report)
class ReportAdmin(admin.ModelAdmin):
    """Administration des rapports."""
    
    list_display = ('report_id', 'title', 'report_type', 'status', 'start_date', 'end_date', 'created_by', 'created_at')
    list_filter = ('report_type', 'status', 'start_date', 'end_date')
    search_fields = ('report_id', 'title', 'description')
    readonly_fields = ('report_id', 'created_at', 'updated_at', 'published_at')
    fieldsets = (
        (_('Informations générales'), {
            'fields': ('report_id', 'title', 'description', 'report_type')
        }),
        (_('Période'), {
            'fields': ('start_date', 'end_date')
        }),
        (_('Contenu'), {
            'fields': ('content',)
        }),
        (_('Statut'), {
            'fields': ('status', 'created_by', 'created_at', 'updated_at', 'published_at')
        }),
    )
    
    def save_model(self, request, obj, form, change):
        if not change:  # Si c'est une création (pas une modification)
            obj.created_by = request.user
        super().save_model(request, obj, form, change)