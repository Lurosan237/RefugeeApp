import os
import sys

# Add the backend directory to the Python path
project_root = os.path.dirname(os.path.abspath(__file__))
backend_dir = os.path.join(project_root, 'backend')
sys.path.insert(0, backend_dir)

# Try to import the settings module directly
try:
    import refugee_management.refugee_management.settings as settings
    print("Successfully imported settings module")
    print(f"Settings module path: {settings.__file__}")
except ImportError as e:
    print(f"Error importing settings: {e}")
    import traceback
    traceback.print_exc()

# Try to import the base settings
try:
    from refugee_management.refugee_management import base
    print("\nSuccessfully imported base settings")
    print(f"Base settings path: {base.__file__}")
except ImportError as e:
    print(f"\nError importing base settings: {e}")
    import traceback
    traceback.print_exc()
