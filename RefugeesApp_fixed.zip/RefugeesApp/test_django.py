import os
import sys
from pathlib import Path

# Add the backend directory to the Python path
project_root = Path(__file__).parent.absolute()
backend_dir = project_root / 'backend'
sys.path.insert(0, str(backend_dir))

# Set the Django settings module
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'refugee_management.refugee_management.settings')

# Initialize Django
try:
    import django
    django.setup()
    print("Django initialized successfully")
except Exception as e:
    print(f"Error initializing Django: {e}")
    import traceback
    traceback.print_exc()
    sys.exit(1)

# Try to import the users app
try:
    from django.apps import apps
    print("\nAvailable apps:")
    for app_config in apps.get_app_configs():
        print(f"- {app_config.name}")
    
    print("\nTrying to get users app config...")
    users_config = apps.get_app_config('users')
    print(f"Successfully got users app config: {users_config.name}")
    print(f"Users app models: {list(users_config.get_models())}")
    
    # Try to import the Refugee model
    from refugee_management.refugees.models import Refugee
    print(f"\nSuccessfully imported Refugee model: {Refugee}")
    
except Exception as e:
    print(f"\nError getting app configs: {e}")
    import traceback
    traceback.print_exc()
